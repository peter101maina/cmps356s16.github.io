<?php
include('config/db.php');

session_start();
$error = '';

if(isset($_POST['submit'])){
    if (empty($_POST['username']) || empty($_POST['password'])) {
        $error = "Username or Password is invalid";
    } else {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $username = stripslashes($username);
        $password = stripslashes($password);

        $username = $conn->real_escape_string($username);
        $password = $conn->real_escape_string($password);

        $password = md5($password);
        $sql = $conn->query("select * from admin where username='$username' AND password ='$password'");
        $rows = $sql->num_rows;

        if ($rows == 1) {
            $_SESSION['login_user']=$username; // Initializing Session
            header("location: home.php"); // Redirecting To Other Page
        } else {
            $error = '<div class="alert">
                        <span class="closebtn">&times;</span>
                        <strong>Error!</strong> Username or password does not exist.
                        </div>';
        }

        $conn->close();
    } 
}

?>