<?php
    //add.php
    require('config/db.php');

    $fname = $_POST["fname"];
    $mname = $_POST["mname"];
    $lname = $_POST["lname"];
    $username = $_POST["username"];
    $pass1 = $_POST["pass1"];
    $pass2 = $_POST["pass2"];
    $role = $_POST["role"];
    $house_no = $_POST["house_no"];
    $city = $_POST["city"];
    $phone_number = $_POST["phone_number"];
    $email = $_POST["email"];

    $name = $fname.' '.$mname.' '.$lname;
    $password = md5($pass1);
    $details = $house_no.'<br/>'.$city;
    date_default_timezone_set('Africa/Nairobi');
    $date = date("Y-m-d h:i:sa");

    $sql = "INSERT INTO `admin`(`full_name`, `username`, `password`, `role`, `phone_number`, `email`, `details`, `last_login`, `date`) 
    VALUES ('$name', '$username', '$password', '$role', '$phone_number', '$email', '$details', '', '$date')";

    $result = $conn->query($sql);

    if($result){
        echo 'Success in adding the user';
    } else {
        echo 'Error: '. $conn->error;
    }
?>