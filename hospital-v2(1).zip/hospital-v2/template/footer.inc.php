<!-- footer -->
		<div class="footer">
			<p>© 2016 Hospital Management System . All Rights Reserved . Design by <a href="http://w3layouts.com/">W3layouts</a></p>
		</div>
		<!-- //footer -->
	</section>
	<script src="js/bootstrap.js"></script>
</body>
</html>