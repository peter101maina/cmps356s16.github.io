<?php require('template/header.inc.php'); ?>
		<div class="main-grid">
			<div class="agile-grids">	
				<!-- blank-page -->
				
				<div class="banner">
					<h2>
						<a href="home.php">Home</a>
						<i class="fa fa-angle-right"></i>
						<span>Patient Master</span>
					</h2>
				</div>
				
				<div class="blank">
					<div class="blank-page">
                        <div class="agile-tables">
					<div class="w3l-table-info">
					  <h3>Patient Master  &nbsp;<a href="addPatient.php" class="btn btn-primary">Add New Patient</a></h3>
                        <?php 

                        if(isset($_GET['msg']) == 'success' && isset($_GET['msg']) == 'success'){
                            echo ' <div class="alert alert-success">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <strong>Success!</strong> Patient Deleted.
                                    </div>';
                        } else if(isset($_GET['msg']) == 'error' && isset($_GET['msg']) == 'error'){
                        echo ' <div class="alert alert-warning">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Error!</strong> Patient not deleted.
                                </div>';
                        }
                        ?>
					    <table id="table">
						<thead>
						  <tr>
							<th>#</th>
							<th>Patient Name</th>
							<th>Age</th>
							<th>Gender</th>
							<th>Blood Group</th>
							<th>Marital Status</th>
							<th>Date of Entry</th>
							<th>Action</th>
						  </tr>
						</thead>
                        <tbody>
                        <?php 
                            $sql = "select * from patients ORDER BY patient_id DESC";
                            $result = $conn->query($sql);

                            if($result->num_rows > 0){
                                while($rows = $result->fetch_assoc()){

                                    $id = $rows['patient_id'];
                                    $name = $rows['name'];
                                    $gender = $rows['gender'];
                                    $birthday = $rows['birthday'];
                                    $blood_group = $rows['blood_group'];
                                    $marital_status = $rows['marital_status'];
                                    $date = $rows['date'];

                                    $date = date("Y-M-d");
                                    $age = $date - $birthday;

                                    if($gender == 1){
                                        $gender = 'Male';
                                    } else {
                                        $gender = 'Female';
                                    }

                        ?>
                    <tr>
                        <td><a href="patient.php?id=<?php echo $id; ?>"><?php echo 'P-00'.$id; ?></a></td>
                        <td><?php echo $name; ?></td>
                        <td><?php echo $age; ?></td>
                        <td><?php echo $gender; ?></td>
                        <td><?php echo strtoupper($blood_group); ?></td>
                        <td><?php echo $marital_status; ?></td>
                        <td><?php echo $date; ?></td>
                        <td><a href="editPatient.php?p_id=<?php echo $id; ?>">Modify</a> | <a href="delete.php?id=<?php echo $id; ?>">Delete</a></td>
                    </tr>
						</tbody>
                        <?php 
                            }
                        }
                        ?>
					  </table>
					</div>
                </div>

					</div>
			   </div>
				<!-- //blank-page -->
			</div>
		</div>
		
        <!--data tables-->
        <script src="js/jquery.min.js"></script>
        <script src="datatables/js/jquery.dataTables.min.js"></script>
        <script src="datatables/js/dataTables.bootstrap.min.js"></script>

        <script>
        $('#table').dataTable();
        </script>
		<?php require('template/footer.inc.php'); ?>