<?php
    include('config/db.php');

    $get = $conn->query("select * from doctors where dept_id='".$_POST['countryId']."'");

    if($get->num_rows > 0){
        while($get_results = $get->fetch_assoc()){

            $dept_id = $get_results['doctor_id'];
            $title = $get_results['name'];
            echo '<option value="'.$dept_id.'">'.$title.'</option>';
            // echo $dept_id. ' ' . $title;
        }
    } else {
        echo '<option value="">--No Department --</option>';
    }

?>