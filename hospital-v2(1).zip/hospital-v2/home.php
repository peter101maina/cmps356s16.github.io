<?php require('template/header.inc.php'); ?>
		<div class="main-grid">
			<div class="agile-grids">	
				<!-- blank-page -->
				
				<div class="banner">
					<h2>
						<a href="home.php">Home</a>
						<i class="fa fa-angle-right"></i>
						<span>Dashboard</span>
					</h2>
				</div>
				
				<div class="blank">
					<div class="blank-page">
						<div class="panel panel-default">
							<div class="row">
								<div class="col-md-6">
									<div class="panel-heading">New Patient</div>
									<div class="panel-body">
										<div class="col-md-12">
											<table id="table">
												<thead>
												<tr>
													<th>#</th>
													<th>Patient Name</th>
													<th>Age</th>
													<th>Date of Entry</th>
												</tr>
												</thead>
												<tbody>
												<?php 
													$sql = "select * from patients ORDER BY patient_id DESC";
													$result = $conn->query($sql);

													if($result->num_rows > 0){
														while($rows = $result->fetch_assoc()){

															$id = $rows['patient_id'];
															$name = $rows['name'];
															$birthday = $rows['birthday'];
															$date = $rows['date'];

															$date = date("Y-M-d");
															$age = $date - $birthday;


												?>
											<tr>
												<td><a href="patient.php?id=<?php echo $id; ?>"><?php echo 'P-00'.$id; ?></a></td>
												<td><?php echo $name; ?></td>
												<td><?php echo $age; ?></td>
												<td><?php echo $date; ?></td>
											</tr>
												</tbody>
												<?php 
													}
												}
												?>
											</table>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="panel-heading">Visiting Patient</div>
									<div class="panel-body">
										<div class="col-md-12">
											<table id="table">
												<thead>
												<tr>
													<th>OPD No</th>
													<th>Name</th>
													<th>Department</th>
													<th>Visiting Date</th>
												</tr>
												</thead>
												<tbody>
												<?php
													$opd= $conn->query("select * from opd");

													while($row = $opd->fetch_assoc()){
														$opd_id = $row['opd_id'];
														$patient_id = $row['patient_id'];
														$doctor_id = $row['doctor_id'];
														$dept_id = $row['dept_id'];
														$date = $row['date'];
														$status = $row['status'];

														if($status == 1){
															$status = "Checked In";
														} else if($status == 0) {
															$status = "Check Out";
														}

														$sql = "select * from patients where patient_id='$patient_id'";
														$result = $conn->query($sql);

															while($rows = $result->fetch_assoc()){

																$id = $rows['patient_id'];
																$name = $rows['name'];																$gender = $rows['gender'];
																$birthday = $rows['birthday'];

																$date = date("Y-M-d");
																$age = $date - $birthday;


														$doc = $conn->query("select * from doctors where doctor_id='$doctor_id'");
														while($doctors = $doc->fetch_assoc()){
															$doc_id = $doctors['doctor_id'];
															$doc_name = $doctors['name'];
															$depert_id = $doctors['dept_id'];

															$department = $conn->query("select * from departments where id='$dept_id'");
															while($dept = $department->fetch_assoc()){
																$dep_id = $dept['id'];
																$title = $dept['title'];

												?>
											<tr>
												<td><?php echo $opd_id; ?></td>
												<td><?php echo $name; ?></td>
												<td><?php echo $title; ?></td>
												<td><?php echo $date; ?></td>
											</tr>
												</tbody>
												<?php 
																}
															}
														}
													}
												?>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- //blank-page -->
			</div>
		</div>
		
		<?php require('template/footer.inc.php'); ?>