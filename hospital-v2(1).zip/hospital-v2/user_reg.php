<?php require('template/header.inc.php'); ?>
		<div class="main-grid">
			<div class="agile-grids">	
				<!-- input-forms -->
				<div class="grids">
					<div class="progressbar-heading grids-heading">
						<h2>Add new users forms</h2>
					</div>

                    <form class="form-horizontal" action="#" method="post" name="patientForm" id="patientForm">
                        
                        <button type="reset" class="btn btn-warning"><i class="fa fa-trash"></i> Reset</button>
                        <button type="submit" id="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                        <br/>
                        <br/>
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#home">Personal Information</a></li>
                            <li><a data-toggle="tab" href="#menu1">Contact Information</a></li>
                        </ul>

                        <div class="tab-content">
                            <div id="home" class="tab-pane fade in active">
                                <div class="panel panel-widget forms-panel">
                                    <div class="progressbar-heading general-heading">
                                        <h4>General Form:</h4>
                                    </div>
                                    <div class="forms">
                                        <h3 class="title1"></h3>
                                        <div class="form-three widget-shadow">
                                            <div class="form-group">
                                                <label for="focusedinput" class="col-sm-2 control-label">Patient Name</label>
                                                <div class="col-sm-3">
                                                    <input type="text" class="form-control1" name="fname" id="fname" placeholder="First Name">
                                                </div>
                                                <div class="col-sm-3">
                                                    <input type="text" class="form-control1" name="mname" id="mname" placeholder="Middle Name">
                                                </div>
                                                <div class="col-sm-3">
                                                    <input type="text" class="form-control1" name="lname" id="lname" placeholder="Last name">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputPassword" class="col-sm-2 control-label">Username</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" name="username" id="username" filter="date"  placeholder="Username">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputPassword" class="col-sm-2 control-label">Password</label>
                                                <div class="col-sm-9">
                                                    <input type="password" class="form-control1" name="pass1" id="pass1" placeholder="Password">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputPassword" class="col-sm-2 control-label">Password</label>
                                                <div class="col-sm-9">
                                                    <input type="password" class="form-control1" name="pass2" id="pass2" placeholder="Password">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="selector1" class="col-sm-2 control-label">Role</label>
                                                <div class="col-sm-9"><select name="role" id="role" class="form-control1">
                                                    <option value="">Select role...</option>
                                                    <option value="administrator">Administrator</option>
                                                    <option value="manager">Manager</option>
                                                    <option value="accountant">Accountant</option>
                                                    <option value="doctor">Doctor</option>
                                                    <option value="nurse">Nurse</option>
                                                    <option value="normal">Normal User</option>
                                                </select></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="menu1" class="tab-pane fade">
                                <div class="panel panel-widget forms-panel">
                                    <div class="progressbar-heading general-heading">
                                    </div>
                                    <div class="forms">
                                        <h3 class="title1">Contact Information</h3>
                                        <div class="form-three widget-shadow">
                                            
                                            <div class="form-group">
                                                <label for="inputPassword" class="col-sm-2 control-label">House no.</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control1" name="house_no" id="house_no" placeholder="House no.">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputPassword" class="col-sm-2 control-label">City</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control1" name="city" id="city" placeholder="City/county">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputPassword" class="col-sm-2 control-label">Phone no</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control1" name="phone_number" id="phone_number" placeholder="Phone number">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputPassword" class="col-sm-2 control-label">Email</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control1" name="email" id="email" placeholder="Email">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
				</div>
				<!-- //input-forms -->
                <script src="js/jquery.min.js"></script>
                <script>
                    $(document).ready(function(){
                        $("#submit").click(function(){
                            var fname = $("#fname").val();
                            var mname = $("#mname").val();
                            var lname = $("#lname").val();
                            var username = $("#username").val();
                            var pass1 = $("#pass1").val();
                            var pass2 = $("#pass2").val();
                            var role = $("#role").val();
                            var house_no = $("#house_no").val();
                            var city = $("#city").val();
                            var phone_number = $("#phone_number").val();
                            var email = $("#email").val();

                            // Returns successful data submission message when the entered information is stored in database.
                            var dataString = 'fname='+ fname + '&mname='+ mname + '&lname='+ lname + '&username='+ username+ '&pass1='+ pass1 + '&pass2='+ pass2 + '&role='+ role + '&house_no='+ house_no + '&city='+ city + '&phone_number='+ phone_number + '&email='+ email;
                            
                            if(pass1 != pass2){
                                alert('Please match the passwords');
                            } else {
                                if(fname==''||username==''||role==''){
                                    alert("Please Fill All Fields required");
                                } else {
                                    // AJAX Code To Submit Form.
                                    $.ajax({
                                        type: "POST",
                                        url: "user_add.php",
                                        data: dataString,
                                        cache: false,
                                        success: function(result){
                                            alert(result);
                                        }
                                    });
                                }
                            }
                            return false;
                        });
                    });
                </script>

			</div>
		</div>
		<?php require('template/footer.inc.php'); ?>