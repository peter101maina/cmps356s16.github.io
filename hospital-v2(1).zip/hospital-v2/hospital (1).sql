-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 04, 2016 at 10:25 AM
-- Server version: 5.7.9
-- PHP Version: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(255) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(150) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(25) NOT NULL,
  `phone_number` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `details` text NOT NULL,
  `last_login` varchar(50) NOT NULL,
  `date` varchar(25) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `full_name`, `username`, `password`, `role`, `phone_number`, `email`, `details`, `last_login`, `date`) VALUES
(1, '-', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrator', '', '', '', '2016-10-04 08:10:55', '2016-10-04 08:12:55'),
(2, 'Emil Gabriel Kitua', 'emilkitua', '7815696ecbf1c96e6894b779456d330e', 'manager', '727235709', 'kituaemil@gmail.com', '123<br/>dar', '', '2016-10-04 08:43:51am');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
CREATE TABLE IF NOT EXISTS `departments` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `title`) VALUES
(1, 'Dentist'),
(2, 'Optician');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
CREATE TABLE IF NOT EXISTS `doctors` (
  `doctor_id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `dept_id` int(50) NOT NULL,
  PRIMARY KEY (`doctor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`doctor_id`, `name`, `dept_id`) VALUES
(1, 'Emil Kitua', 2),
(2, 'Daudi Kitua', 1);

-- --------------------------------------------------------

--
-- Table structure for table `opd`
--

DROP TABLE IF EXISTS `opd`;
CREATE TABLE IF NOT EXISTS `opd` (
  `opd_id` varchar(255) NOT NULL,
  `patient_id` int(10) NOT NULL,
  `doctor_id` int(10) NOT NULL,
  `dept_id` int(10) NOT NULL,
  `pulse_rate` varchar(10) NOT NULL,
  `temperature` varchar(5) NOT NULL,
  `height` varchar(6) NOT NULL,
  `bp` varchar(5) NOT NULL,
  `respiration` varchar(5) NOT NULL,
  `weight` varchar(5) NOT NULL,
  `allergies` text NOT NULL,
  `warnings` text NOT NULL,
  `social_history` text NOT NULL,
  `family_history` text NOT NULL,
  `personal_history` text NOT NULL,
  `past_medical_history` text NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `opd`
--

INSERT INTO `opd` (`opd_id`, `patient_id`, `doctor_id`, `dept_id`, `pulse_rate`, `temperature`, `height`, `bp`, `respiration`, `weight`, `allergies`, `warnings`, `social_history`, `family_history`, `personal_history`, `past_medical_history`, `date`, `status`) VALUES
('OPD-276', 3, 2, 1, '', '', '', '', '', '', '', '', '', ' ', '', '', '2016-10-03 20:18:52', 0);

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
CREATE TABLE IF NOT EXISTS `patients` (
  `patient_id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `gender` int(1) NOT NULL,
  `birthday` date NOT NULL,
  `birth_place` varchar(50) NOT NULL,
  `marital_status` varchar(50) NOT NULL,
  `religion` varchar(50) NOT NULL,
  `blood_group` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(75) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_no` varchar(50) NOT NULL,
  `details` text NOT NULL,
  `insurance_company` varchar(150) NOT NULL,
  `insurance_id` varchar(150) NOT NULL,
  `patient_indetifiers` text NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`patient_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patient_id`, `name`, `gender`, `birthday`, `birth_place`, `marital_status`, `religion`, `blood_group`, `address`, `city`, `country`, `email`, `phone_no`, `details`, `insurance_company`, `insurance_id`, `patient_indetifiers`, `date`) VALUES
(3, 'Emil Kitua', 1, '1993-11-29', 'dar', 'single', '', 'b-', '', '', 'Kenya', '', '', '', '-None-', '-None-', '', '2016-10-02 00:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
