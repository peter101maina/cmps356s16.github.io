<?php require('template/header.inc.php'); ?>
		<div class="main-grid">
			<div class="agile-grids">	
				<!-- blank-page -->
				
				<div class="banner">
					<h2>
						<a href="home.php">Home</a>
						<i class="fa fa-angle-right"></i>
						<span>Patient Master</span>
					</h2>
				</div>
				
				<div class="blank">
					<div class="blank-page">
                        <div class="agile-tables">
					<div class="w3l-table-info">
					  <h3>Patient Master  &nbsp;<a href="addPatient.php" class="btn btn-primary">Add New Patient</a></h3>
                        <?php 

                        if(isset($_GET['msg']) == 'success' && isset($_GET['msg']) == 'success'){
                            echo ' <div class="alert alert-success">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <strong>Success!</strong> User Deleted.
                                    </div>';
                        } else if(isset($_GET['msg']) == 'error' && isset($_GET['msg']) == 'error'){
                        echo ' <div class="alert alert-warning">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Error!</strong> User not deleted.
                                </div>';
                        }
                        ?>
					    <table id="table">
						<thead>
						  <tr>
							<th>#</th>
							<th>Full name</th>
							<th>Username</th>
							<th>Role</th>
							<th>Last Login</th>
							<th>Date of Entry</th>
							<th>Action</th>
						  </tr>
						</thead>
                        <tbody>
                        <?php 
                            $sql = "select * from admin ORDER BY admin_id DESC";
                            $result = $conn->query($sql);

                            if($result->num_rows > 0){
                                while($rows = $result->fetch_assoc()){

                                    $id = $rows['admin_id'];
                                    $name = $rows['full_name'];
                                    $username = $rows['username'];
                                    $role = $rows['role'];
                                    $last_login = $rows['last_login'];
                                    $date = $rows['date'];

                        ?>
                    <tr>
                        <!--<td><a href="user.php?id=<?php echo $id; ?>"><?php echo 'U-00'.$id; ?></a></td>-->
                        <td><?php echo 'U-00'.$id; ?></td>
                        <td><?php echo $name; ?></td>
                        <td><?php echo $username; ?></td>
                        <td><?php echo $role; ?></td>
                        <td><?php echo $last_login; ?></td>
                        <td><?php echo $date; ?></td>
                        <td><a href="delete.php?u_id=<?php echo $id; ?>">Delete</a></td>
                    </tr>
						</tbody>
                        <?php 
                            }
                        }
                        ?>
					  </table>
					</div>
                </div>

					</div>
			   </div>
				<!-- //blank-page -->
			</div>
		</div>
		
        <!--data tables-->
        <script src="js/jquery.min.js"></script>
        <script src="datatables/js/jquery.dataTables.min.js"></script>
        <script src="datatables/js/dataTables.bootstrap.min.js"></script>

        <script>
        $('#table').dataTable();
        </script>
		<?php require('template/footer.inc.php'); ?>