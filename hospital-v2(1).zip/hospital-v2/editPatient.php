<?php require('template/header.inc.php'); ?>
<?php
    if(isset($_GET['p_id'])){
        $id = $_GET['p_id'];
        $id = stripslashes($id);
        $sql = $conn->query("select * from patients where patient_id='$id'");

        $result = $sql->fetch_assoc();
        $p_id = $result['patient_id'];
        $name = $result['name'];
        
        $gender_no = $result['gender'];
        $birthday = $result['birthday'];
        $birth_place = $result['birth_place'];
        $blood_group = $result['blood_group'];
        $marital_status = $result['marital_status'];
        $date = $result['date'];
        $religion = $result['religion'];
        $address = $result['address'];
        $city = $result['city'];
        $country = $result['country'];
        $email = $result['email'];
        $phone_no = $result['phone_no'];
        $details = $result['details'];
        $insurance_company = $result['insurance_company'];
        $insurance_id = $result['insurance_id'];
        $patient_identifiers = $result['patient_indetifiers'];

        $date = date("Y-M-d");
        $age = $date - $birthday;

        if($gender_no == 1){
            $gender = 'Male';
        } else {
            $gender = 'Female';
        }
    }
?>
		<div class="main-grid">
			<div class="agile-grids">	
				<!-- input-forms -->
				<div class="grids">
					<div class="progressbar-heading grids-heading">
						<h2>Edit <i><?php echo $name; ?></i> Details</h2>
					</div>

                    <form class="form-horizontal" action="#" method="post" name="patientForm" id="patientForm">
                        
                        <button type="reset" class="btn btn-warning"><i class="fa fa-trash"></i> Reset</button>
                        <button type="submit" id="submit" class="btn btn-primary"><i class="fa fa-save"></i> Update</button>
                        <br/>
                        <br/>
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#home">Personal Information</a></li>
                            <li><a data-toggle="tab" href="#menu1">Contact Information</a></li>
                            <li><a data-toggle="tab" href="#menu2">Other Information</a></li>
                        </ul>

                        <div class="tab-content">
                            <div id="home" class="tab-pane fade in active">
                                <div class="panel panel-widget forms-panel">
                                    <div class="progressbar-heading general-heading">
                                        <h4>General Form:</h4>
                                    </div>
                                    <div class="forms">
                                            <h3 class="title1"></h3>
                                            <div class="form-three widget-shadow">
                                                <div class="form-group">
                                                    <div class="col-sm-9">
                                                        <input type="hidden" class="form-control1" name="p_id" id="p_id" value="<?php echo $id; ?>" >
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label for="focusedinput" class="col-sm-2 control-label">Patient Name</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control1" name="name" id="name" value="<?php echo $name; ?>">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label for="inputPassword" class="col-sm-2 control-label">Birthday</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" name="birthday" id="birthday" filter="date"  data-invalid="Given value must be a valid date formated as 0000-00-00" value="<?php echo $birthday; ?>">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label for="inputPassword" class="col-sm-2 control-label">Birth Place</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control1" name="birth_place" id="birth_place" value="<?php echo $birth_place; ?>">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label for="selector1" class="col-sm-2 control-label">Gender</label>
                                                    <div class="col-sm-9"><select name="gender" id="gender" class="form-control1">
                                                         <?php 
                                                            if($gender_no != ''){
                                                                echo '<option value="'.$gender_no.'">'.$gender.'</option>';
                                                            } else {
                                                                echo '<option value="">Select gender...</option>';
                                                            }
                                                        ?>
                                                        <option value="1">Male</option>
                                                        <option value="2">Female</option>
                                                    </select></div>
                                                </div>

                                                <div class="form-group">
                                                    <label for="selector1" class="col-sm-2 control-label">Marital Status</label>
                                                    <div class="col-sm-9"><select name="marital_status" id="marital_status" class="form-control1">
                                                     <?php 
                                                        if($marital_status != ''){
                                                            echo '<option value="'.$marital_status.'">'.$marital_status .'</option>';
                                                        } else {
                                                            echo '<option value="">Select marital status...</option>';
                                                        }
                                                    ?>
                                                        <option value="single">Single</option>
                                                        <option value="married">Married</option>
                                                        <option value="divorced">Divorced</option>
                                                    </select></div>
                                                </div>

                                                <div class="form-group">
                                                    <label for="selector1" class="col-sm-2 control-label">Religion</label>
                                                    <div class="col-sm-9"><select name="religion" id="religion" class="form-control1">
                                                    <?php 
                                                        if($religion != ''){
                                                            echo '<option value="'.$religion.'">'.$religion.'</option>';
                                                        } else {
                                                            echo '<option value="">Select religion...</option>';
                                                        }
                                                    ?>
                                                        <option value="christian">Christian</option>
                                                        <option value="muslim">Muslim</option>
                                                    </select></div>
                                                </div>

                                                <div class="form-group">
                                                    <label for="selector1" class="col-sm-2 control-label">Blood group</label>
                                                    <div class="col-sm-9"><select name="blood_group" id="blood_group" class="form-control1">
                                                    <?php 
                                                        if($blood_group != ''){
                                                            echo '<option value="'.$blood_group.'">'.strtoupper($blood_group).'</option>';
                                                        } else {
                                                            echo '<option value="">Select religion...</option>';
                                                        }
                                                    ?>
                                                        <option value="a+">A+</option>
                                                        <option value="a-">A-</option>
                                                        <option value="ab+">AB+</option>
                                                        <option value="ab-">ab-</option>
                                                        <option value="b+">B+</option>
                                                        <option value="b-">B-</option>
                                                        <option value="o+">O+</option>
                                                        <option value="o-">O-</option>
                                                    </select></div>
                                                </div>
                                            </div>
                                    </div>
                                </div>
                            </div>
                            <div id="menu1" class="tab-pane fade">
                                <div class="panel panel-widget forms-panel">
                                    <div class="progressbar-heading general-heading">
                                    </div>
                                    <div class="forms">
                                        <h3 class="title1">Contact Information</h3>
                                        <div class="form-three widget-shadow">
                                            
                                            <div class="form-group">
                                                <label for="inputPassword" class="col-sm-2 control-label">House no.</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control1" name="house_no" id="house_no" value="<?php echo $address; ?>">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputPassword" class="col-sm-2 control-label">City</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control1" name="city" id="city" value="<?php echo $city; ?>">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputPassword" class="col-sm-2 control-label">Phone no</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control1" name="phone_number" id="phone_number" value="<?php echo $phone_no; ?>">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputPassword" class="col-sm-2 control-label">Email</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control1" name="email" id="email" value="<?php echo $email; ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="menu2" class="tab-pane fade">
                                <div class="panel panel-widget forms-panel">
                                    <div class="progressbar-heading general-heading">
                                    </div>
                                    <div class="forms">
                                        <h3 class="title1"></h3>
                                        <div class="form-group">
											<label for="selector1" class="col-sm-2 control-label">Insurance Company</label>
											<div class="col-sm-9"><select name="insurance" id="insurance" class="form-control1">
                                            <?php 
                                                if($insurance_company != ''){
                                                    echo '<option value="'. $insurance_company.'">'. $insurance_company.'</option>';
                                                } else {
                                                    echo '<option>-None-</option>';
                                                }
                                            ?>
												<option value="aar">AAR </option>
												<option value="nhif">NHIF.</option>
											</select></div>
										</div>

                                        <div class="form-group">
											<label for="focusedinput" class="col-sm-2 control-label">Insurance ID number</label>
											<div class="col-sm-9">
												<input type="text" class="form-control1" name="insurance_id" id="insurance_id" value="<?php echo $insurance_company; ?>">
											</div>
										</div>

                                        <div class="form-group">
											<label for="txtarea1" class="col-sm-2 control-label">Patient Identifiers</label>
											<div class="col-sm-9">
                                                <textarea name="patient_indetifiers" id="patient_indetifiers" cols="50" rows="4" class="form-control1"><?php echo $patient_identifiers; ?></textarea>
                                            </div>
										</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
				</div>
				<!-- //input-forms -->
                <script src="js/jquery.min.js"></script>
                <script>
                    $(document).ready(function(){
                        $("#submit").click(function(){
                            // var id = $(this).attr("id");
                            var p_id = $("#p_id").val();
                            var name = $("#name").val();
                            var mname = $("#mname").val();
                            var lname = $("#lname").val();
                            var birthday = $("#birthday").val();
                            var birth_place = $("#birth_place").val();
                            var gender = $("#gender").val();
                            var marital_status = $("#marital_status").val();
                            var religion = $("#religion").val();
                            var blood_group = $("#blood_group").val();
                            var house_no = $("#house_no").val();
                            var city = $("#city").val();
                            var phone_number = $("#phone_number").val();
                            var email = $("#email").val();
                            var insurance = $("#insurance").val();
                            var insurance_id = $("#insurance_id").val();
                            var patient_indetifiers = $("#patient_indetifiers").val();

                            // Returns successful data submission message when the entered information is stored in database.
                            var dataString = 'p_id=' + p_id + '&name='+ name + '&mname='+ mname + '&lname='+ lname + '&birthday='+ birthday+ '&birth_place='+ birth_place + '&gender='+ gender + '&marital_status='+ marital_status + '&religion='+ religion + '&blood_group='+ blood_group + '&house_no='+ house_no + '&city='+ city + '&house_no='+ house_no + '&city='+ city + '&phone_number='+ phone_number + '&email='+ email + '&insurance='+ insurance + '&insurance_id='+ insurance_id + '&patient_indetifiers='+ patient_indetifiers;
                            
                                // AJAX Code To Submit Form.
                                $.ajax({
                                    type: "POST",
                                    url: "edit.php",
                                    data: dataString,
                                    cache: false,
                                    success: function(result){
                                        alert(result);
                                    }
                                });
                            return false;
                        });
                    });
                </script>

			</div>
		</div>
		<?php require('template/footer.inc.php'); ?>