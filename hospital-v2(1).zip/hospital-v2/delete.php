<?php
include('config/db.php');

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $sql = "delete from patients where patient_id = '$id'";
    $result = $conn->query($sql);

    if($result){
        header("Location: patients.php?msg=success");
    } else {
        header("Location: patients.php?msg=error");
    }
}

if(isset($_GET['p_id'])){
    $p_id = $_GET['p_id'];
    $sql = "delete from patients where patient_id = '$p_id'";
    $result = $conn->query($sql);

    if($result){
        header("Location: patients.php?msg=success");
    } else {
        header("Location: patients.php?msg=error");
    }
}

if(isset($_GET['u_id'])){
    $u_id = $_GET['u_id'];
    $sql = "delete from admin where admin_id = '$u_id'";
    $result = $conn->query($sql);

    if($result){
        header("Location: users.php?msg=success");
    } else {
        header("Location: users.php?msg=error");
    }
}
?>