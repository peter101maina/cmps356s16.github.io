<?php
require('config/db.php');
$id = $_GET['p_id'];
    $sql = "update opd SET status=0 WHERE opd_id='".$id."'";
    $res = $conn->query($sql);

    if($res){
        header('Location: out_patient.php?msg=success');
    } else {
        header('Location: out_patient.php?msg=eerror');
    }
?>