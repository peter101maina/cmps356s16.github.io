<?php require('template/header.inc.php'); ?>
		<div class="main-grid">
			<div class="agile-grids">	
				<!-- input-forms -->
				<div class="grids">
					<div class="progressbar-heading grids-heading">
						<h2>Add new patient forms</h2>
					</div>

                    <form class="form-horizontal" action="#" method="post" name="patientForm" id="patientForm">
                        
                        <button type="reset" class="btn btn-warning"><i class="fa fa-trash"></i> Reset</button>
                        <button type="submit" id="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                        <br/>
                        <br/>
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#home">Personal Information</a></li>
                            <li><a data-toggle="tab" href="#menu1">Contact Information</a></li>
                            <li><a data-toggle="tab" href="#menu2">Other Information</a></li>
                        </ul>

                        <div class="tab-content">
                            <div id="home" class="tab-pane fade in active">
                                <div class="panel panel-widget forms-panel">
                                    <div class="progressbar-heading general-heading">
                                        <h4>General Form:</h4>
                                    </div>
                                    <div class="forms">
                                            <h3 class="title1"></h3>
                                            <div class="form-three widget-shadow">
                                                <div class="form-group">
                                                    <label for="focusedinput" class="col-sm-2 control-label">Patient Name</label>
                                                    <div class="col-sm-3">
                                                        <input type="text" class="form-control1" name="fname" id="fname" placeholder="First Name">
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <input type="text" class="form-control1" name="mname" id="mname" placeholder="Middle Name">
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <input type="text" class="form-control1" name="lname" id="lname" placeholder="Last name">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label for="inputPassword" class="col-sm-2 control-label">Birthday</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" name="birthday" id="birthday" filter="date"  data-invalid="Given value must be a valid date formated as 0000-00-00" placeholder="Birthday(0000-00-00)">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label for="inputPassword" class="col-sm-2 control-label">Birth Place</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control1" name="birth_place" id="birth_place" placeholder="Birth place">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label for="selector1" class="col-sm-2 control-label">Gender</label>
                                                    <div class="col-sm-9"><select name="gender" id="gender" class="form-control1">
                                                        <option value="">Select gender...</option>
                                                        <option value="1">Male</option>
                                                        <option value="2">Female</option>
                                                    </select></div>
                                                </div>

                                                <div class="form-group">
                                                    <label for="selector1" class="col-sm-2 control-label">Marital Status</label>
                                                    <div class="col-sm-9"><select name="marital_status" id="marital_status" class="form-control1">
                                                        <option value="">Select marital status...</option>
                                                        <option value="single">Single</option>
                                                        <option value="married">Married</option>
                                                        <option value="divorced">Divorced</option>
                                                    </select></div>
                                                </div>

                                                <div class="form-group">
                                                    <label for="selector1" class="col-sm-2 control-label">Religion</label>
                                                    <div class="col-sm-9"><select name="religion" id="religion" class="form-control1">
                                                        <option value="">Select religion...</option>
                                                        <option value="christian">Christian</option>
                                                        <option value="muslim">Muslim</option>
                                                    </select></div>
                                                </div>

                                                <div class="form-group">
                                                    <label for="selector1" class="col-sm-2 control-label">Blood group</label>
                                                    <div class="col-sm-9"><select name="blood_group" id="blood_group" class="form-control1">
                                                        <option value="">Select blood group...</option>
                                                        <option value="a+">A+</option>
                                                        <option value="a-">A-</option>
                                                        <option value="ab+">AB+</option>
                                                        <option value="ab-">ab-</option>
                                                        <option value="b+">B+</option>
                                                        <option value="b-">B-</option>
                                                        <option value="o+">O+</option>
                                                        <option value="o-">O-</option>
                                                    </select></div>
                                                </div>
                                            </div>
                                    </div>
                                </div>
                            </div>
                            <div id="menu1" class="tab-pane fade">
                                <div class="panel panel-widget forms-panel">
                                    <div class="progressbar-heading general-heading">
                                    </div>
                                    <div class="forms">
                                        <h3 class="title1">Contact Information</h3>
                                        <div class="form-three widget-shadow">
                                            
                                            <div class="form-group">
                                                <label for="inputPassword" class="col-sm-2 control-label">House no.</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control1" name="house_no" id="house_no" placeholder="House no.">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputPassword" class="col-sm-2 control-label">City</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control1" name="city" id="city" placeholder="City/county">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputPassword" class="col-sm-2 control-label">Phone no</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control1" name="phone_number" id="phone_number" placeholder="Phone number">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputPassword" class="col-sm-2 control-label">Email</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control1" name="email" id="email" placeholder="Email">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="menu2" class="tab-pane fade">
                                <div class="panel panel-widget forms-panel">
                                    <div class="progressbar-heading general-heading">
                                    </div>
                                    <div class="forms">
                                        <h3 class="title1"></h3>
                                        <div class="form-group">
											<label for="selector1" class="col-sm-2 control-label">Insurance Company</label>
											<div class="col-sm-9"><select name="insurance" id="insurance" class="form-control1">
												<option>-None-</option>
												<option value="aar">AAR </option>
												<option value="nhif">NHIF.</option>
											</select></div>
										</div>

                                        <div class="form-group">
											<label for="focusedinput" class="col-sm-2 control-label">Insurance ID number</label>
											<div class="col-sm-9">
												<input type="text" class="form-control1" name="insurance_id" id="insurance_id" placeholder="Default Input">
											</div>
										</div>

                                        <div class="form-group">
											<label for="txtarea1" class="col-sm-2 control-label">Patient Identifiers</label>
											<div class="col-sm-9">
                                                <textarea name="patient_indetifiers" id="patient_indetifiers" cols="50" rows="4" class="form-control1"></textarea>
                                            </div>
										</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
				</div>
				<!-- //input-forms -->
                <script src="js/jquery.min.js"></script>
                <script>
                    $(document).ready(function(){
                        $("#submit").click(function(){
                            var fname = $("#fname").val();
                            var mname = $("#mname").val();
                            var lname = $("#lname").val();
                            var birthday = $("#birthday").val();
                            var birth_place = $("#birth_place").val();
                            var gender = $("#gender").val();
                            var marital_status = $("#marital_status").val();
                            var religion = $("#religion").val();
                            var blood_group = $("#blood_group").val();
                            var house_no = $("#house_no").val();
                            var city = $("#city").val();
                            var phone_number = $("#phone_number").val();
                            var email = $("#email").val();
                            var insurance = $("#insurance").val();
                            var insurance_id = $("#insurance_id").val();
                            var patient_indetifiers = $("#patient_indetifiers").val();

                            // Returns successful data submission message when the entered information is stored in database.
                            var dataString = 'fname='+ fname + '&mname='+ mname + '&lname='+ lname + '&birthday='+ birthday+ '&birth_place='+ birth_place + '&gender='+ gender + '&marital_status='+ marital_status + '&religion='+ religion + '&blood_group='+ blood_group + '&house_no='+ house_no + '&city='+ city + '&house_no='+ house_no + '&city='+ city + '&phone_number='+ phone_number + '&email='+ email + '&insurance='+ insurance + '&insurance_id='+ insurance_id + '&patient_indetifiers='+ patient_indetifiers;
                            if(fname==''||birthday==''||gender==''||blood_group==''){
                                alert("Please Fill All Fields required");
                            } else {
                                // AJAX Code To Submit Form.
                                $.ajax({
                                    type: "POST",
                                    url: "add.php",
                                    data: dataString,
                                    cache: false,
                                    success: function(result){
                                        alert(result);
                                    }
                                });
                            }
                            return false;
                        });
                    });
                </script>

			</div>
		</div>
		<?php require('template/footer.inc.php'); ?>