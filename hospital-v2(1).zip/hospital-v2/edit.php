<?php
    //edit.php
    require('config/db.php');

    $p_id = $_POST["p_id"];
    $name = $_POST["name"];
    $mname = $_POST["mname"];
    $lname = $_POST["lname"];
    $birthday = $_POST["birthday"];
    $birth_place = $_POST["birth_place"];
    $gender = $_POST["gender"];
    $marital_status = $_POST["marital_status"];
    $religion = $_POST["religion"];
    $blood_group = $_POST["blood_group"];
    $house_no = $_POST["house_no"];
    $city = $_POST["city"];
    $phone_number = $_POST["phone_number"];
    $email = $_POST["email"];
    $insurance = $_POST["insurance"];
    $insurance_id = $_POST["insurance_id"];
    $patient_indetifiers = $_POST["patient_indetifiers"];


    $sql = "UPDATE `patients` SET `name`='$name',`gender`='$gender',`birthday`='$birthday',`birth_place`='$birth_place',`marital_status`='$marital_status',
    `religion`='$religion',`blood_group`='$blood_group',`address`='$house_no',`city`='$city',`country`='Kenya',`email`='$email',`phone_no`='$phone_number',`details`='',
    `insurance_company`='$insurance',`insurance_id`='$insurance_id',`patient_indetifiers`='$patient_indetifiers' WHERE patient_id='$p_id' ";
    $result = $conn->query($sql);

    if($result){
        echo 'Success in editing the patient details';
    } else {
        echo 'Error: '. $conn->error;
    }
?>