<?php
    //add.php
    require('config/db.php');

    $fname = $_POST["fname"];
    $mname = $_POST["mname"];
    $lname = $_POST["lname"];
    $birthday = $_POST["birthday"];
    $birth_place = $_POST["birth_place"];
    $gender = $_POST["gender"];
    $marital_status = $_POST["marital_status"];
    $religion = $_POST["religion"];
    $blood_group = $_POST["blood_group"];
    $house_no = $_POST["house_no"];
    $city = $_POST["city"];
    $phone_number = $_POST["phone_number"];
    $email = $_POST["email"];
    $insurance = $_POST["insurance"];
    $insurance_id = $_POST["insurance_id"];
    $patient_indetifiers = $_POST["patient_indetifiers"];

    $name = $fname.' '.$mname.' '.$lname;
    date_default_timezone_set('Africa/Nairobi');
    $date = date("Y-m-d h:i:sa");
    $sql = "insert into patients
    (`name`, `gender`, `birthday`, `birth_place`, `marital_status`, `religion`, `blood_group`, `address`, `city`, `country`, `email`, `phone_no`, `details`, `insurance_company`, `insurance_id`, `patient_indetifiers`, date)
    VALUES ('$name', '$gender', '$birthday', '$birth_place', '$marital_status', '$religion', '$blood_group', '$house_no', '$city', 'Kenya', '$email', '$phone_number', '',' $insurance', '$insurance_id', '$patient_indetifiers', '$date')";

    $result = $conn->query($sql);

    if($result){
        echo 'Success in adding the patient';
    } else {
        echo 'Error: '. $conn->error;
    }
?>