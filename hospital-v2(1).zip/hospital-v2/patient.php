<?php require('template/header.inc.php'); ?>
<?php
    if(isset($_GET['id'])){
        $id = $_GET['id'];
        $id = stripslashes($id);
        $sql = $conn->query("select * from patients where patient_id='$id'");

        $result = $sql->fetch_assoc();
        $p_id = $result['patient_id'];
        $name = $result['name'];
        
        $gender = $result['gender'];
        $birthday = $result['birthday'];
        $birth_place = $result['birth_place'];
        $blood_group = $result['blood_group'];
        $marital_status = $result['marital_status'];
        $date = $result['date'];
        $religion = $result['religion'];
        $address = $result['address'];
        $city = $result['city'];
        $country = $result['country'];
        $email = $result['email'];
        $phone_no = $result['phone_no'];
        $details = $result['details'];
        $insurance_company = $result['insurance_company'];
        $insurance_id = $result['insurance_id'];
        $patient_identifiers = $result['patient_indetifiers'];

        $date = date("Y-M-d");
        $age = $date - $birthday;

        if($gender == 1){
            $gender = 'Male';
        } else {
            $gender = 'Female';
        }
    }
?>
		<div class="main-grid">
			<div class="agile-grids">	
				<!-- input-forms -->
				<div class="grids">
					<div class="progressbar-heading grids-heading">
						<h2><?php echo $name; ?> Details</h2>
					</div>

                    <!--<form class="form-horizontal" action="#" method="post" name="patientForm" id="patientForm">-->
                        
                        <a href="patients.php" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Back</a>
                        <a href="delete.php?p_id=<?php echo $p_id; ?>" class="btn btn-warning"><i class="fa fa-trash"></i> Delete Patient</a>
                        <a href="editPatient.php?p_id=<?php echo $p_id; ?>" class="btn btn-primary"><i class="fa fa-edit"></i> Edit Patient</a>
                        <br/>
                        <br/>
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#home">Personal Information</a></li>
                            <li><a data-toggle="tab" href="#menu1">Contact Information</a></li>
                            <li><a data-toggle="tab" href="#menu2">Other Information</a></li>
                            <!--<li><a data-toggle="tab" href="#menu3">Add attachments</a></li>-->
                        </ul>

                        <div class="tab-content">
                            <div id="home" class="tab-pane fade in active">
                                <div class="panel panel-widget forms-panel">
                                    <div class="forms">
                                        <div class="form-three widget-shadow">
                                            <div class="form-group">
                                                <label for="patient_name">Name: <b><?php echo $name; ?></b></label>
                                            </div>
                                            <div class="form-group">
                                                <label for="patient_id">Patient ID: <b><?php echo $id; ?></b></label>
                                            </div>
                                            <div class="form-group">
                                                <label for="age">Age: <b><?php echo $age; ?></b></label>
                                            </div>
                                            <div class="form-group">
                                                <label for="birthday">Birthday: <b><?php echo $birthday; ?></b></label>
                                            </div>
                                            <div class="form-group">
                                                <label for="gender">Gender: <b><?php echo $gender; ?></b></label>
                                            </div>
                                            <div class="form-group">
                                                <label for="blood_group">Blood Group: <b><?php echo strtoupper($blood_group); ?></b></label>
                                            </div>
                                            <div class="divider"></div>
                                            <div class="form-group">
                                                <label for="religion">Religion: <b><?php echo $religion; ?></b></label>
                                            </div>
                                            <div class="form-group">
                                                <label for="marital_status">Marital Status: <b><?php echo $marital_status; ?></b></label>
                                            </div>
                                            <div class="form-group">
                                                <label for="birthplace">Birthplace: <b><?php echo $birth_place; ?></b></label>
                                            </div>
                                        </div>
                                    </div>                       
                                </div>
                            </div>
                            <div id="menu1" class="tab-pane fade">
                                <div class="panel panel-widget forms-panel">
                                    <div class="forms">
                                        <div class="form-three widget-shadow">
                                            <div class="form-group">
                                                <label for="phone_no">Phone: <b><?php echo $phone_no; ?></b></label>
                                            </div>
                                            <div class="form-group">
                                                <label for="email">Email: <b><?php echo $email; ?></b></label>
                                            </div>
                                            <div class="form-group">
                                                <label for="address">Adress: <b><?php echo $address; ?></b></label>
                                            </div>
                                            <div class="form-group">
                                                <label for="city">City: <b><?php echo $city; ?></b></label>
                                            </div>
                                            <div class="form-group">
                                                <label for="country">Country: <b><?php echo $country; ?></b></label>
                                            </div>
                                            <div class="form-group">
                                                <label for="details">Details: <b><?php echo $details; ?></b></label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="menu2" class="tab-pane fade">
                                <div class="panel panel-widget forms-panel">
                                    <div class="forms">
                                        <div class="form-three widget-shadow">
                                            <div class="form-group">
                                                <label for="insurance">Insurance Company: <b><?php echo $insurance_company; ?></b></label>
                                            </div>
                                            <div class="form-group">
                                                <label for="insurance_id">Insurance ID: <b><?php echo $insurance_id; ?></b></label>
                                            </div>
                                            <div class="form-group">
                                                <label for="personal">Patient Identifiers: <b><?php echo $patient_identifiers; ?></b></label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                           <!-- <div id="menu3" class="tab-pane fade">
                                <div class="panel panel-widget forms-panel">
                                    
                                </div>
                            </div> -->
                        </div>
                    <!--</form>-->
				</div>
			</div>
		</div>
		<?php require('template/footer.inc.php'); ?>