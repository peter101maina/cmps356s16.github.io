/**
 * Created by esraamohamed on 4/25/16.
 */
'use strict'

class TeacherRepository {
    constructor() {
        this.fs = require('fs');
    }

    //Read a file and convert its content to a json object
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }

    checkTeacher(teacher) {
        let result;
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(teachers => {
                teachers = teachers.filter(t => t.username === teacher.username && t.password === teacher.password);
                if (teachers.length > 0) {
                    result = "teacher";
                }
                else {
                    result = "not found";
                }
                //  console.log(result);
                resolve(result);
                reject("error");
            });
        });
    }

    getStudents() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(students => {
                // Only return the student Id and names\
                let studentList=[];
                for(let student of students){
                    for(let oneStu of student.students){
                        studentList.push(oneStu);
                    }
                }
                resolve(studentList);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getStudentsList(teacherId) {
        return new Promise((resolve, reject) => {
            this.getStudentsTeacher(teacherId).then(students => {
                //   console.log(students);
                students = students.map(s => {
                    return {
                        studentId: s.studentId,
                        name: `${s.studentId} - ${s.firstName} ${s.lastName}`
                    }
                });
                resolve(students);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getStudentsTeacher(teacherId) {
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
              //  console.log(students);
                students = students.filter(s => s.teacherId === teacherId);
                resolve(students);
            }).catch(err => {
                reject(err);
            });
        });
    }

    fetchTeacher(username) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(teachers => {
                teachers = teachers.filter(s => s.username === username);
                if (teachers.length > 0) {
                    delete teachers[0].password;
                    resolve(teachers[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getAllTasks(student) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(tasks => {
                tasks = tasks.filter(t => t.studentId === student.studentId);
                if (tasks.length > 0) {
                    student.tasks = tasks;
                    resolve(student);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }


    getStudent(studentId){
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                students = students.filter(t => t.studentId === studentId);
                return this.getAllTasks(students[0]);
            }).then(student => {
                resolve(student);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getPendingTasks(student) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(tasks => {
                tasks = tasks.filter(t => t.studentId === student.studentId && t.hasOwnProperty("masteryLevel") === false);
                if (tasks.length > 0) {
                    student.tasks = tasks;
                    resolve(student);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }


    getStudentPending(studentId){
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                students = students.filter(t => t.studentId === studentId);
                return this.getPendingTasks(students[0]);
            }).then(student => {
                resolve(student);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getFinishedTasks(student) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(tasks => {
                tasks = tasks.filter(t => t.studentId === student.studentId && t.hasOwnProperty("masteryLevel") === true);
                if (tasks.length > 0) {
                    student.tasks = tasks;
                    resolve(student);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }


    getStudentFinished(studentId){
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                students = students.filter(t => t.studentId === studentId);
                return this.getFinishedTasks((students[0]));
            }).then(student => {
                resolve(student);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getTasks() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(tasks => {
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }

    deleteTask(taskId) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(tasks => {
                //  console.log(requests);
                // Look for the hero to be deleted then remove it
                let len = tasks.length;
                let foundAt = -1;
                for (let i = 0; i < len; i++) {
                    if (tasks[i].taskId == taskId) {
                        foundAt = i;
                        break;
                    }
                }
                if (foundAt >= 0) {
                    tasks.splice(foundAt, 1);
                }
                // console.log(requests);

                //Save the heros back to the file
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(() => {
                resolve();
            }).catch(err => {
                reject(err);
            });
        });
    }

    getSurahs() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/surah.json').then(surahs => {
                //Only return the student Id and names
                surahs = surahs.map(s => {
                    return {
                        id: s.id,
                        name: `${s.id}. ${s.englishName} (${s.ayaCount} Aya)`
                    }
                });
                resolve(surahs);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getSaurah(id) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/surah.json').then(surahs => {
                //Only return the student Id and names
                surahs = surahs.filter(s => s.id === id);
                if (surahs.length > 0) {
                    resolve(surahs[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getMessages() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/message.json').then(messages => {
                resolve(messages);
            }).catch(err => {
                reject(err);
            });
        });
    }
    addMessage(message) {
      //  console.log(message);
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                //Get the last Id used +1
                let maxId = Math.max.apply(Math, messages.map(m => m.messageId)) + 1;
                console.log("maxId", maxId);

                message.messageId = maxId;

                console.log("Message.addMessage", message);
                messages.push(message);
                return this.writeJsonFile('./data/message.json', messages);
            }).then(()=> resolve(message))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    completeTask(task) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let len = tasks.length;
                for(let i=0; i<len; i++){
                    if (tasks[i].taskId == task.taskId) {
                        tasks[i].completedDate = task.completedDate;
                        tasks[i].masteryLevel = task.masteryLevel;
                        tasks[i].comment = task.comment;
                        break;
                    }
                }
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(()=> resolve())
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    fetchTask(taskId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks = tasks.filter(t => t.taskId === taskId);
                if (tasks.length > 0) {
                    resolve(tasks[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    addTask(task) {
        //  console.log(message);
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                //Get the last Id used +1
                let maxId = Math.max.apply(Math, tasks.map(m => m.taskId)) + 1;
                console.log("maxId", maxId);

                task.taskId = maxId;

                console.log("Message.addMessage", task);
                tasks.push(task);
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(()=> resolve(task))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
//    "completedDate": "02/04/2016",
//    "masteryLevel": "Excellent",
//    "comment": "Excellent work"
    updateTask(task) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let len = tasks.length;
                for(let i=0; i<len; i++){
                    if (tasks[i].taskId == task.taskId) {
                        tasks[i].surahId = task.surahId;
                        tasks[i].surahName = task.surahName;
                        tasks[i].fromAya = task.fromAya;
                        tasks[i].toAya = task.toAya;
                        tasks[i].type = task.type;
                        tasks[i].dueDate = task.dueDate;
                        break;
                    }
                }
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(()=> resolve())
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }




//    let students = JSON.parse(fileData);
//    //This will return array of arrays!
//    let studentArrays = students.map(s => {
//    return s.students;
//});
//
//    //Using ES2015 spread operator to flatten multidimensional studentArrays
//    students = [].concat(...studentArrays);
//    console.log(students);
//}
//});

}

module.exports = new TeacherRepository();