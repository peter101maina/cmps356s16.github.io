'use strict'
class ParentController {
    constructor() {
        this.Parentrepository = require('./ParentRepository');
    }

    getAnnouncement(req,res){
        this.Parentrepository.getAnnouncement().then(ann => {
            //console.log(JSON.stringify(ann, null, 2));
            res.json(ann);
        }).catch(err => {
            res.status(404).send("Failed :" + err);

        });
    }

    getStudents(req,res){

        this.Parentrepository.getStudents().then(stu => {
            console.log(JSON.stringify(stu, null, 2));
            res.json(stu);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    getTestParents(req,res){
        //let username = req.params.id;
        //console.log('req.params.id', username);
        this.Parentrepository.getParents().then(parents => {
            //console.log(JSON.stringify(staff, null, 2));
            res.json(parents[0]);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }
    getTaskByStudent(req,res){
        let id=parseInt(req.params.id);
        console.log("Student id=" +id);
        this.Parentrepository.getTaskBySID(id).then(tasks => res.json(tasks)).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    getParent(req, res){
    let username = (req.params.username);
        console.log('req.params.id', username);
        this.Parentrepository.getParent(username).then(parent => {
            console.log(JSON.stringify(parent, null, 2));
            res.json(parent);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
}
    
}

module.exports = new ParentController();