/**
 * Created by esraamohamed on 4/25/16.
 */
'use strict'
//When the document is loaded in the browser then fill the students dropdown.
$(document).ready(function () {
    let user = JSON.parse(localStorage.user);
    console.log("$(document).ready.user", user);

    $("#msg").hide();
    $("#status").hide();
    $("#taskStatus").hide();
    $("#add").hide();

    getTeacher(user.username).then(teacher => {
        // displayStudent(student);
        let fname = teacher.firstName;
        let lname = teacher.lastName;
        let fullname = fname + " " + lname;
        $('#username').html(fullname);

        getStudents(teacher.staffNo).then(students => fillStudentsDD(students))
            .catch(err => console.log(err));

        $("#studentList").on('change', onStudentChange);
    }).catch(err => console.log(err));

    $("#taskStatus").on('change', onStatusChange);
    //  $('#surahChange').on('change', onSurahChange);
    $('#tasks-details').on('click', 'a.deleteButton', deleteTask);
    $('#tasks-details').on('click', 'a.completeButton', complete);

});

function getTeacher(username) {
    let url = `http://localhost:9080/api/teacher/${username}`;
    return fetch(url).then(response => response.json());
}

function getStudents(teacherId) {
    let url = `http://localhost:9080/api/students/${teacherId}`;
    return fetch(url).then(response => response.json());
}


function getStudentTasks(studentId) {
    let url = `http://localhost:9080/api/studentTasks/${studentId}`;
    return fetch(url).then(response => response.json());
}

function getTasksFinished(studentId) {
    let url = `http://localhost:9080/api/studentTasksFinished/${studentId}`;
    return fetch(url).then(response => response.json());
}
function getTasksPending(studentId) {
    let url = `http://localhost:9080/api/studentTasksPending/${studentId}`;
    return fetch(url).then(response => response.json());
}

function getSurahs() {
    let url = "http://localhost:9080/api/surahs";
    return fetch(url).then(response => response.json());
}

function getSurah(id) {
    let url = `http://localhost:9080/api/surah/${id}`;
    return fetch(url).then(response => response.json());
}

function fetchTask(taskId) {
    let url = `http://localhost:9080/api/tasks/${taskId}`;
    return fetch(url).then(response => response.json());
}

function fillStudentsDD(students) {
    for (let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.name
        }).appendTo($("#studentList"))
    }
}

function onStudentChange() {
    $("#msg").show();
    $("#status").show();
    $("#taskStatus").show();
    $("#add").show();
    let selectedStudentId = $(this).val();
//here i should get all tasks for one student getAllTasks(studentId)  --> student.tasks = ttt
    getTasksPending(selectedStudentId).then(student => {
        displayTasks(student);
    }).catch(err => console.log(err));
}


function displayTasks(student) {

    $('#tasks-details').empty();
    let htmlTemplate = $('#tasks-template').html(),
        tasksTemplate = Handlebars.compile(htmlTemplate)

    console.log('tasksTamplete(student)', tasksTemplate(student));

    $('#tasks-details').html(tasksTemplate(student));
}

function onStatusChange() {
    let user = JSON.parse(localStorage.user);
    let studentId = $('#stu').attr('data-studentId');
    let selectedStatus = $(this).val();

    //Pending requests
    if (selectedStatus === "Pending") {
        getTasksPending(studentId).then(student => {
            displayTasks(student);
        });
    }
    //only decided requests
    else if (selectedStatus === "Finished") {
        getTasksFinished(studentId).then(student => {
            displayTasks(student);
        });
    }
    //all requests
    else {
        getStudentTasks(studentId).then(student => {
            displayTasks(student);
        });
    }
}

function deleteTask(event) {
    let user = JSON.parse(localStorage.user);
    event.preventDefault();
    //let username = user.username;
    console.log("your username is correct");
    console.log(username);
    //Prevent the default browser behavior when a link is clicked

    // Ask the user to confirm. If they cancel the request then exit this function
    if (!confirm('Confirm delete?')) {
        return;
    }

    let taskId = $(this).attr('data-taskId');
    //   console.log("deleteHero.heroId: ", heroId);

    let url = `http://localhost:9080/api/tasks/${taskId}`;
    //   console.log("deleteHero.heroId", heroId);
    fetch(url, {method: 'delete'}).then(() => {

        $(this).closest('tr').remove();
    }).then(() => {
        //After delete then refresh the list
        let studentId = $('#stu').attr('data-studentId');
        getTasksPending(studentId).then(student => {
            displayTasks(student);
        });
    });
}

function addTask() {

    let htmlTemplate = $('#task-form-template').html(),
        taskTemplate = Handlebars.compile(htmlTemplate);


    getSurahs().then(surahs => {
        fillSurahsDD(surahs)
    }).catch(err => console.log(err));


    $('#task-form').html(taskTemplate({}));
    let today = new Date();
    let dd = today.getDate() + 1;
    let mm = today.getMonth() + 1;
    let yyyy = today.getFullYear();

    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    today = yyyy + '-' + mm + '-' + dd;
    $('#dueDate').val(today);

    showFormAsModel();
}

function fillSurahsDD(surahs) {
    for (let surah of surahs) {
        $("<option>", {
            value: surah.id,
            text: surah.name
        }).appendTo($("#surahChange"))
    }
}

function updateTask(taskId) {
    console.log("in update task");
    console.log("taskId", taskId);

    fetchTask(taskId).then(task => {
        console.log(task);

        let htmlTemplate = $('#task-form-template').html(),
            taskTemplate = Handlebars.compile(htmlTemplate);

        getSurahs().then(surahs => {
            fillSurahsDD(surahs)
        }).catch(err => console.log(err));

        getSurah(task.surahId).then(surah => {

            $('#surahChange').val(surah.surahName);
            console.log(surah);
            $('#fromAya').attr("min", 1);
            let ayah = parseInt(surah.ayaCount);
            ayah = ayah-1;
            $('#fromAya').attr("max", ayah);

            $('#selectedV').val(task.fromAya);
            $('#selectedValue').val(task.toAya);
            let fromVal;
            $(".slider").on("change", function () {
                fromVal = this.value;
                console.log(fromVal);
                $('#toAya').attr("max", parseInt(surah.ayaCount));

            });

            $(".slider").on("input", function(){

                let vall = parseInt(this.value);
               // vall = vall+1;
                $('#selectedValue').val(vall);
                $('#toAya').attr("min", vall);
                console.log(this.value)
            });
        }).catch(err => console.log(err));

        //let day = task.dueDate.substring()

        $('#task-form').html(taskTemplate(task));

        let dueDate = new Date(task.dueDate.substring(6, 10),task.dueDate.substring(3, 5)-1,task.dueDate.substring(0, 2));
        console.log("date updated");
        let dd = dueDate.getDate();
        let mm = dueDate.getMonth() + 1;
        let yyyy = dueDate.getFullYear();
        if (dd < 10) {
            dd = '0' + dd;
        }
        if (mm < 10) {
            mm = '0' + mm;
        }
        dueDate = yyyy + '-' + mm + '-' + dd;
        console.log(dueDate);
        $('#dueDate').val(dueDate);

        if(task.type === "Revision")
            $('input:radio[name="taskType"]').filter('[value="Revision"]').attr('checked', true);
        else
            $('input:radio[name="taskType"]').filter('[value="Memorization"]').attr('checked', true);

        //$("<option>", {
        //    value: task.surahId,
        //    text: task.surahName
        //}).val($("#surahChange"))
        //value: surah.id,
        //    text: surah.name
        //

        //$('#surahChange').append($('<option>', {
        //    value: task.surahId,
        //    text: task.surahName
        //}));

        console.log(task.surahName);
        console.log("check now");
      //  $('#surahChange options[value=3]).attr('selected', 'selected');
      //  $('#surahChange option').get(3).selected = true;
       // $('#surahChange option')[3].checked = true;
       // $('#surahChange').get(3).attr('selected', 'selected');
        //Select the heroType in the Dropdown
        //${s.id}. ${s.englishName} (${s.ayaCount} Aya)


        //$("#surahChange option[value='3. Aal-e-Imran (200 Aya)']").prop('selected', true);
        //$('#surahChange').option(task.surahName);
        //$('#surahChange').val(10);
        //console.log($('#opt').val());
        console.log("surah change");
        //$("surahChange[value='10']").attr('selected','selected');
        //console.log($('#surahChange').text());
        console.log($('#surahChange').val());

        showFormAsModel();

    }).catch(err => console.log(err));
}

function showFormAsModel() {
    let taskForm = $("#task-form").dialog({
        height: 500,
        width: 550,
        title: 'Task Form',
        modal: true,
        buttons: {
            "Submit": function () {
                saveTask();
                taskForm.dialog("close");
            },
            Cancel: function () {
                taskForm.dialog("close");
            }
        }
    });
}

function saveHero() {
    let hero = {
        name: $('#name').val(),
        heroType: $('#heroType').val(),
        quote: $('#quote').val()
    };

    let url = "http://localhost:9080/api/heroes/";
    let requestMethod = "post";

    let heroId = $('#heroId').val();

    //In case of update make the method put and append the id to the Url
    if (heroId != '') {
        hero.id = parseInt(heroId);
        url += heroId;
        requestMethod = "put";
    }

    console.log("saveHero.heroId", heroId);

    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(hero)
    }).then(() => {
        //After add/update then refresh the list
        getHeroes();
    });
}
function saveTask() {

    console.log("in save task");

    let studentId = parseInt($('#stu').attr('data-studentId'));
    console.log(studentId);

    let taskType = document.querySelector('input[name="taskType"]:checked').value;
    console.log(taskType);

    let surahId = parseInt($('#surahChange').val());
    console.log(surahId);

    let suraName;

    getSurah(parseInt(surahId)).then(surah => {
        console.log(surah);
        suraName = surah.englishName;
        console.log(suraName)


        let fromAya = parseInt($('#fromAya').val());
        console.log(fromAya);

        let toAya = parseInt($('#toAya').val());
        console.log(toAya);

        let dueDate = $('#dueDate').val();
        let dat = new Date(dueDate);
        console.log(dueDate);
        console.log(dat);

        let dd = dat.getDate();
        let mm = dat.getMonth() + 1;
        let yyyy = dat.getFullYear();
        if (dd < 10) {
            dd = '0' + dd;
        }
        if (mm < 10) {
            mm = '0' + mm;
        }
        let datt = dd + '/' + mm + '/' + yyyy;

        let task = {
            studentId: studentId,
            surahId: surahId,
            surahName: suraName,
            fromAya: fromAya,
            toAya: toAya,
            type: taskType,
            dueDate: datt
        };

        let url = "http://localhost:9080/api/newTask/";
        let requestMethod = "post";

         let taskId = $('#taskId').val();
        console.log(taskId);

        //In case of update make the method put and append the id to the Url
        if (taskId != '') {
            task.taskId = parseInt(taskId);
            url += taskId;
            requestMethod = "put";
        }

          console.log("saveTask.taskId", url);

        fetch(url, {
            method: requestMethod,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(task)
        }).then(() => {
            //After add/update then refresh the list
            getTasksPending(studentId).then(student => {
                displayTasks(student);
            });
        });
    });
}

function onSurahChange() {
    //let user = JSON.parse(localStorage.user);
    //let studentId =  $('#stu').attr('data-studentId');
    console.log("on surah change");

    let selectedSurah = parseInt($('#surahChange').val());
    console.log(selectedSurah);


    getSurah(selectedSurah).then(surah => {

        console.log(surah);
        $('#fromAya').attr("min", 1);
        let ayah = parseInt(surah.ayaCount);
        ayah = ayah-1;
        $('#fromAya').attr("max", ayah);

        let fromVal;
        $(".slider").on("change", function () {
            fromVal = this.value;
            console.log(fromVal);
            $('#toAya').attr("max", parseInt(surah.ayaCount));

        });

          $(".slider").on("input", function(){

              let vall = parseInt(this.value);
            //  vall = vall+1;
              $('#selectedValue').val(vall);
              $('#toAya').attr("min", vall);
              console.log(this.value);
          });


    }).catch(err => console.log(err));

}

function sendMsg() {

    let htmlTemplate = $('#message-template').html(),
        msgTemplate = Handlebars.compile(htmlTemplate);

    $('#msg-form').html(msgTemplate({}));

    //let today = moment().format('YYYY-MM-DD');
    //$('#dueDate').val(today);
    showMsgAsModel();
}


function showMsgAsModel() {
    let messageForm = $("#msg-form").dialog({
        height: 350,
        width: 550,
        title: 'Message Form',
        modal: true,
        buttons: {
            "Send": function () {
                saveMessage();
                alert("The message is sent successfully");
                messageForm.dialog("close");
            },
            Cancel: function () {
                messageForm.dialog("close");
            }
        }
    });
}
function saveMessage() {

    let today = new Date();
    let dd = today.getDate();
    let mm = today.getMonth() + 1;
    let yyyy = today.getFullYear();

    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    today = mm + '/' + dd + '/' + yyyy;

    let message = {
        studentId: parseInt($('#stu').attr('data-studentId')),
        messageDate: today,
        body: $('#body').val(),
        attachment: ""
    };

    let url = "http://localhost:9080/api/message/";

    //In case of update make the method put and append the id to the Url

    // console.log("saveMessage.messageId", messageId);

    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(message)
    }).then(() => {
        console.log("Done");
    });
}

function complete(taskId) {
    console.log("taskId", taskId);

    fetchTask(taskId).then(task => {
        console.log(task);

        let htmlTemplate = $('#complete-template').html(),
            completeTemplate = Handlebars.compile(htmlTemplate);

        $('#complete-form').html(completeTemplate(task));
        $('#masteryLevel').val(task.masteryLevel);
        let today = new Date();
        let dd = today.getDate();
        let mm = today.getMonth() + 1;
        let yyyy = today.getFullYear();

        if (dd < 10) {
            dd = '0' + dd;
        }
        if (mm < 10) {
            mm = '0' + mm;
        }
        today = yyyy + '-' + mm + '-' + dd;

        //  document.getElementById('compDate').innerHTML=today;
        $('#compDate').val(today);

        showCompleteModel();

    }).catch(err => console.log(err));
}


function showCompleteModel() {
    let completeForm = $("#complete-form").dialog({
        height: 450,
        width: 550,
        title: 'Complete Form',
        modal: true,
        buttons: {
            "Submit": function () {
                saveComplete();
                completeForm.dialog("close");
            },
            Cancel: function () {
                completeForm.dialog("close");
            }
        }
    });
}

function saveComplete() {

    let compDate = $('#compDate').val();
    let dat = new Date(compDate);
    console.log(compDate);
    console.log(dat);

    let dd = dat.getDate();
    let mm = dat.getMonth() + 1;
    let yyyy = dat.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    let datt = dd + '/' + mm + '/' + yyyy;


    let taskId = $('#task').val();
    console.log(taskId);
    let task = {
        taskId: parseInt(taskId),
        completedDate: datt,
        masteryLevel: $('#masteryLevel').val(),
        comment: $('#comment').val()
    };

    let url = "http://localhost:9080/api/task/";
    url += taskId;


    //In case of update make the method put and append the id to the Url

    // console.log("saveMessage.messageId", messageId);

    fetch(url, {
        method: "put",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(task)
    }).then(() => {
        console.log("Done");
        let studentId = $('#stu').attr('data-studentId');
        getTasksPending(studentId).then(student => {
            displayTasks(student);
        });
    });
}
