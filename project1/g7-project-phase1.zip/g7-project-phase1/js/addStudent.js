'use strict'

    
function getParent() {
    let url = "http://localhost:9080/api/parents";
    return fetch(url).then(response => response.json());
}

function fillParentDD(parents) {
    console.log(parents);
    for (let parent of parents) {
        $("<option>", {
            value: parent.qatariId,
            text: parent.fullname
        }).appendTo($("#parent-list"))
    }
}

function addParent(){
    let htmlTemplate = $('#parent-form-template').html(),
        parentTemplate = Handlebars.compile(htmlTemplate);
    
    $('#parentForm').html(parentTemplate({}));
    showParentFormAsModel();
}

function showParentFormAsModel() {
    let parentForm = $( "#parentForm" ).dialog({
        height: 450,
        width: 750,
        title: 'Parent Form',
        modal: true,
        buttons: {
            "Submit": function() {
                saveParent();
                parentForm.dialog( "close" );
            },
            Cancel: function() {
                parentForm.dialog( "close" );
            }
        }
    });
}

function saveParent() {
    let parent = {
        qatariId: $('#qatariId').val(),
        firstName: $('#pfirstName').val(),
        lastName: $('#plastName').val(),
        mobile: $('#mobile').val(),
        email: $('#email').val(),
        username: $('#pusername').val(),
        password: $('#password').val(),
        students:[]
    };

    let url = "http://localhost:9080/api/addParent/";
     let requestMethod = "post";
    
     fetch(url, {
     method: requestMethod,
     headers: {
     "Content-Type": "application/json"
     },
     body: JSON.stringify(parent)
     }).then(() => {
        console.log("add parent is done ")
     });
}

function getTeacher() {
    let url = "http://localhost:9080/api/teachers";
    return fetch(url).then(response => response.json());
}

function fillTeacherDD(teachers) {
    console.log(teachers);
    for (let teacher of teachers) {
        $("<option>", {
            value: teacher.teacherId,
            text: teacher.name +"-" +teacher.halaqa
        }).appendTo($("#teacher-list"))
    }
}

function addChild() {
    let htmlTemplate = $('#child-form-template').html(),
        childTemplate = Handlebars.compile(htmlTemplate);

    getParent().then(parents => {
        // console.log(parents);
        fillParentDD(parents)

    }).catch(err => console.log(err));

    getTeacher().then(teachers => {
        fillTeacherDD(teachers)
    }).catch(err => console.log(err));
 
    $('#childForm').html(childTemplate({}));
    showChildFormAsModel();
}

function showChildFormAsModel() {
    let childForm = $( "#childForm" ).dialog({
        height: 450,
        width: 750,
        title: 'child Form',
        modal: true,
        buttons: {
            "Submit": function() {
                saveChild();
                alert("The student has been added successfully");
                childForm.dialog( "close" );
            },
            Cancel: function() {
                childForm.dialog( "close" );
            }
        }
    });
}

function saveChild() {
    let child = {
            firstName: $('#firstName').val(),
            dob: $('#dob').val(),
            schoolGrade: $('#schoolGrade').val(),
            teacherId: $('#teacher-list').val()
    };

    let gender=document.querySelector('input[name="gender"]:checked').value;
    if(gender==="female"){
        child.gender='F'
    }else{
        child.gender='M'
    }

        let parentId;
    let selectType=document.querySelector('input[name="parent"]:checked').value;
    console.log(selectType)
    if(selectType==="parentList"){
        parentId=parseInt($('#parent-list').val());
        console.log("in the parentList"+parentId)
        // getParent().then(parents=>{
        //     console.log(parents)
        //     parents=parents.filter(p=>p.qatariId===parentId);
        //     child.lastName=parents[0].lastname;
        //     console.log(child);
        // });
        child.parentId=parentId;
        console.log(child);

    }else if(selectType==="newParent") {
        parentId = $('#qatariId').val();
        console.log("in the new parent " + parentId)
        child.parentId = parentId;
        // child.lastName=$('#plastName')
        console.log(child);
    }
    let url = `http://localhost:9080/api/addStudents/`;
     let requestMethod = "post";

     fetch(url, {
     method: requestMethod,
     headers: {
     "Content-Type": "application/json"
     },
     body: JSON.stringify(child)
     }).then(() => {
         console.log("Done");
         // if (confirm('The student has been added')) {
         //     return;
         // }
     });

}

