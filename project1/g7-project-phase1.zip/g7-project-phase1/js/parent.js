
'use strict';
//When the document is loaded in the browser then fill the students dropdown.
let currentParent;
$(document).ready(function(){
    $('#showMessages').hide();
    $('#showTasks').hide();

    // getStudents().then(students => fillStudentsDD(students))
    //     .catch(err => console.log(err));
    let user = JSON.parse(localStorage.user);
    console.log(user);
    $("#progressStatus").on('change', updateDisplay);

    if (localStorage.user) {
    }
    getParent(user.username).then(p=> {
        currentParent = p;
        $("#username").text(currentParent.firstName + " " + currentParent.lastName);

        fillChildrenDD( currentParent.students);


        $("#myChildren").on('change', updateDisplay);
        showStudentsTasks();
    });

    showAnn();
});

function fillChildrenDD(students) {
    for(let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName
        }).appendTo($("#myChildren"))
    }
}

function updateDisplay() {
    let stuId = parseInt($("#myChildren").val());
    let choice= $("#progressStatus").val();
    $('#showMessages').show();
    $('#showTasks').show();

    showStudentsTasks(stuId);
}

function getStudents() {
    let url = "http://localhost:9080/api/students";
    return fetch(url).then(response => response.json());
}

function getStudent(studentId) {
    let url = `http://localhost:9080/api/students/${studentId}`;
    return fetch(url).then(response => response.json());
}

function fetchParents() {
    let url = `http://localhost:9080/api/students`;
    return fetch(url).then(response => response.json());
}

function fetchMessages() {
    let url = `http://localhost:9080/api/massages`;
    return fetch(url).then(response => response.json());
}

function getParentMessages (qId)
{
    return new Promise((resolve, reject) => {
        fetchMessages().then(messages => {
            messages = messages.filter(m => m.parentId === qId);
            resolve( messages);
        });
    });
}

function showMessages(){
    $('#progDetails').empty();
    $('#messDetails').empty();

    // let studentId =  parseInt($('#stu').attr('data-studentId'));

    let studentId = $('#myChildren').val();
    console.log(studentId)
    getMessages(studentId).then(messages=> {
        console.log(messages);
        displayMessages(messages);
    });
}

function getMessages(studentId) {
    let url = `http://localhost:9080/api/studentMessage/${studentId}`;
    return fetch(url).then(messages => messages.json()).catch(err =>{
        if (confirm('No message for this student')) {
            return;
        }
    });
}

function getParent (username)
{
    return new Promise((resolve, reject) => {
        fetchParents().then(parents => {
            let parent = parents.filter(p=> p.username === username)[0];
            resolve( parent);
        });
    });
}
function onStudentChange() {
    let selectedStudentId = $(this).val();

    getStudent(selectedStudentId).then(student => {
        displayStudent(student);
    }).catch(err => console.log(err));
}

function fillStudentsDD(students) {
    for(let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.name
        }).appendTo($("#studentsDD"))
    }
}
function fetchStudentTasks(id) {
    let url = `http://localhost:9080/api/tasks/student/${id}`;
    return fetch(url).then(response => response.json());
}

function fetchAnn() {
    let url = `http://localhost:9080/api/announcement/`;
    return fetch(url).then(response => response.json());
}

function showStudentsTasks(studentid){
    $('#messDetails').empty();
    $('#progDetails').empty();
    let htmlTemplate = $('#Task-template').html(),
        Tasktemplate = Handlebars.compile(htmlTemplate);

    // console.log('studentTemplate(student)', studentTemplate(student));
    $('#progDetails').empty();
    console.log('current parent = ' + JSON.stringify( currentParent));

    currentParent.students.map(s => {
        if(s.studentId === studentid) {
            fetchStudentTasks(s.studentId).then(tasks => {
                $('#progDetails').append(Tasktemplate({tasks}));
            })
        }
    });
}

function displayMessages(messages) {
    console.log(messages)
    $('#progDetails').empty();
    // $('#messDetails').empty();

    let htmlTemplate = $('#Message-template').html(),
        messageTemplate = Handlebars.compile(htmlTemplate)

    $('#messDetails').html(messageTemplate(messages));
}

function showAnn(){
    let htmlTemplate = $('#Announcement-template').html(),
        annTemplate = Handlebars.compile(htmlTemplate);

    // console.log('studentTemplate(student)', studentTemplate(student));
    // $('#annDetails').empty();
    fetchAnn().then(ann => {
        console.log("heloo    " + JSON.stringify(ann) );
        $('#annDetails').html(annTemplate({ann}));
    });
}

// function displayStudent(student) {
//
//     let htmlTemplate = $('#student-template').html(),
//         studentTemplate = Handlebars.compile(htmlTemplate)
//
//     console.log('studentTemplate(student)', studentTemplate(student));
//
//     $('#studentDetails').html(studentTemplate(student));
// }






