'use strict'
//When the document is loaded in the browser then fill the heroes dropdown.
$(document).ready(function () {
    $('#showMessages').hide();
    $('#showTasks').hide();

    let user = JSON.parse(localStorage.user);
    console.log("$(document).ready.user", user);

    getCoordinator(user.username).then(cor => {
        console.log(cor);
        let firstname = cor.firstName;
        let lastname = cor.lastName;
        let fullname = firstname + " " + lastname;
        console.log(fullname);
        $('#username').html(fullname);
        
        getStudent().then(students => {
            fillStudentsDD(students);
        });
        $("#studentList").on('change', showTask);

    }).catch(err => console.log(err));
});

function fillStudentsDD(students) {
    for (let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.name
        }).appendTo($("#studentList"))
    }
}

function getCoordinator(username) {
    console.log(username);
    let url = `http://localhost:9080/api/coordinator/${username}`;
    return fetch(url).then(response => response.json());
}

function getStudent() {
    let url = `http://localhost:9080/api/studentList`;
    return fetch(url).then(response => response.json());
}

function getStudentTasks(studentId) {
    let url = `http://localhost:9080/api/studentTasks/${studentId}`;
    return fetch(url).then(response => response.json()).catch(err =>{
        if (confirm('No tasks for this student')) {
            return;
        }
    });
}

function addAnnouncement() {
    let htmlTemplate = $('#announcement-form-template').html(),
        announcementTemplate = Handlebars.compile(htmlTemplate);

    $('#announcementForm').html(announcementTemplate({}));
    showAnnFormAsModel();
}

function showAnnFormAsModel() {
    let announcementForm = $("#announcementForm").dialog({
        height: 450,
        width: 750,
        title: 'Announcement Form',
        modal: true,
        buttons: {
            "Submit": function () {
                saveAnnouncement();
                announcementForm.dialog("close");
            },
            Cancel: function () {
                announcementForm.dialog("close");
            }
        }
    });
}

function saveAnnouncement() {
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!
    var yyyy = today.getFullYear();

    if (dd < 10) {
        dd = '0' + dd
    }
    
    if (mm < 10) {
        mm = '0' + mm
    }
    today = mm + '/' + dd + '/' + yyyy;

    let announcement = {
        event: $('#event').val(),
        body: $('#body').val(),
        announcementDate: today,
        image: $('#image').val()
    };

    let url = "http://localhost:9080/api/announcement/";
    let requestMethod = "post";

    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(announcement)
    }).then(() => {
        //After add then refresh the list
        showAnnouncement();
    });
}

function showTask() {
    $('#messDetails').empty();
    $('#annDetails').empty();

    let selectedStatus = $('#studentList').val();
    $('#showMessages').show();
    $('#showTasks').show();

    getStudentTasks(selectedStatus).then(student => {
        displayTasks(student);
    }).catch(err => console.log(err));

}
function showMessages() {
    // console.log("i am in the  show message")
    $('#taskDetails').empty();
    $('#annDetails').empty();
    //$('#messDetails').empty();

    // let studentId =  parseInt($('#stu').attr('data-studentId'));

    let studentId = $('#studentList').val();
    console.log(studentId)
    getMessages(studentId).then(messages=> {
        console.log(messages);
        displayMessages(messages);
    });
}

function showAnnouncement() {
    $('#taskDetails').empty();
    $('#messDetails').empty();
    $('#annDetails').empty();
    
    getAnnouncement().then(announcements => {
        displayAnnouncement(announcements);
    });
}

function getMessages(studentId) {
    let url = `http://localhost:9080/api/studentMessage/${studentId}`;
    return fetch(url).then(messages => messages.json()).catch(err =>{
            if (confirm('No message for this student')) {
             return;
             }
        });
}

function getAnnouncement() {
    let url = `http://localhost:9080/api/Announcement`;
    return fetch(url).then(Announcement => Announcement.json());
}


function displayAnnouncement(announcements) {
    $('#annDetails').empty();
    $('#tasks-details').empty();
    $('#messDetails').empty();
    let htmlTemplate = $('#Announcement-template').html(),
        AnnouncementTemplate = Handlebars.compile(htmlTemplate)

    // console.log('studentTemplate(coordinator)', studentTemplate(student));
    $('#annDetails').html(AnnouncementTemplate({announcements}));
}

function displayMessages(messages) {
    console.log(messages)
    $('#annDetails').empty();
    $('#tasks-details').empty();
    //$('#messDetails').empty();
    
        let htmlTemplate = $('#message-template').html(),
            messageTemplate = Handlebars.compile(htmlTemplate)

        $('#messDetails').html(messageTemplate(messages));
}

function displayTasks(student) {
    $('#annDetails').empty();
    $('#tasks-details').empty();
    $('#messDetails').empty();
    let htmlTemplate = $('#tasks-template').html(),
        tasksTemplate = Handlebars.compile(htmlTemplate)

    // console.log('tasksTamplete(student)', tasksTemplate(student));
    $('#tasks-details').html(tasksTemplate(student));
}