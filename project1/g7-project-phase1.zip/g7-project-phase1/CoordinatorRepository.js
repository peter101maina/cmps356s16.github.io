'use strict'

class CoordinatorRepository {
    constructor() {
        this.fs = require('fs');
    }

    //Read a file and convert its content to a json object
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }

    checkCoordinator(coordinator) {
        let result;
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(coordinators => {
                coordinators = coordinators.filter(c => c.username === coordinator.username && c.password === coordinator.password && c.isCoordinator === 1);
                if (coordinators.length > 0) {
                    result = "coordinator";
                }
                else {
                    result = "not found";
                }
                //  console.log(result);
                resolve(result);
                reject("error");
            });
        });
    }

    getStudents() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(students => {
                // Only return the student Id and names\
                let studentList = [];
                for (let student of students) {
                    for (let oneStu of student.students) {
                        studentList.push(oneStu);
                    }
                }
                resolve(studentList);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getStudentsList() {
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                //   console.log(students);
                students = students.map(s => {
                    return {
                        studentId: s.studentId,
                        name: `${s.firstName} ${s.lastName}`
                    }
                });
                resolve(students);
            }).catch(err => {
                reject(err);
            });
        });
    }

    // retrieveTasks() {
    //     return new Promise((resolve, reject) => {
    //         this.readJsonFile('./data/task.json').then(tasks => {
    //             resolve(tasks);
    //         }).catch(err => {
    //             reject(err);
    //         });
    //     });
    // }

    // getTaskBySID(studentId) {
    //     return new Promise((resolve, reject) => {
    //         this.retriveTasks().then(tasks => {
    //             // console.log(tasks)
    //             tasks = tasks.filter(p => p.studentId === studentId);
    //             resolve(tasks);
    //         }).catch(err => {
    //             reject(err);
    //         });
    //     });
    // }

    getAnnouncement() {
        return new Promise((resolve, reject) => {
            let Ann;
            this.readJsonFile('./data/announcement.json').then(announcement => {
                resolve(announcement);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getAllMessages(student) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/message.json').then(messages => {
                messages = messages.filter(s => s.studentId === student.studentId);
                if (messages.length > 0) {
                    student.messages = messages;
                    resolve(student);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getMessageOfStudent(studentId) {
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                students = students.filter(s => s.studentId === studentId);
                return this.getAllMessages(students[0]);
            }).then(student => {
                resolve(student);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getCoordinatorByUsername(username) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(teachers => {
                // console.log(teachers)
                teachers = teachers.filter(t => t.username === username);
                resolve(teachers[0]);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getTeachers() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(teachers => {
                // console.log(teachers)
                teachers = teachers.map(t => {
                    // console.log(t.hasOwnProperty("halaqa"))
                    if (t.hasOwnProperty("halaqa") === true) {
                        return {
                            teacherId: t.staffNo,
                            name: t.firstName + " " + t.lastName,
                            halaqa: t.halaqa
                        }
                    } else return;
                });
                for (let i = 0; i < teachers.length; i++) {
                    if (teachers[i] === undefined)
                        teachers.splice(i, 1);
                }
                resolve(teachers);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getLastName(parentId) {
        return new Promise((resolve, reject) => {
    
            this.getParents().then(parents=> {
                // console.log(parents)
                parents = parents.map(p => {
                    return {
                        qatariId:p.qatariId,
                        lastName: p.lastname
                    }
                });
                parents = parents.filter(p=>p.qatariId === parentId);
                resolve(parents[0]);
            });
        });
    }

        getParents()
        {
            return new Promise((resolve, reject) => {
                this.readJsonFile('./data/student.json').then(parents => {
                    // console.log(parents)
                    parents = parents.map(p => {
                        return {
                            qatariId: p.qatariId,
                            firstname: p.firstName,
                            lastname: p.lastName,
                            fullname: p.firstName + " " + p.lastName
                        }
                    });

                    resolve(parents);
                }).catch(err => {
                    reject(err);
                });
            });
        }
    
        getAllParents()
        {
            return new Promise((resolve, reject) => {
                this.readJsonFile('./data/student.json').then(parents => {
                    resolve(parents);
                }).catch(err => {
                    reject(err);
                });
            });
        }

        addAnnouncement(announcement)
        {
            return new Promise((resolve, reject) => {
                this.getAnnouncement().then(ann => {
                    //Get the last Id used +1
                    let maxId = Math.max.apply(Math, ann.map(a => a.announcementId)) + 1;
                    console.log("maxId", maxId);

                    announcement.announcementId = maxId;

                    ann.push(announcement);
                    console.log("Controller.addAnn", ann);
                    return this.writeJsonFile('./data/announcement.json', ann);
                }).then((ann)=> resolve(ann))
                    .catch(err => {
                        console.log(err);
                        reject(err);
                    });
            });
        }

        addParent(parent)
        {
            return new Promise((resolve, reject) => {
                this.getAllParents().then(parents => {
                    parents.push(parent);
                    return this.writeJsonFile('./data/student.json', parents);
                }).then((pa)=> resolve(pa))
                    .catch(err => {
                    console.log(err);
                    reject(err);
                });
            });
        }

        getStudentParent(qataryid)
        {
            return new Promise((resolve, reject) => {
                this.readJsonFile('./data/student.json').then(students => {
                    // Only return the student Id and names\
                    students = students.filter(p=>p.qatariId === qataryid);
                    // console.log(students);
                    let studentList = [];
                    for (let student of students) {
                        for (let oneStu of student.students) {
                            studentList.push(oneStu);
                        }
                    }
                    resolve(studentList);
                }).catch(err => {
                    reject(err);
                });
            });
        }

        getStudentsByParentId(pid)
        {
            return new Promise((resolve, reject) => {
                this.readJsonFile('./data/student.json').then(parents => {
                    console.log(parents);
                    parents = parents.filter(p => p.qatariId === pid);
                    if (parents.length > 0) {
                        resolve(parents[0]);
                    }
                    else {
                        reject("No records found");
                    }
                });
            });
        }

        addChild(child)
        {
            return new Promise((resolve, reject) => {
                let parentId = child.parentId;
                // console.log(parentId)
                this.getStudentParent(parentId).then(studentList=> {
                    delete  child.parentId;
                    this.getStudentsList().then(studentList=> {
                        let maxId = Math.max.apply(Math, studentList.map(s => s.studentId)) + 1;
                        child.studentId = maxId;
                    });
                    // console.log(child)
                    this.getLastName(parentId).then(parent=> {
                        child.lastName=parent.lastName;
                    });
                    studentList.push(child);
                    // console.log(studentList)

                    this.getStudentsByParentId(parentId).then(p=> {
                        delete p.students;
                        p.students = studentList;
                        // console.log(JSON.stringify(p, null, 2));

                        this.getAllParents().then(parents=> {
                            let len = parents.length;
                            let foundAt = -1;
                            for (let i = 0; i < len; i++) {
                                if (parents[i].qatariId == p.qatariId) {
                                    foundAt = i;
                                    break;
                                }
                            }
                            if (foundAt >= 0) {
                                parents.splice(foundAt, 1);
                            }
                            parents.push(p);
                            return this.writeJsonFile('./data/student.json', parents);
                        });
                    }).then((children)=> resolve(children))
                }).catch(err => {
                    console.log(err);
                    reject(err);
                });

            });
        }
    }

    module.exports = new CoordinatorRepository();