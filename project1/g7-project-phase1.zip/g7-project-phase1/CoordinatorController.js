'use strict'
class CoordinatorController {
    constructor() {
        this.cooRepository = require('./CoordinatorRepository');
    }

    getCoordinator(req, res){
        let username = req.params.id;
        console.log('req.params.id', username);
        this.cooRepository.getCoordinatorByUsername(username).then(staff => {
            // console.log(JSON.stringify(staff, null, 2));
            res.json(staff);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    getAnnouncement(req, res){
        this.cooRepository.getAnnouncement().then(ann => {
            res.json(ann);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }
    
    addAnnouncement(req, res) {
        let announcement = req.body;
        console.log(announcement);
        this.cooRepository.addAnnouncement(announcement).then((announcement)=> {
                let urlOfNewAnn = `/api/announcement/${announcement.announcementId}`;
                res.location(urlOfNewAnn)
                res.status(201).send(`Created and available @ ${urlOfNewAnn}`);
            }).catch(err => res.status(500).send(err));
    }

    getParent(req, res) {
        this.cooRepository.getParents().then(parent => {
            res.json(parent);
        });
    }
    getTeachers(req, res) {
        this.cooRepository.getTeachers().then(teacher => {
            res.json(teacher);
        });
    }
    getStudent(req, res) {
        this.cooRepository.getStudentsList().then(students => {
            console.log(students)
            res.json(students);
        });
    }

    addParent(req, res) {
        let parent = req.body;
        // console.log(parent);
        this.cooRepository.addParent(parent).then((parent)=> {
                let urlOfNewAnn = `/api/student/${parent.qatariId}`;
                res.location(urlOfNewAnn)
                res.status(201).send(`Created and available @ ${urlOfNewAnn}`);
            })
            .catch(err => res.status(500).send(err));
    }

    addChild(req, res) {
        let child = req.body;
        console.log(child)
        this.cooRepository.addChild(child).then((students)=> {
                let urlOfNewAnn = `/api/student/${child.studentId}`;
                res.location(urlOfNewAnn)
                res.status(201).send(`Created and available @ ${urlOfNewAnn}`);
            })
            .catch(err => res.status(500).send(err));
    }

    getMessageOfStudent(req, res){
        let studentId = req.params.id;
        console.log('req.params.studentId', studentId);
        this.cooRepository.getMessageOfStudent(parseInt(studentId)).then(student => {
            console.log(JSON.stringify(student, null, 2));
            res.json(student);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    
}

module.exports = new CoordinatorController();