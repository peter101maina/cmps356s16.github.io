"use strict";
let express = require('express'),
    bodyParser = require('body-parser')
//open = require('open');

let app = express();
//Allow serving static files
app.use(express.static(__dirname));

let port = 9080;

app.use(bodyParser.urlencoded({extended:true}));
//aut-deserialize the body of incoming request to a json object
app.use(bodyParser.json());


let parentController=require('./ParentController');
let parentRepository=require('./ParentRepository');

let cooRepository = require('./CoordinatorRepository');
let cooController = require('./CoordinatorController');

let teacherRepository = require('./TeacherRepository');
let teacherController=require('./TeacherController');

app.post('/', (req, res) => {
    let resultS;
    let userInfo = req.body;
    console.log("app.post.req.body", userInfo);

    console.log("i reach here")
    parentRepository.checkParent(userInfo).then(result => {
        console.log(userInfo)
        resultS = result;
        if (resultS === 'parent') {
            console.log("parent");
            userInfo.redirectTo = '/parent.html';
            res.json(userInfo);

        } else {
            console.log("i reach coordinator")
            cooRepository.checkCoordinator(userInfo).then(result => {
                resultS = result;
                console.log(resultS);
                if (resultS === 'coordinator') {
                    console.log("coordinator");
                    userInfo.redirectTo = '/coordinator.html';
                    res.json(userInfo);
                }
                else {
                    console.log("i reach teacher")
                    teacherRepository.checkTeacher(userInfo).then(result => {
                        resultS = result;
                        console.log(resultS);
                        if (resultS === 'teacher') {
                            console.log("teacher");
                            userInfo.redirectTo = '/teacher.html';
                            res.json(userInfo);
                        }
                        else {
                            console.log("error");
                        }
                    });
                }
            });
        }
    });
});


app.get('/api/students/:teacherId', (req, res) =>  teacherController.getStudentsList(req, res));
app.get('/api/teacher/:username', (req, res) => teacherController.fetchTeacher(req, res));
app.get('/api/studentTasks/:id', (req, res) => teacherController.getStudent(req, res));
app.get('/api/studentTasksPending/:id', (req, res) => teacherController.getStudentPending(req, res));
app.get('/api/studentTasksFinished/:id', (req, res) => teacherController.getStudentFinished(req, res));
app.delete('/api/tasks/:taskId', (req, res) => teacherController.deleteTask(req, res));
app.get('/api/surahs', (req, res) => teacherController.getSurahs(req, res));
app.get('/api/surah/:id', (req, res) => teacherController.getSaurah(req, res));
app.post('/api/message/', (req, res) => teacherController.addMessage(req, res));
app.put('/api/task/:taskId', (req, res) => teacherController.completeTask(req, res));
app.get('/api/tasks/:taskId', (req, res) => teacherController.fetchTask(req, res));
app.post('/api/newTask/', (req, res)  => teacherController.addTask(req, res));
app.put('/api/newTask/:taskId', (req, res) => teacherController.updateTask(req, res));


app.get('/api/parent/:username', (req, res) => parentController.getParent(req, res));
app.get('/api/students/', (req, res) => parentController.getStudents(req, res));
app.get('/api/students/:id', (req, res) => parentController.getTestParents(req, res));
app.get('/api/tasks/student/:id', (req, res) => parentController.getTaskByStudent(req, res));


app.get('/api/studentMessage/:id', (req, res) => cooController.getMessageOfStudent(req, res));
app.get('/api/studentList', (req, res) => cooController.getStudent(req, res));
app.get('/api/Announcement', (req, res) => cooController.getAnnouncement(req, res));
app.get('/api/coordinator/:id', (req, res) => cooController.getCoordinator(req, res));
app.get('/api/teachers', (req, res) => cooController.getTeachers(req, res));
app.get('/api/parents', (req, res) => cooController.getParent(req, res));
app.post('/api/announcement/', (req, res) => cooController.addAnnouncement(req, res));
app.post('/api/addParent/',(req,res)=> cooController.addParent(req,res));
app.post('/api/addStudents/',(req,res)=> cooController.addChild(req,res));

app.listen(port, function(){
    console.log('Students App is running my app on http://localhost:' + port);
});