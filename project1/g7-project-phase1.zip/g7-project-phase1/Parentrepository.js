
'use strict'

class ParentRepository {
    constructor() {
        this.fs = require('fs');
    }

    //Read a file and convert its content to a json object
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }


getParent(username){
    return new Promise((resolve, reject) => {
        this.readJsonFile('./data/student.json').then(parents => {
            console.log(parents)
            parents = parents.filter(p => p.username === username);
            resolve(parents[0]);
        }).catch(err => {
            reject(err);
        });
    });
}

    checkParent(parent) {
        let result;
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(parents => {
                parents = parents.filter(p => p.username === parent.username && p.password === parent.password);
                if (parents.length > 0) {
                    result = "parent";
                    console.log(JSON.stringify(parents[0]));
                    resolve(result);
                }
                else {
                    result = "not found";
                }
                //  console.log(result);
                resolve(result);
                reject("error");
            });
        });
    }

    getStudent(id)
    {
        return new Promise((resolve, reject) => {
            this.getParents().then(p => {
                for (var i = 0; i < p.length; i++) {
                    for (var k = 0; k< p[i].students.length;k++)
                        if (p[i].students[k].studentId === id) {
                            resolve(p[i].students[k]);
                            break;
                        }
                }
            });
        });
    }


    getStudents() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(students => {
                resolve(students);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getStudentsByParentId(pid) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(parents => {
                // console.log(students);
                parents = parents.filter(p => p.qatariId === pid);
                if (parents.length > 0) {
                    //     delete students[0].password;
                    resolve(parents[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getParents(){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(students => {
                resolve(students);
            }).catch(err => {
                reject(err);
            });
        });
    }


    retriveTasks() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(students => {
                resolve(students);
            }).catch(err => {
                reject(err);
            });
        });
    }

    // retreveByParentID(pId){
    //     return new Promise((resolve, reject) => {
    //         this.getMassages().then(mas => {
    //             console.log(mas);
    //             mas = mas.filter(p => p.parentId === pId);
    //             resolve(JSON.stringify(mas));
    //         }).catch(err => {
    //             reject(err);
    //         });
    //     });
    // }

    getTaskBySID(studentId){
        return new Promise((resolve, reject) => {
            this.getStudent(studentId).then(student => {
                this.retriveTasks().then(tasks => {
                    // console.log(tasks);
                    tasks = tasks.filter(p => p.studentId === studentId);
                    tasks.forEach(t => t.studentName = student.firstName);
                    resolve(tasks);
                }).catch(err => {
                    reject(err);
                });
            });

        });
    }

    // getTeacherByUsername(username){
    //     return new Promise((resolve, reject) => {
    //         this.getTeachers().then(Teachers => {
    //             console.log(Teachers);
    //             Teachers = Teachers.filter(t => t.username === username);
    //             resolve(JSON.stringify(Teachers));
    //         }).catch(err => {
    //             reject(err);
    //         });
    //     });
    // }

    getAnnouncement(){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/announcement.json').then(announcements => {

                resolve(announcements);
            }).catch(err => {
                reject(err);
            });
        });
    }

    // getMassages(){
    //     return new Promise((resolve, reject) => {
    //         this.readJsonFile('./data/massage.json').then(massages => {
    //             massages= massages.map(m => {
    //                 return {
    //                     Massages:m
    //                 }
    //             });
    //             resolve(JSON.stringify(massages));
    //         }).catch(err => {
    //             reject(err);
    //         });
    //     });
    // }
}

module.exports = new ParentRepository();