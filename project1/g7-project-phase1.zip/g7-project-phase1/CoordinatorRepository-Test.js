// 'use strict'
// let HMWRepository = require('./CoordinatorRepository.js');
// let parentRepo=require('./ParentRepository');
// // HMWRepository.getMassages().then(heroes => {
// //     console.log((JSON.stringify(heroes, null, 2)));
// // }).catch(err=> {
// //     console.log((err));
// // });
//
// let parentID = 12;
// let ann={
//     announcementDate: "22/01/16",
//     event: "holiday",
//     body: "hhd",
//     attachment: "nn.jpg"
// }
// // HMWRepository.getStudentByParentId(parentID).then(hero => {
// //     //Displays a pretty-printed multiline JSON representation indented with 2 spaces
// //     console.log(JSON.stringify(hero, null, 2));
// // });
// let parentId= 12;
//     let child={
//         parentId: 12,
//     firstName: "Israa",
//     lastName: "saleem",
// }
//
// let parent={
//     qatariId: 44,
//     firstName: "Salim",
//     lastName: "Al sarsour",
//     mobile: "9999-888",
//     email: "Salim@test.com",
//     username: "coordinator",
//     password: "password",
//     students:[]
// }
//
// // HMWRepository.addChild(child).then(heroes => {
// //     console.log((JSON.stringify(heroes, null, 2)));
// // }).catch(err=> {
// //     console.log((err));
// // });
// let a={
//     announcementDate:"test"
// }
//
// HMWRepository.checkCoordinator(parent).then(last=>{
//     // let lastName=last.lastName;
//
//     console.log(last);
// }).catch(err=> {
//     console.log((err));
// });
