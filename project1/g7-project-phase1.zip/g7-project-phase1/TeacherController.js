'use strict'
class TeacherController {
    constructor() {
        this.teacherRepository = require('./TeacherRepository');
    }

    updateTask(req, res) {
        let task = req.body;
        console.log(task);
        this.teacherRepository.updateTask(task).then(() => {
            res.status(200).send("Task updated successfully");
        }).catch(err => {
            console.log(err);
            res.status(500).send(err);
        });
    }

    addTask(req, res) {
        let task = req.body;
        this.teacherRepository.addTask(task).then((task)=> {
                console.log(task);
                let urlOfNewTask = `/api/newTask/${task.taskId}`;
                res.location(urlOfNewTask)
                res.status(201).send(`Created and available @ ${urlOfNewTask}`);
            })
            .catch(err => res.status(500).send(err));
    }


    fetchTask(req, res) {
        let taskId = req.params.taskId;
        this.teacherRepository.fetchTask(parseInt(taskId)).then(task => {
            console.log(JSON.stringify(task, null, 2));
            res.json(task);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }

    completeTask(req, res){
        let task = req.body;
        console.log(task);
        this.teacherRepository.completeTask(task).then(() => {
            res.status(200).send("Task updated successfully");
        }).catch(err => {
            console.log(err);
            res.status(500).send(err);
        });
        
    }

    addMessage(req, res){
        let message = req.body;
        this.teacherRepository.addMessage(message).then((message)=> {
                let urlOfNewMessage = `/api/message/${message.messageId}`;
                res.location(urlOfNewMessage)
                res.status(201).send(`Created and available @ ${urlOfNewMessage}`);
            })
            .catch(err => res.status(500).send(err));
    }

    getSaurah(req, res){
        let surahId = req.params.id;
        this.teacherRepository.getSaurah(parseInt(surahId)).then(surah => {
            console.log(JSON.stringify(surah, null, 2));
            res.json(surah);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }

    getSurahs(req, res){
        this.teacherRepository.getSurahs().then(surahs => {
            console.log(JSON.stringify(surahs, null, 2));
            res.json(surahs);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    
    }

    deleteTask(req, res){
        let taskId = req.params.taskId;
        console.log('req.params.tasktId', taskId);
        this.teacherRepository.deleteTask(parseInt(taskId)).then(() => {
            res.status(200).send("Request deleted");
        }).catch(err => {
            res.status(500).send(err);
        });
    }

    getStudentFinished(req, res){
        let studentId = req.params.id;
        console.log('req.params.studentId', studentId);
        this.teacherRepository.getStudentFinished(parseInt(studentId)).then(student => {
            console.log(JSON.stringify(student, null, 2));
            res.json(student);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    getStudentPending(req, res) {
        let studentId = req.params.id;
        console.log('req.params.studentId', studentId);
        this.teacherRepository.getStudentPending(parseInt(studentId)).then(student => {
            console.log(JSON.stringify(student, null, 2));
            res.json(student);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }

    getStudent(req, res){
        let studentId = req.params.id;
        console.log('req.params.studentId', studentId);
        this.teacherRepository.getStudent(parseInt(studentId)).then(student => {
            console.log(JSON.stringify(student, null, 2));
            res.json(student);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    
    }

    fetchTeacher(req, res){
        let teacherUsername = req.params.username;
        console.log('req.params.username', teacherUsername);
        this.teacherRepository.fetchTeacher(teacherUsername).then(teacher => {
            console.log(JSON.stringify(teacher, null, 2));
            res.json(teacher);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }

    getStudentsList(req, res){
        let teacherId = req.params.teacherId;
        console.log('req.params.id', teacherId);
        console.log("done");
        this.teacherRepository.getStudentsList(parseInt(teacherId)).then(students => {
            console.log(JSON.stringify(students, null, 2));
            res.json(students);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    
}
module.exports = new TeacherController();
