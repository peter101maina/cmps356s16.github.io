// //'use strict'
// //let studentRepository = require('./StudentRepository.js');
// //studentRepository.getStudents().then(students => {
// //    console.log(students);
// //});
// //
// //let studentId = 2015002;
// //studentRepository.getStudent(studentId).then(student => {
// //    //Displays a pretty-printed multiline JSON representation indented with 2 spaces
// //    console.log(JSON.stringify(student, null, 2));
// //});
//
//
// 'use strict'
// //let teacherId = 501;
// let username = "teacher1";
// //let teacherRepository = require('./TeacherRepository.js');
// //
// //   teacherRepository.getStudentsList(teacherId).then(students => {
// //      // teacherRepository.getStudents(students).then(list => {
// //           console.log(students);
// //    //   });
// //});
//
//
// //
// //let teacherRepository = require('./TeacherRepository.js');
// //
// //teacherRepository.fetchTeacher(username).then(teacher => {
// //    // teacherRepository.getStudents(students).then(list => {
// //    console.log(teacher);
// //    //   });
// //});
// let studentId= 1;
// //let student = {
// //    studentId: 1,
// //    firstName: "Ibn Juha",
// //    lastName: "Dahak",
// //    dob: "1/1/2009",
// //    gender: "M",
// //    schoolGrade: 4,
// //    teacherId: 502
// //};
//
// let teacherRepository = require('./TeacherRepository.js');
// let parentRepo=require("./Parentrepository");
// //
// parentRepo.getParent("samira").then(student => {
//    console.log(student);
//      });
//
// //teacherRepository.getStudent(studentId).then(student => {
// //    // teacherRepository.getStudents(students).then(list => {
// //    console.log(student);
// //    //   });
// //});
//
// //teacherRepository.getSurahs().then(surahs => {
// //    console.log(surahs);
// //});
// <<<<<<< HEAD
//
// // teacherRepository.getMessages().then(messages => {
// //     console.log(messages);
// // });
// =======
// let task = {
//     studentId: 6,
//     surahId: 7,
//     surahName: "Al-Araf",
//     fromAya: 18,
//     toAya: 22,
//     type: "Revision",
//     dueDate: "3/04/2016"
// }
// teacherRepository.addTask(task).then(task => {
//     console.log(task);
// });
// >>>>>>> origin/master
