/**
 * Created by Fatma on 16-Apr-16.
 */

let qatariId;
let studentId;

$(document).ready(function () {

    let user = JSON.parse(localStorage.user);

    if (user != 'undefined') {
        $('#username').html(user.firstName + " " + user.lastName);
        qatariId = user.qatariId;
    }

    getStudents().then(students => {
        fillStudentsDD(students); //studentId is assigned here
        getAllStudentTasks(); //need to have studentId first before this
        getStudentMessages(); //need to have studentId first before this
        getAnnouncements();
    }).catch(err => console.log(err));


    $("#studentsDD").on('change', onStatusChange);
    $("#allButton").on('click', getAllStudentTasks);
    $("#completeButton").on('click', getCompleteStudentTasks);
    $("#pendingButton").on('click', getPendingStudentTasks);
    $("#messagesRadio").on('click', getStudentMessages);

    $('#announcementsTableDiv').on('click', 'td.announcementLink', showADetails);

    $("#home").on('click', onHomeClick);
    $("#about").on('click', onAboutClick);
    $("#help").on('click', onHelpClick);
    $("#logout").on('click', onLogoutClick);

});

function getStudents() {

    let url = `http://localhost:9080/api/parents/${qatariId}`;
    return fetch(url).then(response => response.json());
}

function getAllStudentTasks() {
    let url = "http://localhost:9080/api/tasks/all/" + studentId;
    fetch(url).then(response => response.json()).then(tasks =>displayTasks(tasks)).catch(err => console.log(err));
}

function getCompleteStudentTasks() {
    let url = "http://localhost:9080/api/tasks/complete/" + studentId;
    fetch(url).then(response => response.json()).then(tasks =>displayTasks(tasks)).catch(err => console.log(err));
}

function getPendingStudentTasks() {
    let url = `http://localhost:9080/api/tasks/pending/${studentId}`;
    fetch(url).then(response => response.json()).then(tasks =>displayTasks(tasks)).catch(err => console.log(err));
}

function getStudentMessages() {
    let url = `http://localhost:9080/api/messages/${studentId}`;
    fetch(url).then(response => response.json()).then(messages =>displayMessages(messages)).catch(err => console.log(err));
}

function getMessage(id, studentId) {
    let url = "http://localhost:9080/api/messages/" + studentId + "/" + id;
    return fetch(url).then(response => response.json());
}

function getAnnouncements() {
    let url = "http://localhost:9080/api/announcements";
    fetch(url).then(response => response.json()).then(announcements =>displayAnnouncements(announcements)).catch(err => console.log(err));
}

function getAnnouncement(id) {
    let url = "http://localhost:9080/api/announcements/" + id;
    return fetch(url).then(response => response.json());
}

function fillStudentsDD(students) {
    for (let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName + " " + student.lastName
        }).appendTo($("#studentsDD"))
    }
    studentId = $("#studentsDD").val();//initially selected
}

function displayTasks(tasks) {
    let htmlTemplate = $('#task-template').html(),
        taskTemplate = Handlebars.compile(htmlTemplate)
    $('#tasksTableDiv').html(taskTemplate({tasks}));
}

function displayMessages(messages) {
    let htmlTemplate = $('#messages-template').html(),
        messageTemplate = Handlebars.compile(htmlTemplate)
    $('#messagesTableDiv').html(messageTemplate({messages}));
}

function displayAnnouncements(announcements) {
    let htmlTemplate = $('#announcements-template').html(),
        announcementTemplate = Handlebars.compile(htmlTemplate)
    $('#announcementsTableDiv').html(announcementTemplate({announcements}));
}

function onStatusChange() {
    studentId = $(this).val();
    getAllStudentTasks();//populate the table

    if ($("#messagesRadio").is(":checked")) //if messages is checked, get messages of the new student
        getStudentMessages()
    //else do nothing, knowing that announcement is checked and announcements are the same for all students
}

function showMDetails(id, studentId) {
    getMessage(id, studentId).then(message => {

        console.log(message);


        let htmlTemplate = $('#details-template').html(),
            detailTemplate = Handlebars.compile(htmlTemplate);
        $('#detailsDiv').html(detailTemplate(message));
        showFormAsModel();

    }).catch(err => console.log(err))
}

function showADetails() {

    let id = $(this).attr('data-announcementId');

    console.log(id);

    getAnnouncement(id).then(announcement => {

        let htmlTemplate = $('#details-template').html(),
            detailTemplate = Handlebars.compile(htmlTemplate);
        $('#detailsDiv').html(detailTemplate(announcement));
        showFormAsModel();

    }).catch(err => console.log(err))
}

function showFormAsModel() {
    let detailsDialog = $("#detailsDiv").dialog({
        height: 450,
        width: 750,
        title: 'Details',
        modal: true,
        buttons: {
            "ok": function () {
                detailsDialog.dialog("close");
            }
        }
    });
}

function onHomeClick() {
    window.location = '/homeParent.html'
}

function onAboutClick() {
    window.location = '/aboutParent.html'
}

function onHelpClick() {
    window.location = '/helpParent.html'
}

function onLogoutClick() {
    window.location = '/index.html'
}



