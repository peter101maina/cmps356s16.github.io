/**
 * Created by Fatma on 16-Apr-16.
 */

let studentId;
let taskForm;

$(document).ready(function () {

    let user = JSON.parse(localStorage.user);

    if (user != 'undefined') {
        $('#username').html(user.firstName + " " + user.lastName);
        qatariId = user.qatariId;
    }

    getStudents().then(students => {
        fillStudentsDD(students); //studentId is assigned here
        getAllStudentTasks(); //need to have studentId first before this
        getAnnouncements();
    }).catch(err => console.log(err));

    $("#studentsDD").on('change', onStatusChange);
    $("#allButton").on('click', getAllStudentTasks);
    $("#completeButton").on('click', getCompleteStudentTasks);
    $("#pendingButton").on('click', getPendingStudentTasks);

    $("#announce").on('click', makeAnnouncement);

    $('#announcementsTableDiv').on('click', 'td.announcementLink', showADetails);

    $("#home").on('click', onHomeClick);
    $("#register").on('click', onRegisterClick);
    $("#about").on('click', onAboutClick);
    $("#help").on('click', onHelpClick);
    $("#logout").on('click', onLogoutClick);

});

function getStudents() {
    let url = "http://localhost:9080/api/students";
    return fetch(url).then(response => response.json());
}

function getAllStudentTasks() {
    let url = "http://localhost:9080/api/tasks/all/" + studentId;
    fetch(url).then(response => response.json()).then(tasks =>displayTasks(tasks)).catch(err => console.log(err));
}

function getCompleteStudentTasks() {
    let url = "http://localhost:9080/api/tasks/complete/" + studentId;
    fetch(url).then(response => response.json()).then(tasks =>displayTasks(tasks)).catch(err => console.log(err));
}

function getPendingStudentTasks() {
    let url = "http://localhost:9080/api/tasks/pending/" + studentId;
    fetch(url).then(response => response.json()).then(tasks =>displayTasks(tasks)).catch(err => console.log(err));
}

function getAnnouncements() {
    let url = "http://localhost:9080/api/announcements";
    fetch(url).then(response => response.json()).then(announcements =>displayAnnouncements(announcements)).catch(err => console.log(err));
}

function getAnnouncement(id) {
    let url = "http://localhost:9080/api/announcements/" + id;
    return fetch(url).then(response => response.json());
}

function fillStudentsDD(students) {
    for (let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName + " " + student.lastName
        }).appendTo($("#studentsDD"))
    }
    studentId = $("#studentsDD").val();//initially selected
}

function displayTasks(tasks) {
    let htmlTemplate = $('#task-template').html(),
        taskTemplate = Handlebars.compile(htmlTemplate)
    $('#tasksTableDiv').html(taskTemplate({tasks}));
}

function displayAnnouncements(announcements) {
    let htmlTemplate = $('#announcements-template').html(),
        announcementTemplate = Handlebars.compile(htmlTemplate)
    $('#announcementsTableDiv').html(announcementTemplate({announcements}));
}

function makeAnnouncement(event) {
    event.preventDefault();
    let htmlTemplate = $('#announcement-form-template').html(),
        announTemplate = Handlebars.compile(htmlTemplate);
    $('#popupDiv').html(announTemplate());
    showFormAsModelNew();
}

function showFormAsModelNew() {
    taskForm = $("#popupDiv").dialog({
        height: 600,
        width: 750,
        title: 'Announcement Form',
        modal: true,
        buttons: {
            Submit: function(){
                taskForm.dialog("close");
                sendAnnouncement();
                $("#newAnnouncementForm").submit();
                //location.reload();
                //window.location = '/index.html'
                //window.location = '/homeCoordinator.html'

            },
            Cancel: function () {
                taskForm.dialog("close");
            }
        }
    });
}

function showADetails() {

    let id = $(this).attr('data-announcementId');

    console.log(id);

    getAnnouncement(id).then(announcement => {

        let htmlTemplate = $('#details-template').html(),
            detailTemplate = Handlebars.compile(htmlTemplate);
        $('#detailsDiv').html(detailTemplate(announcement));
        showFormAsModel();

    }).catch(err => console.log(err))
}


function showFormAsModel() {
    let detailsDialog = $("#detailsDiv").dialog({
        height: 450,
        width: 750,
        title: 'Details',
        modal: true,
        buttons: {
            "ok": function () {
                detailsDialog.dialog("close");
            }
        }
    });
}


function sendAnnouncement() {

    var filename = $('input[type=file]').val().split('\\').pop();

    Date.prototype.toDateInputValue = (function () {
        var local = new Date(this);
        local.setMinutes(this.getMinutes() - this.getTimezoneOffset());
        return local.toJSON().slice(0, 10);
    });

    let message = {
        "title": $("#title").val(),
        "text": $("#text").val(),
        "date": new Date().toDateInputValue(),
        "image": filename
    }

    let url = "http://localhost:9080/api/announcements";
    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(message)
    }).then(() => {
    });

    window.location = '/homeCoordinator.html'

}


function onStatusChange() {
    studentId = $(this).val();
    getAllStudentTasks();//populate the table
}

function onHomeClick() {
    window.location = '/homeCoordinator.html'
}

function onAboutClick() {
    window.location = '/aboutCoordinator.html'
}

function onHelpClick() {
    window.location = '/helpCoordinator.html'
}

function onRegisterClick() {
    window.location = '/registerNewChild.html'
}

function onLogoutClick(event) {
    window.location = '/index.html'
}
