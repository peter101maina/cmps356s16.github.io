/**
 * Created by Fatma on 21-Apr-16.
 */

'use strict'

$(document).ready(()=> {
    $("#login").on('click', onLogin);
});

function onLogin() {
    let user = {
        username: $("#userName").val(),
        password: $("#password").val()
    };

    let url = "http://localhost:9080";
    let requestMethod = "post";

    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(user)
    }).then(response => response.json())
        .then(user => {
            localStorage.user = JSON.stringify(user);
            window.location = user.redirectTo;
        }).catch(err=> {
        showMessage("username or password unresolved...");
    });
}

function showMessage(m) {
    $("#wrongInput").html(m);
}




