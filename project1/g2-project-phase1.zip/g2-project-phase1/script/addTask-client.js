/**
 * Created by Samasung on 04/22/2016.
 */

let studentId;
let surahId;
let surahName;
let fromAya;
let toAya;
let type;


$(document).ready(function () {

    let user = JSON.parse(localStorage.user);

    if (user != 'undefined') {
        $('#username').html(user.firstname + " " + user.lastname);
        teacherId = user.staffNo;
    }


    getSurahs().then(surahs => fillSurahsDD(surahs))
        .catch(err => console.log(err));
    $("#surahDD").on('change', onSurahSelected);

    getStudents().then(students => fillStudentsDD(students))
        .catch(err => console.log(err));
    $("#studentsDD").on('change', onStudentSelected);

    $('#addTaskBtn').on('click', addTask);


});


function getStudents() {
    let url = `http://localhost:9080/api/students/${teacherId}`;
    return fetch(url).then(response => response.json());
}

function fillStudentsDD(students) {
    for (let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName + " " + student.lastName
        }).appendTo($("#studentsDD"))
    }
}

function onStudentSelected() {
    studentId = $(this).val();
}

function getSurahs() {
    let url = "http://localhost:9080/api/surahs";
    return fetch(url).then(response => response.json());
}

function fillSurahsDD(surahs) {
    for (let surah of surahs) {
        $("<option>", {
            value: surah.id,
            text: surah.englishName + "  -  " + surah.name,
        }).appendTo($("#surahDD"))
    }
}

function onSurahSelected() {
    let selectedSurahId = $(this).val();
    surahId = selectedSurahId;
    getSurah(selectedSurahId).then(surah => {
        surahName = surah[0].englishName;
        let min;

        $('#maxFrom').text("Max: " + parseInt(surah[0].ayaCount - 1));

        $('#AyaFrom').attr("max", parseInt(surah[0].ayaCount - 1));
        $('#AyaFrom').attr("min", 1);
        $('#AyaFrom').attr("value", 1);
        $('#AyaFrom').on('input', function () {
            $('#selectedFrom').text($('#AyaFrom').val());
            min = $('#selectedFrom').val();
            fromAya = min;
            $('#AyaTo').attr("min", parseInt(min));
        });


        $('#maxTo').text("Max: " + surah[0].ayaCount);

        $('#AyaTo').attr("max", parseInt(surah[0].ayaCount));

        $('#AyaTo').attr("value", 1);
        $('#AyaTo').on('input', function () {
            $('#selectedTo').text($('#AyaTo').val());
            toAya = $('#AyaTo').val();
        });
    }).catch(err => console.log(err));
}

function getSurah(id) {
    let url = `http://localhost:9080/api/surahs/${id}`;
    return fetch(url).then(response => response.json());
}

function addTask() {
    let task = {
        studentId: parseInt(studentId),
        surahId: parseInt(surahId),
        surahName: surahName,
        fromAya: parseInt(fromAya),
        toAya: parseInt(toAya),
        type: $('#taskType').val(),
        dueDate: $('#taskDue').val()
    }

    let url = "http://localhost:9080/api/tasks";
    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(task)
    }).then(() => {
        //After add/update then refresh the list
        GoHomeInstructor();
        console.log(task);
    });


    function GoHomeInstructor() {
        window.location = '/homeInstructor.html'
    }

    

}