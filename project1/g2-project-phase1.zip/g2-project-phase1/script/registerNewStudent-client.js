/**
 * Created by Fatma on 23-Apr-16.
 */


$(document).ready(function () {

    getTeachers().then(teachers=> {
        fillTeachersDD(teachers);
    }).catch(err=>console.log(err));

    $("#newParentRadio").on('click', showNewParentFields);
    $("#existingParentRadio").on('click', hideNewParentFields);
    $("#addChild").on('click', addChild);


});

function fillTeachersDD(teachers) {
    for (let teacher of teachers) {
        $("<option>", {
            value: teacher.staffNo,
            text: teacher.firstName + " " + teacher.lastName
        }).appendTo($("#teachersDD"))
    }
    studentId = $("#studentsDD").val();//initially selected
}

function showNewParentFields() {
    $('#firstNameLabel').show();
    $('#firstName').show();
    $('#lastNameLabel').show();
    $('#lastName').show();
    $('#mobileNumberLabel').show();
    $('#mobileNumber').show();
    $('#emailLabel').show();
    $('#email').show();
    $('#usernameLabel').show();
    $('#username').show();
    $('#passwordLabel').show();
    $('#password').show();

}

function hideNewParentFields() {
    $('#firstNameLabel').hide();
    $('#firstName').hide();
    $('#lastNameLabel').hide();
    $('#lastName').hide();
    $('#mobileNumberLabel').hide();
    $('#mobileNumber').hide();
    $('#emailLabel').hide();
    $('#email').hide();
    $('#usernameLabel').hide();
    $('#username').hide();
    $('#passwordLabel').hide();
    $('#password').hide();

}


function getTeachers() {
    let url = "http://localhost:9080/api/teachers";
    return fetch(url).then(response => response.json());
}

function addChild() {
    let parent = {
        "qatariId": parseInt($('#qatariId').val()),
        "firstName": $('#firstName').val(),
        "lastName": $('#lastName').val(),
        "mobile": $('#mobileNumber').val(),
        "email": $('#email').val(),
        "username": $('#username').val(),
        "password": $('#password').val(),
        "student": {
            "firstName": $('#childFirstName').val(),
            "lastName": $('#childLastName').val(),
            "dob": $('#birthDate').val(),
            "gender": $("#femaleRadio").is(":checked") ? "F" : "M",
            "schoolGrade": parseInt($('#schooleGrade').val()),
            "teacherId": parseInt($('#teachersDD').val())
        }
    }

    let url = "http://localhost:9080/api/students";
    let requestMethod = "post";

    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(parent)
    });
    GoHomeCoordinator() ;
    $('#studentAdded').show();

}

function GoHomeCoordinator() {
    window.location = '/homeCoordinator.html'
}

function onResetChild() {
    $('#studentAdded').hide();
}