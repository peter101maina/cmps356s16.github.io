/**
 * Created by Samasung on 04/24/2016.
 */

"use strict"

let teacherId;


$(document).ready(function () {

    let user = JSON.parse(localStorage.user);

    if (user != 'undefined') {
        $('#username').html(user.firstname + " " + user.lastname);
        teacherId = user.staffNo;
    }

    getStudents().then(students => {
        fillStudentsDD(students); //studentId is assigned here
    }).catch(err => console.log(err));


    $('#messageBtn').on('click', sendMessage);
});

function getStudents() {
    let url = `http://localhost:9080/api/students/${teacherId}`;
    return fetch(url).then(response => response.json());
}

function fillStudentsDD(students) {
    for (let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName + " " + student.lastName
        }).appendTo($("#studentsDD"))
    }
    studentId = $("#studentsDD").val();//initially selected
}

function sendMessage() {

    var filename = $('input[type=file]').val().split('\\').pop();

    Date.prototype.toDateInputValue = (function () {
        var local = new Date(this);
        local.setMinutes(this.getMinutes() - this.getTimezoneOffset());
        return local.toJSON().slice(0, 10);
    });

    let message = {
        "studentId": parseInt($("#studentsDD").val()),
        "title": $("#title").val(),
        "text": $("#text").val(),
        "date": new Date().toDateInputValue(),
        "image": filename
    }

    let url = "http://localhost:9080/api/messages";
    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(message)
    }).then(() => {
        window.location = '/homeInstructor.html'
    });


}