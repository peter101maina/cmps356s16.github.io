/**
 * Created by Fatma on 16-Apr-16.
 */
let id;
let studentId;
let surahId;
let surahName;
let fromAya;
let toAya;
let type;
let dueDate;
let teacherId;
let taskForm;

$(document).ready(function () {

    let user = JSON.parse(localStorage.user);

    if (user != 'undefined') {
        $('#username').html(user.firstName + " " + user.lastName);
        teacherId = user.staffNo;
    }


    getStudents().then(students => {
        fillStudentsDD(students); //studentId is assigned here
        getPendingStudentTasks(); //need to have studentId first before this
        getAnnouncements();
    }).catch(err => console.log(err));


//    $('#btnAll').on('click',getAll);
    $('#btnComplete').on('click', getCompleteStudentTasks);
    $('#btnPending').on('click', getPendingStudentTasks);
    $("#home").on('click', onHomeClick);
    $("#sendMessage").on('click', onSendMessageClick);
    $("#addTask").on('click', onAddTaskClick);
    $("#about").on('click', onAboutClick);
    $("#help").on('click', onHelpClick);
    $("#logout").on('click', onLogoutClick);

    $("#studentsDD").on('change', onStatusChange);

    $('#announcementsTableDiv').on('click', 'td.announcementLink', showADetails);

    $('#table-Div').on('click', 'a.updateBtn', updateTask);
    $('#table-Div').on('click', 'a.deleteBtn', deleteTask);
    $('#table-Div').on('click', 'a.completeBtn', completeTask);


});

function getStudents() {
    let url = `http://localhost:9080/api/students/${teacherId}`;
    return fetch(url).then(response => response.json());
}

function getAnnouncements() {
    let url = "http://localhost:9080/api/announcements";
    fetch(url).then(response => response.json()).then(announcements =>displayAnnouncements(announcements)).catch(err => console.log(err));
}

function getAnnouncement(id) {
    let url = "http://localhost:9080/api/announcements/" + id;
    return fetch(url).then(response => response.json());
}

function fillStudentsDD(students) {
    for (let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName + " " + student.lastName
        }).appendTo($("#studentsDD"))
    }
    studentId = $("#studentsDD").val();//initially selected
}

function onStatusChange() {
    studentId = $(this).val();
    getPendingStudentTasks();//populate the table

    //else do nothing, knowing that announcement is checked and announcements are the same for all students
}

function getAllStudentTasks() {
    let url = "http://localhost:9080/api/tasks/all/" + studentId;
    fetch(url).then(response => response.json()).then(tasks =>displayTasks(tasks)).catch(err => console.log(err));
}

function getCompleteStudentTasks() {
    let url = "http://localhost:9080/api/tasks/complete/" + studentId;
    fetch(url).then(response => response.json()).then(tasks =>displayTasks(tasks)).catch(err => console.log(err));
}

function getPendingStudentTasks() {
    let url = "http://localhost:9080/api/tasks/pending/" + studentId;
    fetch(url).then(response => response.json()).then(tasks =>displayTasks(tasks)).catch(err => console.log(err));
}


function fetchSurah(id) {
    let url = `http://localhost:9080/api/surahs/${id}`;
    return fetch(url).then(response => response.json());
}

function updateTask(event) {

    event.preventDefault();
    let taskId = $(this).attr('data-taskId');
    fetchTask(taskId).then(task => {
        id = taskId;
        surahId = task[0].surahId;
        studentId = task[0].studentId;
        surahName = task[0].surahName;
        fetchSurah(task[0].surahId).then(surah => {

            let htmlTemplate = $('#updateTask-template').html(),
                taskTemplate = Handlebars.compile(htmlTemplate);

            $('#popupDiv').html(taskTemplate(task));
            $('#surahName').val(task[0].surahName);

            $('#taskDue').val(task[0].dueDate);

            $('#taskType').val(task[0].type);

            let min;

            $('#maxFrom').text("Max: " + parseInt(surah[0].ayaCount - 1));

            $('#AyaFrom').attr("max", parseInt(surah[0].ayaCount - 1));
            $('#AyaFrom').attr("min", 1);
            $('#AyaFrom').val(task[0].fromAya);
            $('#selectedFrom').text($('#AyaFrom').val());
            fromAya = $('#AyaFrom').val();

            $('#AyaFrom').on('input', function () {
                $('#selectedFrom').text($('#AyaFrom').val());
                min = $('#selectedFrom').val();
                fromAya = min;
                $('#AyaTo').attr("min", parseInt(min)+1);
                $('#selectedTo').text(parseInt(min)+1);
                toAya = parseInt(min)+1+"";//string value
            });

            $('#maxTo').text("Max: " + surah[0].ayaCount);

            $('#AyaTo').attr("max", parseInt(surah[0].ayaCount));
            $('#AyaTo').val(task[0].toAya);
            $('#selectedTo').text($('#AyaTo').val());
            toAya = $('#AyaTo').val();

            $('#AyaTo').on('input', function () {
                $('#selectedTo').text($('#AyaTo').val());
                toAya = $('#AyaTo').val();
            });

            showFormAsModel();

        })

    }).catch(err => console.log(err));
}

function showFormAsModel() {
    taskForm = $("#popupDiv").dialog({
        height: 600,
        width: 750,
        title: 'Task Form',
        modal: true,
        buttons: {
            "Submit": function () {
                saveTask();
                taskForm.dialog("close");
                getPendingStudentTasks();
            },
            Cancel: function () {
                taskForm.dialog("close");
            }
        }
    });

}

function showFormAsModel_complete() {

    taskForm = $("#popupDiv").dialog({
        height: 530,
        width: 750,
        title: 'Task Form',
        modal: true,
        buttons: {
            "Submit": function () {
                saveTask_complete();
                taskForm.dialog("close");
                getCompleteStudentTasks();
            },
            Cancel: function () {
                taskForm.dialog("close");
            }
        }
    });

}

function saveTask() {

    let task = {
        taskId: parseInt(id),
        studentId: parseInt(studentId),
        surahId: parseInt(surahId),
        surahName: surahName,
        fromAya: parseInt(fromAya),
        toAya: parseInt(toAya),
        type: $('#taskType').val(),
        dueDate: $('#taskDue').val()
    };

    let url = "http://localhost:9080/api/tasks/";
    url += task.taskId;

    fetch(url, {
        method: "put",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(task)
    }).then(() => {
        getPendingStudentTasks();
    });
}

function saveTask_complete() {
    let task = {

        taskId: parseInt(id),
        studentId: studentId,
        surahId: surahId,
        surahName: surahName,
        fromAya: parseInt(fromAya),
        toAya: parseInt(toAya),
        type: type,
        dueDate: dueDate,
        completedDate: $('#taskComp').val(),
        masteryLevel: $('#masterylevel').val(),
        comment: $('#taskComment').val()
    };

    let url = "http://localhost:9080/api/tasks/";
    url += task.taskId;

    fetch(url, {
        method: "put",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(task)
    }).then(() => {
        console.log("updated");
    });
}


function fetchTask(taskId) {

    let url = `http://localhost:9080/api/tasks/${taskId}`;
    return fetch(url).then(response=> response.json());
}


function displayTasks(tasks) {
    let htmlTemplate = $('#tasksTable-template').html(),
        taskTemplate = Handlebars.compile(htmlTemplate);
    $('#table-Div').html(taskTemplate({tasks}));
}

function deleteTask(event) {
    event.preventDefault();

    // Ask the user to confirm. If they cancel the request then exit this function
    if (!confirm('Confirm delete?')) {
        return;
    }
    else {
        let taskId = $(this).attr('data-taskId');
        let url = `http://localhost:9080/api/tasks/${taskId}`;

        fetch(url, {method: 'delete'}).then(() => {
            //After successful delete remove the row from the HTML table

            $(this).closest('tr').remove();
        }).then(() => {
            //After delete then refresh the list

        });
        location.reload();
    }

}


function getAllStudentTasks() {
    let url = "http://localhost:9080/api/tasks/all/" + studentId;
    fetch(url).then(response => response.json()).then(tasks =>displayTasks(tasks)).catch(err => console.log(err));
}

function getCompleteStudentTasks() {
    let url = "http://localhost:9080/api/tasks/complete/" + studentId;
    fetch(url).then(response => response.json()).then(tasks =>displayTasks(tasks)).catch(err => console.log(err));
}

function getPendingStudentTasks() {
    let url = "http://localhost:9080/api/tasks/pending/" + studentId;
    fetch(url).then(response => response.json()).then(tasks =>displayTasks(tasks)).catch(err => console.log(err));
}

function completeTask(event) {

    event.preventDefault();
    let taskId = $(this).attr('data-taskId');
    fetchTask(taskId).then(task => {
        id = taskId;
        surahId = task[0].surahId;
        studentId = task[0].studentId;
        surahName = task[0].surahName;
        type = task[0].type;
        dueDate = task[0].dueDate;
        fromAya = task[0].fromAya;
        toAya = task[0].toAya;

        // fetchSurah(task[0].surahId).then(surah => {

        let htmlTemplate = $('#completeTask-template').html(),
            taskTemplate = Handlebars.compile(htmlTemplate);
        $('#popupDiv').html(taskTemplate(task));

        $('#surahName_Complete').val(task[0].surahName);

        $('#studentId').val(task[0].studentId);

        // this is to get today's date for completion date!

        Date.prototype.toDateInputValue = (function () {
            var local = new Date(this);
            local.setMinutes(this.getMinutes() - this.getTimezoneOffset());
            return local.toJSON().slice(0, 10);
        });

        $('#taskComp').val(new Date().toDateInputValue());


        showFormAsModel_complete();

        //}
        //)

    }).catch(err => console.log(err));


}

function onHomeClick() {
    window.location = '/homeInstructor.html'
}

function onAboutClick() {
    window.location = '/aboutInstructor.html'
}

function onHelpClick() {
    window.location = '/helpInstructor.html'
}

function onAddTaskClick() {
    window.location = '/addTask.html'
}

function onSendMessageClick() {
    window.location = '/newMessage.html'
}

function onLogoutClick() {
    window.location = '/index.html'
}

function showADetails() {

    let id = $(this).attr('data-announcementId');

    getAnnouncement(id).then(announcement => {

        let htmlTemplate = $('#details-template').html(),
            detailTemplate = Handlebars.compile(htmlTemplate);
        $('#detailsDiv').html(detailTemplate(announcement));
        showAFormAsModel();

    }).catch(err => console.log(err))
}

function showAFormAsModel() {
    let detailsDialog = $("#detailsDiv").dialog({
        height: 450,
        width: 750,
        title: 'Details',
        modal: true,
        buttons: {
            "ok": function () {
                detailsDialog.dialog("close");
            }
        }
    });
}

function displayAnnouncements(announcements) {
    let htmlTemplate = $('#announcements-template').html(),
        announcementTemplate = Handlebars.compile(htmlTemplate)
    $('#announcementsTableDiv').html(announcementTemplate({announcements}));
}