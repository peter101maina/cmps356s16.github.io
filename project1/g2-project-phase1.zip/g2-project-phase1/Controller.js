/**
 * Created by Sony Vaio on 4/20/2016.
 */

'use strict'
class Controller {
    constructor() {
        this.repository = require('./Repository.js');
    }

    login(req,res){
        let userInfo = req.body;
        this.repository.login(userInfo).then(user => {
            if (user.type==="parent"){
                user.redirectTo = '/homeParent.html';
                res.status(200).send(user) ;
            }
            else if (user.type==="coordinator"){
                user.redirectTo = '/homeCoordinator.html';
                res.status(200).send(user) ;
            }
            else{
                user.redirectTo='homeInstructor.html' ;
                res.status(200).send(user) ;
            }
        }).catch(err=>res.send(err)) ;
    }

    getParentStudents (req,res)
    {
        let qatariId = req.params.qatariId;
        this.repository.getParentStudents(parseInt(qatariId)).then(students => {
            res.json(students);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        }); 
        
        
    }

    getStudentAllTasks (req,res) 
    {

        let studentId = req.params.studentId;
        this.repository.getStudentAllTasks(parseInt(studentId)).then(tasks => {
            res.json(tasks);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    getStudentPendingTasks (req,res) 
    {

        let studentId = req.params.studentId;
        this.repository.getStudentPendingTasks(parseInt(studentId)).then(tasks => {
            res.json(tasks);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }


    getStudentCompleteTasks (req,res)
    {
        let studentId = req.params.studentId;
        this.repository.getStudentCompleteTasks(parseInt(studentId)).then(tasks => {
            res.json(tasks);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    getMessages (req,res)
    {
        let studentId = req.params.studentId;
        this.repository.getMessages(parseInt(studentId)).then(messages => {
            res.json(messages);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
        
    }

    getMessage(req,res){
        let id = req.params.id;
        this.repository.getMessage(id).then(message => {
            res.json(message);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    getAnnouncements(req,res)
    {
        this.repository.getAnnouncements().then(announcements => {
            res.json(announcements);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    getAnnouncement(req,res){
        let id = req.params.id;
        this.repository.getAnnouncement(id).then(announcement => {
            res.json(announcement);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    getTasks(req,res){
        this.repository.getTasks().then(tasks => {
            res.json(tasks);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    getPendingTasks(req,res){
        this.repository.getPendingTasks().then(tasks => {
            res.json(tasks);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    getCompleteTasks(req,res){
        this.repository.getCompleteTasks().then(tasks => {
            res.json(tasks);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    getStudents(req,res){
        this.repository.getStudents().then(students => {
            res.json(students);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    addStudent(req,res){
        let student = req.body;

        this.repository.addStudent(student).then((student)=> {
                let urlOfNewStudent = `/api/students/${student.studentId}`;
                res.location(urlOfNewStudent)
                res.status(201).send(`Created and available @ ${urlOfNewStudent}`);
            })
            .catch(err => res.status(500).send(err));
    }

    addAnnouncement(req,res){
        let announcement = req.body;

        this.repository.sendAnnouncement(announcement).then((announcement)=> {
                let urlOfNewAnnouncement = `/api/announcements/${announcement.id}`;
                res.location(urlOfNewAnnouncement);
                res.status(201).send(`Created and available @ ${urlOfNewAnnouncement}`);
            })
            .catch(err => res.status(500).send(err));
    }

    addMessage(req,res) {
        let message = req.body;

        this.repository.sendMessage(message).then((message)=> {
                let urlOfNewMessage = `/api/messages/${message.id}`;
                res.location(urlOfNewMessage);
                res.status(201).send(`Created and available @ ${urlOfNewMessage}`);
            })
            .catch(err => res.status(500).send(err));
    }

    addTask(req,res) {
        let task = req.body;

        this.repository.addTask(task).then((task)=> {
                let urlOfNewTask = `/api/tasks/${task.taskId}`;
                res.location(urlOfNewTask);
                res.status(201).send(`Created and available @ ${urlOfNewTask}`);
            })
            .catch(err => res.status(500).send(err));
    }

    updateTask(req,res) {
        let task = req.body;
        this.repository.updateTask(task).then(()=> {
                //let urlOfTask = `/api/tasks/${task.taskId}`;
                res.status(200).send('Successfully updated.');
            })
            .catch(err => res.status(500).send(err));
    }

    deleteTask(req,res) {
        let taskId = req.params.taskId;

        this.repository.deleteTask(parseInt(taskId)).then(() => {
            res.status(200).send('Successfully deleted.');
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });

        
    }

    getSurahs(req,res){
        this.repository.getSurahs().then(surahs => {
            res.json(surahs);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    getASurah(req,res){
        let surahId = req.params.id;

        this.repository.getASurah(parseInt(surahId)).then(surah => {
            res.json(surah);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    getATask (req,res)
    {
        let taskId = req.params.taskId;

        this.repository.getATask(parseInt(taskId)).then(task => {
            res.json(task);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
        
    }

    getInstructorStudents(req,res)
    {
        let teacherId = req.params.id ;
        this.repository.getInstructorStudents(parseInt(teacherId)).then(students => {
            res.json(students);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
        
    }

    getTeachers(req,res){
        this.repository.getTeachers().then(teachers => {
            res.json(teachers);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }
    

}

module.exports= new Controller() ;