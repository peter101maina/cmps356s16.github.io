/**
 * Created by Fatma on 16-Apr-16.
 */

"use strict"
class Repository {

    constructor() {
        this.fs = require('fs');
    }

    readFile(filepath) {
        return new Promise((resolve, reject)=> {
                this.fs.readFile(filepath, (err, data)=> {
                    if (err)
                        reject("error occurred: " + err);
                    else {
                        let json = JSON.parse(data);
                        resolve(json);
                    }
                });
            }
        );
    }

    login(user) {
        return new Promise((resolve, reject)=> {

            this.readFile('./data/parent.json').then(parents=> {

                let parent = parents.filter(p=>p.username == user.username && p.password == user.password)[0];

                if (parent != null) {
                    parent.type = "parent";
                    resolve(parent);
                }

                else //parent not found
                    return this.readFile('./data/teacher.json');//maybe a staff

            }).then(staffs=> {
                let staff = staffs.filter(s=>s.username === user.username && s.password === user.password)[0];

                if (staff != null) {
                    if (staff.isCoordinator == 1)
                        staff.type = "coordinator";
                    else
                        staff.type = "teacher";
                    resolve(staff);
                }
                else
                    reject("username or password unresolved...");

            }).catch(err => {
                reject(err);
            });
        });
    }

    writeToFile(path, data) {
        return new Promise((resolve, reject)=> {
            this.fs.writeFile(path, data, (err, data)=> {
                if (err)
                    reject(err);
                else
                    resolve("added");
            });
        });
    }

    getParents() {
        return new Promise((resolve, reject)=> {
            let filepath = './data/parent.json';
            this.readFile(filepath).then(parents=> {
                resolve(parents);
            }).catch(err=> {
                reject(err);
            });
        });
    }

    getTeachers() {
        return new Promise((resolve, reject)=> {
            let filepath = './data/teacher.json';
            this.readFile(filepath).then(teachers=> {
                resolve(teachers.filter(t=>t.isCoordinator != 1));
            }).catch(err=> {
                reject(err);
            });
        });
    }

    getSurahs() {
        return new Promise((resolve, reject)=> {
            let filepath = './data/surah.json';
            this.readFile(filepath).then(surahs=> {
                resolve(surahs);
            }).catch(err=> {
                reject(err);
            });
        });
    }

    getASurah(surahId) {
        return new Promise((resolve, reject)=> {
            let filepath = './data/surah.json';
            this.readFile(filepath).then(surah=> {
                surah = surah.filter(s=> s.id == surahId);
                resolve(surah);
            }).catch(err=> {
                reject(err);
            });
        });
    }

    getTasks() {
        return new Promise((resolve, reject)=> {
            let filepath = './data/task.json';
            this.readFile(filepath).then(tasks=> {
                resolve(tasks);
            }).catch(err=> {
                reject(err);
            });
        });
    }

    getStudents() {
        return new Promise((resolve, reject)=> {
            this.getParents().then(parents=> {
                let students = [];
                for (let parent of parents) {
                    for (let student of parent.students) {
                        students.push(student);
                    }
                }
                resolve(students);
            }).catch(err=>reject(err));
        });
    }

    getCompleteTasks() {
        return new Promise((resolve, reject)=> {
            this.getTasks().then(tasks=> {
                resolve(tasks.filter(t=> t.masteryLevel != null));
            }).catch(err=> {
                reject(err);
            })
        });
    }

    getPendingTasks() {
        return new Promise((resolve, reject)=> {
            this.getTasks().then(tasks=> {
                resolve(tasks.filter(t=> t.masteryLevel == null));
            }).catch(err=> {
                reject(err);
            })
        });
    }

    getParentStudents(parentId) {
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {
                parents = parents.filter(p => parentId === p.qatariId);
                let children = parents[0].students;
                resolve(children);

            }).catch(err => reject(err));
        });
    }

    getStudentAllTasks(studentId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks = tasks.filter(t => t.studentId === studentId);
                resolve(tasks);

            }).catch(err => reject(err));
        });

    }

    getStudentCompleteTasks(studentId) {
        return new Promise((resolve, reject) => {
            this.getCompleteTasks().then(tasks => {
                tasks = tasks.filter(t => t.studentId === studentId);
                resolve(tasks);

            }).catch(err => reject(err));
        });

    }

    getStudentPendingTasks(studentId) {
        return new Promise((resolve, reject) => {
            this.getPendingTasks().then(tasks => {
                tasks = tasks.filter(t => t.studentId === studentId);
                resolve(tasks);

            }).catch(err => reject(err));
        });

    }

    getAllMessages() {
        return new Promise((resolve, reject) => {
            this.readFile('./data/message.json').then(messages => {
                resolve(messages);
            }).catch(err => reject(err));

        });
    }

    getMessages(studentId) {
        return new Promise((resolve, reject) => {
            this.readFile('./data/message.json').then(messages => {
                messages = messages.filter(m=> m.studentId === studentId);
                resolve(messages);

            }).catch(err => reject(err));

        });
    }

    getMessage(id) {
        return new Promise((resolve, reject)=> {
            this.getAllMessages().then(messages=> {
                let message = messages.filter(m=>m.id == id)[0];
                resolve(message);
            }).catch(err=>reject(err));
        });
    }

    sendMessage(message) {
        return new Promise((resolve, reject) => {
            this.getAllMessages().then(messages => {
                let maxId = Math.max.apply(Math, messages.map(m => m.id)) + 1;
                message.id = maxId;
                messages.push(message);

                this.writeToFile('./data/message.json', JSON.stringify(messages)).then(() => resolve(message))
                    .catch(err => reject(err));
            }).catch(err => reject(err));
        });
    }


    getAnnouncements() {
        return new Promise((resolve, reject) => {
            this.readFile('./data/announcement.json').then(announcemnets => {
                resolve(announcemnets);
            }).catch(err => reject(err));

        });
    }

    getAnnouncement(id) {
        return new Promise((resolve, reject)=> {
            this.getAnnouncements().then(announcements=> {
                resolve(announcements.filter(a=>a.id == id)[0])
            }).catch(err=>reject(err));
        });
    }

    sendAnnouncement(announcement) {
        return new Promise((resolve, reject) => {
            this.getAnnouncements().then(announcements => {
                let maxId = Math.max.apply(Math, announcements.map(a => a.id)) + 1;
                announcement.id = maxId;
                announcements.push(announcement);
                this.writeToFile('./data/announcement.json', JSON.stringify(announcements)).then(()=> {
                        resolve(announcement);
                    })
                    .catch(err => reject(err));
            }).catch(err => reject(err));
        });
    }

    addStudent(parent) {
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {

                let existingParent = parents.filter(p => p.qatariId == parent.qatariId)[0];

                if (existingParent) {
                    let existingStudents = existingParent.students;
                    this.getStudents().then(students=> {
                        let maxId = Math.max.apply(Math, students.map(s => s.studentId)) + 1;
                        parent.student.studentId = maxId;
                        existingStudents.push(parent.student);
                        this.writeToFile('./data/parent.json', JSON.stringify(parents)).then(() => {
                            resolve(parent.student);
                        }).catch(err => reject(err));

                    }).catch(err => reject(err));
                }
                else {
                    this.getStudents().then(students=> {
                        let maxId = Math.max.apply(Math, students.map(s => s.studentId)) + 1;
                        parent.student.studentId = maxId;
                        parent.students = [];
                        parent.students.push(parent.student);
                        delete parent.student;

                        parents.push(parent);
                        this.writeToFile('./data/parent.json', JSON.stringify(parents)).then(() => {
                            resolve(parent.student);
                        }).catch(err => reject(err));

                    }).catch(err => reject(err));
                }


            }).catch(err => {
                reject(err);
            });
        });
    }


    getATask(taskId) {
        return new Promise((resolve, reject)=> {
            let filepath = './data/task.json';
            this.readFile(filepath).then(task=> {
                task = task.filter(t=> t.taskId == taskId);
                resolve(task);
            }).catch(err=> {
                reject(err);
            });
        });
    }

    addTask(task) {
        return new Promise((resolve, reject)=> {
            this.getTasks().then(tasks=> {
                let maxId = Math.max.apply(Math, tasks.map(t => t.taskId)) + 1;
                task.taskId = maxId;
                tasks.push(task);
                this.writeToFile("./data/task.json", JSON.stringify(tasks)).then(() => resolve(task)).catch(err=> {
                    reject(err);
                });
            }).catch(err=> {
                reject(err)
            });
        });
    }

    updateTask(task) {
        return new Promise((resolve, reject)=> {

            this.getTasks().then(tasks=> {

                let updatedTask = tasks.filter(t=>t.taskId == task.taskId)[0];
                updatedTask.taskId = task.taskId;
                updatedTask.studentId = task.studentId
                updatedTask.surahId = task.surahId
                updatedTask.surahName = task.surahName
                updatedTask.fromAya = task.fromAya
                updatedTask.toAya = task.toAya
                updatedTask.type = task.type
                updatedTask.dueDate = task.dueDate
                updatedTask.completedDate = task.completedDate
                updatedTask.masteryLevel = task.masteryLevel
                updatedTask.comment = task.comment

                this.writeToFile("./data/task.json", JSON.stringify(tasks));

            }).catch(err=> {
                reject(err);
            });

        });
    }

    deleteTask(taskId) {
        return new Promise((resolve, reject)=> {
            this.getTasks().then(tasks=> {
                let taskToCancel = tasks.filter(t=>t.taskId == taskId)[0];
                let index = tasks.indexOf(taskToCancel);
                tasks.splice(index, 1);
                this.writeToFile("./data/task.json", JSON.stringify(tasks));
            }).catch(err=> {
                reject(err);
            });
        });
    }


    getInstructorStudents(teacherId) {
        return new Promise((resolve, reject) => {
            this.getStudents().then(students=> {
                let instructorStudents;
                instructorStudents = students.filter(s=> s.teacherId == teacherId);
                resolve(instructorStudents);

            }).catch(err => reject(err));

        });
    }

}

module.exports = new Repository();

//new Repository().getMessage(3).then(m=>console.log(m)).catch(e=>console.log(e))