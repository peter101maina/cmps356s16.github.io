/**
 * Created by Fatma on 16-Apr-16.
 */

"use strict";
let express = require('express'),
    bodyParser = require('body-parser'),
//open = require('open');

//multer is a package used to ease uploading files
multer = require('multer'),
    path = require('path'),
    //node-uuid is a package to generate a unique identifier
    uuid = require('node-uuid');

let app = express();
//Allow serving static files
app.use(express.static(__dirname));

let port = 9080;

app.use(bodyParser.urlencoded({extended:true}));
//aut-deserialize the body of incoming request to a json object
app.use(bodyParser.json());
let options = multer.diskStorage(
    {
        destination : 'images/' ,
        filename: function (req, file, cb) {
            let fileName = file.originalname;
            cb(null, fileName);
        }
    });

app.post('/images', multer({ storage: options}).single('msgImage'), (req, res) => {

});

let controller = require('./Controller') ;

//login
app.post('/', (req, res) => controller.login(req,res));

//parent
app.get('/api/parents/:qatariId',(req,res)=>controller.getParentStudents(req,res)) ;
app.get('/api/tasks/all/:studentId',(req,res) => controller.getStudentAllTasks(req,res)) ;
app.get('/api/tasks/pending/:studentId',(req,res) => controller.getStudentPendingTasks(req,res)) ;
app.get('/api/tasks/complete/:studentId',(req,res) => controller.getStudentCompleteTasks(req,res)) ;
app.get('/api/messages/:studentId',(req,res) => controller.getMessages(req,res)) ;
app.get('/api/messages/:studentId/:id',(req,res) => controller.getMessage(req,res)) ;
app.get('/api/announcements',(req,res) => controller.getAnnouncements(req,res)) ;
app.get('/api/announcements/:id',(req,res) => controller.getAnnouncement(req,res)) ;

//coordinator
app.get('/api/students',(req,res) => controller.getStudents(req,res)) ;
app.get('/api/teachers',(req,res) => controller.getTeachers(req,res)) ;
app.get('/api/tasks/all',(req,res) => controller.getTasks(req,res)) ;
app.get('/api/tasks/pending',(req,res) => controller.getPendingTasks(req,res)) ;
app.get('/api/tasks/complete',(req,res) => controller.getCompleteTasks(req,res)) ;
app.post('/api/students',(req,res) => controller.addStudent(req,res)) ;
app.post('/api/announcements',(req,res) => controller.addAnnouncement(req,res)) ;

//instructor
app.post('/api/messages',(req,res) => controller.addMessage(req,res)) ;
app.post('/api/tasks',(req,res) => controller.addTask(req,res)) ;
app.get('/api/students/:id',(req,res) => controller.getInstructorStudents(req,res)) ;
app.put('/api/tasks/:taskId',(req,res) => controller.updateTask(req,res)) ;
app.delete('/api/tasks/:taskId', (req, res) => controller.deleteTask(req, res));
app.get('/api/surahs', (req, res) => controller.getSurahs(req, res));
app.get('/api/surahs/:id', (req, res) => controller.getASurah(req, res));
app.get('/api/tasks/:taskId',(req,res) => controller.getATask(req,res)) ;


app.listen(port, function(){
    console.log('HalaqaMetrash App is running my app on http://localhost:' + port);
});