/**
 * Created by adel on 4/22/16.
 */

'use strict'

class SurahRepository {
    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }



    getSurahs() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/surah.json').then(surah => {
                resolve(surah);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getSurahById(Id) {
        return new Promise((resolve, reject) => {
            this.getSurahs().then(surahs => {
                surahs = surahs.filter(s => s.id === Id);
                if (surahs.length > 0) {
                    resolve(surahs[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getNumberOfAya(type,ayaCount) {

        return new Promise((resolve, reject) => {


            this.getSurah(type).then(surahs => { surahs = surahs.filter(s => s.ayaCount>=ayaCount  );
                if (surahs.length > 0) {
                    resolve(surahs);
                }
                else {
                    reject("No records found");
                }
            })



        });
    }


}

module.exports = new SurahRepository();