/**
 * Created by adel on 4/22/16.
 */"use strict";
let express = require('express'),
    bodyParser = require('body-parser')
//open = require('open');

let app = express();
//Allow serving static files
app.use(express.static(__dirname));

let port = 9080;

app.use(bodyParser.urlencoded({extended:true}));
//aut-deserialize the body of incoming request to a json object
app.use(bodyParser.json());
let studentController = require('./Controller/StudentController');
let studentRepository = require('./StudentRepository');
let taskController = require('./Controller/TaskController');
let teacherController = require('./Controller/TeacherController');
let teacherRepository = require('./TeacherRepository');
let surahController = require('./Controller/SurahController');
let messageController = require('./Controller/MessageController');
let annoucementController = require('./Controller/AnnoucementController');


app.post('/', (req, res) => {
    let userInfo = req.body;
    console.log(userInfo);
    let count=0;

    studentRepository.getParents().then(parents => {
        for (let i = 0; i < parents.length; i++) {
            if (parents[i].username == userInfo.username && parents[i].password == userInfo.password) {
                userInfo = parents[i];
                count++;
                userInfo.redirectTo = '/Parent.html';
                console.log(userInfo);
                res.json(userInfo);
                break;
            }
        }
    });
    teacherRepository.getTeachers().then(teachers => {
            for (let i = 0; i < teachers.length; i++) {
                console.log(userInfo);

                if (teachers[i].username == userInfo.username && teachers[i].password ==userInfo.password ) {
                    userInfo=teachers[i];
                    count++;
                    if(teachers[i].isCoordinator)

                        userInfo.redirectTo = '/Coordinator.html';
                    else
                        userInfo.redirectTo = '/Tasks.html';

                    console.log(userInfo);
                    res.json(userInfo);
                    break;

                }
                else if(count==0 && i==(teachers.length-1)){
                    res.json(userInfo);
                }
            }
        }
    );
});
app.get('/api/parents', (req, res) => studentController.getParents(req, res));
app.post('/api/parents', (req, res) => studentController.addParent(req, res));
app.post('/api/students', (req, res) => studentController.addStudent(req, res));

app.get('/api/students', (req, res) => studentController.getStudents(req, res));
app.get('/api/students/:studentId', (req, res) => studentController.getStudent(req, res));
app.get('/api/studentsT/:teacherId', (req, res) => studentController.getStudentOfTeacher(req, res));

app.get('/api/parentschild/:username', (req, res) => studentController.getStudentOfParent(req, res));
app.get('/api/parents/:username', (req, res) => studentController.getParentByUN(req, res));


app.get('/api/tasks', (req, res) => taskController.getTasks(req, res));
app.get('/api/tasks/:taskId', (req, res) => taskController.getTask(req, res));

app.post('/api/tasks', (req, res) => taskController.addTask(req, res));
app.put('/api/tasks', (req, res) => taskController.updateTask(req, res));

app.delete('/api/tasks/:taskId', (req, res) => taskController.deleteTask(req, res));

app.get('/api/task/:type', (req, res) => taskController.getTaskByType(req, res));
app.get('/api/task/:studentId/:type', (req, res) => taskController.getTaskByStudentIdType(req, res));
app.get('/api/t/:studentId', (req, res) => taskController.getTaskByStudentId(req, res));
//app.get('/api/tU/:username', (req, res) => taskController.getTaskOfParentstudent(req, res));
app.get('/api/surahs/:id', (req, res) => surahController.getSurah(req, res));
app.get('/api/surahs', (req, res) => surahController.getSurahs(req, res));
app.get('/api/annoucements', (req, res) => annoucementController.getAnnoucements(req, res));
app.post('/api/annoucements', (req, res) => annoucementController.addAnnoucement(req, res));

app.get('/api/annoucements/:aId', (req, res) => annoucementController.getAnnoucement(req, res));
app.get('/api/messages', (req, res) => messageController.getMessages(req, res));
app.post('/api/messages', (req, res) => messageController.addMessage(req, res));

app.get('/api/messages/:messageId', (req, res) => messageController.getMessage(req, res));

app.get('/api/msg/:studentId', (req, res) => messageController.getMessageBySID(req, res));

app.get('/api/teachers/:username', (req, res) => teacherController.getTeacherByUN(req, res));
app.get('/api/teachers', (req, res) => teacherController.getTechers(req, res));
app.get('/api/teachersT', (req, res) => teacherController.getTeachersNoC(req, res));


app.listen(port, function(){
    console.log('Students App is running my app on http://localhost:' + port);
});