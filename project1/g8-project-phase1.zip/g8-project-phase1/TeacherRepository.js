/**
 * Created by adel on 4/22/16.
 */
'use strict'
class TeacherRepository {
    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }





    getTeachers() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(t => {

                resolve(t);
            }).catch(err => {
                reject(err);
            });
        });
    }
getTeachersNoC(){
    return new Promise((resolve, reject) => {
        this.getTeachers().then(teachers => {
            teachers = teachers.filter(t=> !(t.isCoordinator));
            if (teachers.length > 0) {
                resolve(teachers);
            }
            else {
                reject("No records found");
            }
        });
    });
}
    getTeacherByUN(username) {
        return new Promise((resolve, reject) => {
            this.getTeachers().then(teachers => {
                teachers = teachers.filter(t => t.username === username);
                if (teachers.length > 0) {
                    resolve(teachers[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getTeachersNoPass(){
        return new Promise((resolve, reject) => {
            this.getTeachers().then(teachers => {
                for(let t of teachers){
                    delete t.password;
                }
                if (teachers.length > 0) {
                    resolve(teachers);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getTeacherBySNO(staffNo) {
        return new Promise((resolve, reject) => {
            this.getTeachers().then(teachers => {
                teachers = teachers.filter(t => t.username === username);
                if (teachers.length > 0) {
                    resolve(teachers[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }


}
module.exports= new TeacherRepository();