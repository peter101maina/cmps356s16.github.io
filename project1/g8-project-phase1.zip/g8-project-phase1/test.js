/**
 * Created by adel on 4/26/16.
 */
'use strict'
let tas = require('./TeacherRepository');

tas.getTeachersNoC(502).then(student => {
    //Displays a pretty-printed multiline JSON representation indented with 2 spaces
    console.log(JSON.stringify(student, null, 2));
});