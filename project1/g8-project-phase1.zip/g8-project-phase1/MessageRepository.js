
'use strict'

class MessageRepository {
    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }



    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }

    getMessages() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/message.json').then(m => {
                resolve(m);
            }).catch(err => {
                reject(err);
            });
        });
    }


    getMessageById(messageId) {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                messages = messages.filter(m => m.messageId === messageId);
                if (messages.length > 0) {
                    resolve(messages[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getMessageBySID(studentId) {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                messages = messages.filter(m => m.studentId === studentId);
                if (messages.length > 0) {
                    resolve(messages);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    addMessage(message) {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                let maxId = Math.max.apply(Math, messages.map(m => m.messageId)) + 1;
                console.log("maxId", maxId);

                message.messageId = maxId;

                console.log("addMessage", message);
                messages.push(message);
                return this.writeJsonFile('./data/message.json', messages);
            }).then(()=> resolve(message))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }



}
module.exports= new MessageRepository();