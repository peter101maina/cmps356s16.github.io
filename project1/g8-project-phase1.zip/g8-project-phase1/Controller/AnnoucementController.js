
/**
 * Created by adel on 4/23/16.
 */

'use strict'
class AnnoucementController {
    constructor() {
        this.annoucementRepository = require('./../AnnoucementRepository');
    }

    getAnnoucements(req, res) {
        this.annoucementRepository.getAnnoucements().then(annoucements => {
            res.json(annoucements);
        });
    }

    getAnnoucement (req, res) {
        let aId = req.params.aId;
        console.log('req.params.aId', aId);
        this.annoucementRepository.getAnnoucementById(parseInt(aId)).then(annoucement => {
            console.log(JSON.stringify(annoucement, null, 2));
            res.json(annoucement);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }


    addAnnoucement(req, res) {
        let annoucement = req.body;

        this.annoucementRepository.addAnnoucement(annoucement).then((annoucement)=> {
                let urlOfNewAnnoucement= `/api/annoucements/${annoucement.aId}`;
                res.location(urlOfNewAnnoucement)
                res.status(201).send(`Created and available @ ${urlOfNewAnnoucement}`);
            })
    }


}

module.exports = new AnnoucementController();