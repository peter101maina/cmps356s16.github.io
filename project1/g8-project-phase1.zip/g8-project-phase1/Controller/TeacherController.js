/**
 * Created by adel on 4/23/16.
 */






'use strict'
class TeacherController{
    constructor() {
        this.teacherRepository = require('./../TeacherRepository.js');
    }

    getTechers(req, res) {
        this.teacherRepository.getTeachers().then(teachers => {
            res.json(teachers);
        });
    }



    getTeacherByUN (req, res) {
        let username = req.params.username;
        console.log('req.params.username', username);
        this.teacherRepository.getParentByUN(username).then(teacher => {
            console.log(JSON.stringify(teacher, null, 2));
            res.json(teacher);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    getTeachersNoC (req, res) {
        this.teacherRepository.getTeachersNoC().then(teachers => {
            res.json(teachers);
        });
    }
}

module.exports = new TeacherController();




