/**
 * Created by adel on 4/22/16.
 */
'use strict'
class StudentController{
    constructor() {
        this.studentRepository = require('./../StudentRepository.js');
    }

    getStudents(req, res) {
        this.studentRepository.getStudents().then(students => {
            res.json(students);
        });
    }
    getStudent(req, res) {
        let studentId=req.params.studentId
        this.studentRepository.getStudentById(studentId).then(student => {
            res.json(student);
        });
    }

    getParents(req, res) {
        this.studentRepository.getParents().then(parents => {
            res.json(parents);
        });
    }

    getParentByUN (req, res) {
        let username = req.params.username;
        console.log('req.params.username', username);
        this.studentRepository.getParentByUN(username).then(parent => {
            console.log(JSON.stringify(parent, null, 2));
            res.json(parent);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }
    getStudentOfTeacher (req, res) {
        let teacherId = req.params.teacherId;
        console.log('req.params.teacherId', teacherId);
        this.studentRepository.getStudentOfTeacher(parseInt(teacherId)).then(students => {
            console.log(JSON.stringify(students, null, 2));
            res.json(students);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }
    getStudentOfParent (req, res) {
        let username = req.params.username;
        console.log('req.params.username', username);
        this.studentRepository.getStudentOfParent(username).then(student => {
            console.log(JSON.stringify(student, null, 2));
            res.json(student);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    addParent(req, res) {
        let parent = req.body;

        this.studentRepository.addParent(parent).then((parent)=> {
                let urlOfNewParents = `/api/parents/${parent.username}`;
                res.location(urlOfNewParents)
                res.status(201).send(`Created and available @ ${urlOfNewParents}`);
            })
            .catch(err => res.status(500).send(err));
    }

    addStudent(req, res) {
        let student = req.body;

        this.studentRepository.addStudentToParent(student).then((student)=> {
                let urlOfNewS = `/api/students/${student.studentId}`;
                res.location(urlOfNewS)
                res.status(201).send(`Created and available @ ${urlOfNewS}`);
            })
            .catch(err => res.status(500).send(err));
    }

}

module.exports = new StudentController();
