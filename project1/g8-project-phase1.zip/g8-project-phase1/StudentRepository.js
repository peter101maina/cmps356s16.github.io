
'use strict'
class StudentRepository {
    constructor() {
        this.fs = require('fs');
    }
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }
    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }
    getParents() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(parents => {
              //  let teacherRepo= require('./TeacherRepository');
               // teacherRepo.getTeachersNoPass().then(teachers => {
                    for(let parent of parents)
                    { let students=parent.students;
                        //for(let student of students)
                        // {student.teacher = teachers.filter(t => t.staffNo === student.teacherId)[0];}
                    }

                    resolve(parents);
                }).catch(err => {
                    reject(err);
                });})
      //  });
    }
    getParentByUN(username) {
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {

                parents = parents.filter(p => p.username === username);
                if (parents.length > 0) {
                    resolve(parents[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getStudents(){
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {
                let students=[];
                for(var i=0;i<parents.length;i++){
                    for(var j=0;j<parents[i].students.length;j++)
                    {
                        students.push(parents[i].students[j]);}
                }
                if (students.length > 0) {
                    resolve(students);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getStudentOfTeacher(teacherId){
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                students = students.filter(s => s.teacherId === teacherId);
                if (students.length > 0) {
                    resolve(students);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getStudentOfParent(username){
        return new Promise((resolve, reject) => {
            this.getParentByUN(username).then(parent => {
                let students = parent.students;
                if (students.length > 0) {
                    resolve(students);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    addParent(parent) {
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {

                this.getStudents().then(students=>{
                    let maxId = Math.max.apply(Math, students.map(s => s.studentId)) + 1;
                    console.log("maxId", maxId);

                    for(let i=0;i<parent.students.length;i++)

                        parent.students[i].studentId=(i+maxId);

                    console.log("addParent", parent);
                    parents.push(parent);
                    return this.writeJsonFile('./data/student.json', parents);
                }).then(()=> resolve(parent))
                    .catch(err => {
                        console.log(err);
                        reject(err);
                    });});

        });
    }
    addStudentToParent(student) {
        return new Promise((resolve, reject) => {
            this.getParents().then(parents =>{
                let username=student.parentUserName;
                delete student.parentUserName;
                this.getParentByUN(username).then(parent =>{

                    this.getStudents().then(students=>{
                        this.getStudentOfParent(username).then(sib=>{
                            let maxId = Math.max.apply(Math, students.map(s => s.studentId)) + 1;
                            console.log("maxId", maxId);
                            student.studentId=maxId;

                            sib.push(student)
                            parent.students=sib;

                            console.log("add student to parent", parent);
                            for(let i=0; i<parents.length; i++){
                                if (parents[i].username == parent.username) {
                                    parents[i] = parent;
                                    break;
                                }
                            }
                            return this.writeJsonFile('./data/student.json', parents);
                        }).then(()=> resolve(student))
                            .catch(err => {
                                console.log(err);
                                reject(err);
                            });

                    });
                })
            })})


    }
    getStudentById(studentId){
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                students = students.filter(s => s.studentId === studentId);

                if (students.length > 0) {
                    resolve(students[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }


}
module.exports= new StudentRepository();