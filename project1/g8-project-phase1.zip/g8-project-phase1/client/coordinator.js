/**
 * Created by adel on 4/23/16.
 */
$(document).ready(function () {

    let user = JSON.parse(localStorage.user);
    $('#userFullname').html(user.firstName+" "+user.lastName);
    getStudents().then(students => {fillStudentsDD(students);fillStudentsDD2(students)})

        .catch(err => console.log(err));

    $('#studentsDD').on('change', onStudentChange);
    $('#studentsDD2').on('change', onStudentChange2);

    $('#send').on('click', addAnnoucenment);

});
function addAnnoucenment() {
    let annoucement = {
        title: $('#title').val(),
        message: $('#msg').val()
    };
    let url = "http://localhost:9080/api/annoucements/";
    let method = "post";

    fetch(url, {
        method: method,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(annoucement)
    }).then(() => {
        //After add/update then refresh the list
        alert("annoucenment added")
    });}
function getStudents(){
    let url = "http://localhost:9080/api/students";
    return fetch(url).then(response => response.json())
}
function onStudentChange(){
    let studentId=$(this).val();
    fetchTasks(studentId).then(tasks => {displayTasks(tasks)}).catch(err => console.log(err));

}
function fetchMessages(studentId) {
    let url = `http://localhost:9080/api/msg/${studentId}`;
    return fetch(url).then(response => response.json());
}
function onStudentChange2(){
    let studentId=$(this).val();
    fetchMessages(studentId).then(messages => {displayMessage(messages)}).catch(err => console.log(err));
}
function fillStudentsDD2(students) {
    for(let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName+" "+student.lastName
        }).appendTo($("#studentsDD2"))
    }
}
function fillStudentsDD(students) {
    for(let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName+" "+student.lastName
        }).appendTo($("#studentsDD"))
    }
}
function displayMessage(m) {
    let htmlTemplate = $('#message-template').html(),
        tTemplate = Handlebars.compile(htmlTemplate)
    $('#mess').html(tTemplate({m}));

}
function fetchTasks(studentId) {
    let url = `http://localhost:9080/api/t/${studentId}`;
    return fetch(url).then(response => response.json());
}
function displayTasks(tasks) {

    let htmlTemplate = $('#students-template').html(),
        sTemplate = Handlebars.compile(htmlTemplate)

    $('#studentTasks').html(sTemplate({tasks}));

}