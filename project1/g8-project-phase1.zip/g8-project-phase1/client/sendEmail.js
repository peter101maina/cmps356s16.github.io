/**
 * Created by adel on 4/25/16.
 */

'use strict'
$(document).ready(function () {
    let user = JSON.parse(localStorage.user);
    $('#userFullname').html(user.firstname+" "+user.lastname);
    getStudents(user.staffNo).then(students => fillstudentsDD(students))
        .catch(err => console.log(err));
    $('#sendM').on('click', sendM);
});

function fillstudentsDD(students) {
    for(let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName+" "+student.lastName
        }).appendTo($("#studentsDD"))
    }
}
function getStudents(teacherId){
    let url = `http://localhost:9080/api/studentsT/${teacherId}`;
    return fetch(url).then(response => response.json());
}


function sendM() {
    let user = JSON.parse(localStorage.user);
    let stNo=user.staffNo;
    let messages = {
        studentId:parseInt($('#studentsDD').val()),
        teacherId:stNo,
        title:$('#title').val(),
        message:$('#msg').val()
    }
    let url = "http://localhost:9080/api/messages/";
    let method = "post";
    fetch(url, {
        method: method,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(messages)
    }).then(() => {
        //After add/update then refresh the list
        alert(" added")
        window.location="/Task.html";
    });
}