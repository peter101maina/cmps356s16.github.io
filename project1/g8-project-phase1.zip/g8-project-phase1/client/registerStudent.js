/**
 * Created by adel on 4/25/16.
 */

'use strict'
$(document).ready(function () {
    let user = JSON.parse(localStorage.user);
    $('#userFullname').html(user.firstname+" "+user.lastname);
    getParents().then(parents => fillParentsDD(parents)).catch(err => console.log(err));
    getTeachers().then(teachers => fillTeacherDD(teachers)).catch(err => console.log(err));
    $('#send').on('click', addStudent);
});
function fillTeacherDD(teachers) {
    for(let teacher of teachers) {
        $("<option>", {
            value: teacher.staffNo,
            text: teacher.halaqa+ "teacher Name: "+teacher.firstName
        }).appendTo($("#teachersDD"))
    }
}
function fillParentsDD(parents) {
    for(let parent of parents) {
        $("<option>", {
            value: parent.username,
            text: parent.firstName+" "+parent.lastName
        }).appendTo($("#parentsDD"))
    }
}
function addStudent() {
    let student={
        firstName:$('#firstName').val(),
        lastName:$('#lastName').val(),
        dob:$('#dob').val(),
        gender:$('#gender').val(),
        schoolGrade:$('#schoolgrade').val(),
        teacherId:$('#teachersDD').val(),

        parentUserName:$('#parentsDD').val()
    }
    let url = "http://localhost:9080/api/students/";
    let method = "post";

    fetch(url, {
        method: method,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(student)
    }).then(() => {
        //After add/update then refresh the list
        alert("student added")
        window.location="/Coordinator.html";
    });
}

function getTeachers(){
    let url = "http://localhost:9080/api/teachersT";
    return fetch(url).then(response => response.json());
}

function getParents(){
    let url = "http://localhost:9080/api/parents";
    return fetch(url).then(response => response.json());
}