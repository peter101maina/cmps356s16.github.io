/**
 * Created by adel on 4/24/16.
 */
$(document).ready(function () {

    let user = JSON.parse(localStorage.user);
    $('#userFullname').html(user.firstName+" "+user.lastName);
    getStudents(user.username).then(students => {fillStudentsDD(students);fillStudentsDD2(students)}).catch(err => console.log(err));
    $('#studentsDD').on('change', onStudentChange);
    $('#studentsDD2').on('change', onStudentChange2);

    getAnnoucenments();

    $('#message').on('click', showMessage);
});
function fetchMessages(studentId) {
    let url = `http://localhost:9080/api/msg/${studentId}`;
    return fetch(url).then(response => response.json());
}
function getStudents(username){
    let url = `http://localhost:9080/api/parentschild/${username}`
    return fetch(url).then(response => response.json())
}
function getTasks(user) {
    fetchTasks(user.username).then(tasks=>displayTasks(tasks) )
        .catch(err => console.log(err));
}
function onStudentChange2(){
    let studentId=$(this).val();
    fetchMessages(studentId).then(messages => {displayMessage(messages)}).catch(err => console.log(err));
}
function displayMessage(m) {
    let htmlTemplate = $('#message-template').html(),
        tTemplate = Handlebars.compile(htmlTemplate)
    $('#mess').html(tTemplate({m}));

}
function onStudentChange(){
    let studentId=$(this).val();
    fetchTasks(studentId).then(tasks => {displayTasks(tasks)}).catch(err => console.log(err));

}
function fillStudentsDD2(students) {
    for(let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName+" "+student.lastName
        }).appendTo($("#studentsDD2"))
    }
}
function fillStudentsDD(students) {
    for(let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName+" "+student.lastName
        }).appendTo($("#studentsDD"))
    }
}
function getAnnoucenments()
{
    fetchAnnoucenments().then(ann=>displayAnoucenments(ann) )
        .catch(err => console.log(err));

}
function fetchAnnoucenments() {

    let url = `http://localhost:9080/api/annoucements`;
    return fetch(url).then(response => response.json());
}

function fetchTasks(studentId) {
    let url = `http://localhost:9080/api/t/${studentId}`;
    return fetch(url).then(response => response.json());
}
function displayTasks(tasks) {

    let htmlTemplate = $('#students-template').html(),
        sTemplate = Handlebars.compile(htmlTemplate)

    $('#studentTasks').html(sTemplate({tasks}));

}
function displayAnoucenments(ann) {

    let htmlTemplate = $('#annoucen-template').html(),
        aTemplate = Handlebars.compile(htmlTemplate)

    $('#annouce').html(aTemplate({ann}));

}