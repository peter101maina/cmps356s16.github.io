/**
 * Created by adel on 4/24/16.
 */

$(document).ready(function () {

    let user = JSON.parse(localStorage.user);
    $('#userFullname').html(user.firstName+" "+user.lastName);
    $('#studentsDD').on('change', onStudentChange);
    getStudents(user.username).then(students => {fillStudentsDD(students);})

        .catch(err => console.log(err));
});
function fillStudentsDD(students) {
    for(let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName+" "+student.lastName
        }).appendTo($("#studentsDD"))
    }
}
function getStudents(username){
    let url = `http://localhost:9080/api/parentschild/${username}`;
    return fetch(url).then(response => response.json());
}
function onStudentChange(){
    let studentId=$(this).val();
    fetchMessages(studentId).then(messages => {displayMessage(messages)}).catch(err => console.log(err));
}

function fetchMessages(studentId) {
    let url = `http://localhost:9080/api/msg/${studentId}`;
    return fetch(url).then(response => response.json());
}


function displayMessage(m) {
    let htmlTemplate = $('#message-template').html(),
        tTemplate = Handlebars.compile(htmlTemplate)
    $('#mess').html(tTemplate({m}));

}