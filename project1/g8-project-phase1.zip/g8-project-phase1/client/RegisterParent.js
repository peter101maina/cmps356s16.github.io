/**
 * Created by adel on 4/25/16.
 */
'use strict'
$(document).ready(function () {

    let user = JSON.parse(localStorage.user);
    $('#userFullname').html(user.firstname+" "+user.lastname);
    getTeachers().then(teachers => fillTeacherDD(teachers)).catch(err => console.log(err));

    $('#register').on('click', registerParent);

});
function fillTeacherDD(teachers) {
    for(let teacher of teachers) {
        $("<option>", {
            value: teacher.staffNo,
            text: teacher.halaqa+ "teacher Name: "+teacher.firstName
        }).appendTo($("#teachersDD"))
    }
}
function getTeachers(){
    let url = "http://localhost:9080/api/teachersT";
    return fetch(url).then(response => response.json());
}
function registerParent(){

    let parent={
        qatariId:$('#qatarId').val(),
        firstName:$('#PfirstName').val(),
        lastName:$('#PlastName').val(),
        mobile:$('#mobileNo').val(),
        email:$('#email').val(),
        username:$('#userName').val(),
        password:$('#userPassword').val(),
        students:[{
        firstName:$('#firstName').val(),
        lastName:$('#lastName').val(),
        dob:$('#dob').val(),
        gender:$('#gender').val(),
        schoolGrade:$('#schoolgrade').val(),
            teacherId:$('#teachersDD').val(),
        parentUserName:$('#parentsDD').val()}]
    }
    let url = "http://localhost:9080/api/parents/";
    let method = "post";

    fetch(url, {
        method: method,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(parent)
    }).then(() => {
        //After add/update then refresh the list
        alert("parent added")
        window.location="/Coordinator.html";
    });
}