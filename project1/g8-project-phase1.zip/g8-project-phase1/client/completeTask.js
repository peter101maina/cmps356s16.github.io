/**
 * Created by adel on 4/26/16.
 */
$(document).ready(function () {

    let user = JSON.parse(localStorage.user);
    $('#userFullname').html(user.firstName+" "+user.lastName);
    let taskId = JSON.parse(localStorage.tIdC);

    $('#taskID').html(taskId);
    $('#complete').on('click', updateTask);


});
function fetchTask(taskId) {
    let url = `http://localhost:9080/api/tasks/${taskId}`;
    return fetch(url).then(response => response.json());
}

function updateTask(){
    let taskId = JSON.parse(localStorage.tIdC);

    fetchTask(taskId).then(taskOld=>{  let task = {
            taskId:taskOld.taskId,
            studentId:taskOld.studentId,
            surahId:taskOld.surahId,
            surahName:taskOld.surahName,
            fromAya:taskOld.fromAya,
            toAya:taskOld.toAya,
            type:taskOld.type,
            dueDate:taskOld.dueDate,
            completedDate:$('#cd').val(),
            "masteryLevel":$('#mLevel').val(),
            "comment":$('#comm').val()

        }
            let url = "http://localhost:9080/api/tasks/";
            let method = "put";

            fetch(url, {
                method: method,
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(task)
            }).then(() => {
                //After add/update then refresh the list
                alert("task updated")
                window.location="/Task.html";
            });} )
        .catch(err => console.log(err));


}