/**
 * Created by adel on 4/26/16.
 */
$(document).ready(function () {

    let user = JSON.parse(localStorage.user);
    $('#userFullname').html(user.firstName+" "+user.lastName);
    localStorage.teacherId= JSON.stringify(user.staffNo)
    getStudents(user.staffNo).then(students => fillStudentDD(students))
    getTasks();

    $('#studentDD').on('change', onChange);
    $('#type').on('change', onChange);

    $('#updateTask').on('click',updateTsak);
    $('#tasks-list').on('click', 'a.deleteButton', deleteTask);

});

function onChange() {

    let type = $(this).val();
    let studentId=$('#studentDD').val();

        fetchTasks(studentId,type).then(tasks => {displayTasks(tasks)}).catch(err => console.log(err));


}

function getTasks(){
    fetchTasks2().then(tasks=>displayTasks(tasks) )
        .catch(err => console.log(err));
}
function fetchTasks2(){
    let url = "http://localhost:9080/api/tasks";
    return fetch(url).then(response => response.json());
}
function fillStudentDD(students) {
    for(let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName+" "+student.lastName
        }).appendTo($("#studentDD"))
    }
}
function completeTsak(taskId){
    localStorage.tIdC=JSON.stringify(taskId);
    window.location='../completeTask.html'
}
function getStudents(teacherId){
    let url = `http://localhost:9080/api/studentsT/${teacherId}`;
    return fetch(url).then(response => response.json());
}
function onStudentChange() {
    let studentId = $(this).val();
    let type=$('#type').val()
    fetchTasks(studentId,type).then(tasks => {displayTasks(tasks)}).catch(err => console.log(err));

}

function updateTsak(taskId){

    localStorage.tId=JSON.stringify(taskId);

    window.location='updateTask.html'
}
function getTasks(studentId) {
    fetchTasks(studentId).then(tasks=>displayTasks(tasks) )
        .catch(err => console.log(err));
}



function fetchTasks(studentId,type) {
    let url = `http://localhost:9080/api/task/${studentId}/${type}`;
    return fetch(url).then(response => response.json());
}

function displayTasks(tasks) {

    let htmlTemplate = $('#tasks-template').html(),
        sTemplate = Handlebars.compile(htmlTemplate)

    $('#tasks-list').html(sTemplate({tasks}));

}
function deleteTask(event) {
    event.preventDefault();
    if (!confirm('Confirm Cancel?')) {
        return;
    }
    let taskId = $(this).attr('data-taskId');

    let url = `http://localhost:9080/api/tasks/${taskId}`;
    fetch(url, {method: 'delete'}).then(() => {
        //After successful delete remove the row from the HTML table
        $(this).closest('tr').remove();
    }).then(() => {
        //After delete then refresh the list
        getTasks();
    });
}
