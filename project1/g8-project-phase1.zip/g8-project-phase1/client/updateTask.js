/**
 * Created by adel on 4/26/16.
 */
$(document).ready(function () {

    let teacherId = JSON.parse(localStorage.teacherId);
    let tID=JSON.parse(localStorage.tId)

    $('#tID').html(tID);
    getSurahs().then(surahs => {var allS= surahs;fillSurahsDD(surahs)})

        .catch(err => console.log(err));
    getStudents(teacherId).then(students => fillStudentsDD(students))

        .catch(err => console.log(err));
    $('#surahsDD').on('change', onSurahChange);
    $('#update').on('click', updateTask);

    $("#fromAya").on('change', onAyaChange);
});

function empty(){
    $('#fromAya').val(1);
    $('#toAya').val(1);
    $('#valFAya').val(1);
    $('#valTAya').val(1)

    ;
}
function getStudents(){
    let url = "http://localhost:9080/api/students";
    return fetch(url).then(response => response.json())
}
function changeToAya(ayaMin){
    $('#toAya').val(ayaMin);
    $('#valTAya').val(ayaMin)
    ;
}
function onAyaChange(){
    let ayaMin=$(this).val()

    $('#toAya').attr('min',parseInt(ayaMin))
    $('#valTAya').val(parseInt(ayaMin))
    changeToAya(ayaMin)


}
function onSurahChange(){
    empty();
    let id=$(this).val()
    getSurah(id).then(surah=> {$('#fromAya').attr('max',surah.ayaCount)
        $('#toAya').attr('max',surah.ayaCount)}).catch(err => console.log(err));
}
function fillSurahsDD(surahs) {
    for(let surah of surahs) {
        $("<option>", {
            value: surah.id,
            text: surah.englishName
        }).appendTo($("#surahsDD"))
    }
}
function fillStudentsDD(students) {
    for(let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName+" "+student.lastName
        }).appendTo($("#studentsDD"))
    }
}
function getSurah(id){
    let url = `http://localhost:9080/api/surahs/${id}`;
    return fetch(url).then(response => response.json())
}
function getSurahs(){
    let url = "http://localhost:9080/api/surahs";
    return fetch(url).then(response => response.json())
}
function fetchTask(taskId) {
    let url = `http://localhost:9080/api/tasks/${taskId}`;
    return fetch(url).then(response => response.json());
}

function  updateTask(){
    let taskId = JSON.parse(localStorage.tId);

    let id=$('#surahsDD').val();
    getSurah(id).then(surah=>{let sId=parseInt($('#studentsDD').val());
        let task = {
            taskId:taskId,
            studentId:sId,
            surahId:$('#surahsDD').val(),
            surahName:surah.englishName,
            fromAya:$('#fromAya').val(),
            toAya:$('#toAya').val(),
            type:$('input[name=type]:checked').val(),
            dueDate:$('#dd').val(),
        }
        let url = "http://localhost:9080/api/tasks/";
        let method = "put";

        fetch(url, {
            method: method,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(task)
        }).then(() => {
            //After add/update then refresh the list
            alert("task updated")
            window.location="/Task.html";
        });}).catch(err => console.log(err));


}

function getStudents(teacherId){
    let url = `http://localhost:9080/api/studentsT/${teacherId}`;
    return fetch(url).then(response => response.json());
}