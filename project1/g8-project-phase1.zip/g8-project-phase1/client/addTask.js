/**
 * Created by adel on 4/26/16.
 */
'use strict'
$(document).ready(function () {

    let teacherId=JSON.parse(localStorage.teacherId);
    $('#teacher').html(teacherId);

    getSurahs().then(surahs => {var allS= surahs;fillSurahsDD(surahs)})

        .catch(err => console.log(err));
    getStudents(teacherId).then(students => fillStudentsDD(students))

        .catch(err => console.log(err));
    $('#surahsDD').on('change', onSurahChange);
    $('#add').on('click', addTask);
    defaultDate()

    $("#fromAya").on('change', onAyaChange);


});
function empty(){
    $('#fromAya').val(1);
    $('#toAya').val(1);
    $('#valFAya').val(1);
    $('#valTAya').val(1)

    ;
}
function defaultDate(){
let nextDay=new Date(new Date().getTime()+24*60*60*1000)
    let day= nextDay.getDate(),month= nextDay.getMonth()+1,year=nextDay.getFullYear();
    if(day<10){
        day='0'+day
    }
    nextDay=month+'/'+day+'/'+year;
    $('#dd').val(new Date(year,month,day))
}

function getStudents(teacherId){
    let url = `http://localhost:9080/api/studentsT/${teacherId}`;
    return fetch(url).then(response => response.json());
}
function changeToAya(ayaMin){
    $('#toAya').val(ayaMin);
    $('#valTAya').val(ayaMin)
    ;
}

function onAyaChange(){
    let ayaMin=$(this).val()

    $('#toAya').attr('min',parseInt(ayaMin))
    $('#valTAya').val(parseInt(ayaMin))
    changeToAya(ayaMin)


}
function onSurahChange(){
    empty();
    let id=$(this).val()
    getSurah(id).then(surah=> {$('#fromAya').attr('max',surah.ayaCount)
        $('#toAya').attr('max',surah.ayaCount)}).catch(err => console.log(err));
}
function fillSurahsDD(surahs) {
    for(let surah of surahs) {
        $("<option>", {
            value: surah.id,
            text: surah.id+" "+surah.englishName+" ("+surah.ayaCount+" Aya)"
        }).appendTo($("#surahsDD"))
    }
}
function fillStudentsDD(students) {
    for(let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName+" "+student.lastName
        }).appendTo($("#studentsDD"))
    }
}
function  addTask(){
    let id=$('#surahsDD').val();
    getSurah(id).then(surah=>{    let sId=parseInt($('#studentsDD').val());
        let task = {
        studentId:sId,
        surahId:$('#surahsDD').val(),
        surahName:surah.englishName,
        fromAya:$('#fromAya').val(),
        toAya:$('#toAya').val(),
        type:$('input[name=type]:checked').val(),
        dueDate:$('#dd').val(),
    }
        let url = "http://localhost:9080/api/tasks/";
        let method = "post";

        fetch(url, {
            method: method,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(task)
        }).then(() => {
            //After add/update then refresh the list
            alert("task added")
            window.location="/Task.html";
        });}).catch(err => console.log(err));


}
function getSurah(id){
    let url = `http://localhost:9080/api/surahs/${id}`;
    return fetch(url).then(response => response.json())
}
function getSurahs(){
        let url = "http://localhost:9080/api/surahs";
        return fetch(url).then(response => response.json())
}