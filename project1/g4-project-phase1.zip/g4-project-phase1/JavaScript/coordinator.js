/**
 * Created by Alya on 4/25/2016.
 */
'use strict'
$(document).ready(function(){
    getchildren().then(children => fillChildrenDD(children))
        .catch(err => console.log(err));


    $("#ChildrenDD").on('change', onStudentChange);
    // $("#msgs_button").on('click', showMsgs);
    // $("#regionsDD").on('change', onRegionChange);
});

function getchildren() {
    let url = "http://localhost:9090/all_children";
    return fetch(url).then(response => response.json());
}

function getchildren() {
    let url = "http://localhost:9090/all_children";
    return fetch(url).then(response => response.json());
}
function getStudent(studnetId) {
    let url = `http://localhost:9090/tasks/${studnetId}`;
    return fetch(url).then(response => response.json());
}
function getmsgs(studnetId) {
    let url = `http://localhost:9090/msgs/${studnetId}`;
    return fetch(url).then(response => response.json());
}
function getAnnouncments() {
    let url = "http://localhost:9090/announcment";
    return fetch(url).then(response => response.json());
}
function showMsgs() {
    $("#msg-list").show();
    let student = $("#ChildrenDD").val();

    getmsgs(student).then(msgs => {
        displayMsgs(msgs);
    }).catch(err => console.log(err));
}

function onStudentChange() {
    // $("#msgs_button").show();
    // $("#msg-list").hide();
    let selectedStudent = $(this).val();
    getStudent(selectedStudent).then(studnet => {
        displayStudenttask(studnet);
        getmsgs(selectedStudent).then(msgs => {
            showMsgs(msgs);
        }).catch(err => console.log(err))
    }).catch(err => console.log(err))
}

function fillChildrenDD(children) {
    for(let child of children) {
        $("<option>", {
            value: child.studentId,
            text: child.firstName +"  "+ child.lastName
        }).appendTo($("#ChildrenDD"))
    }
}
function displayStudenttask(tasks) {

     console.log(tasks);
    let htmlTemplate = $('#task-template').html(),
        requestsTemplate = Handlebars.compile(htmlTemplate)
    // console.log(announcments);

    $('#task-list').html(requestsTemplate({tasks}));
}
function displayMsgs(msgs) {

    // console.log(annoucments);

    let htmlTemplate = $('#msg-template').html(),
        requests = Handlebars.compile(htmlTemplate)
    // console.log(announcments);

    $('#msg-list').html(requests({msgs}));
}

function addMsg() {
    let htmlTemplate = $('#msg-form-template').html(),
        heroTemplate = Handlebars.compile(htmlTemplate);

    $('#msg-form').html(heroTemplate({}));
    // showFormAsModel();
    savemsg();
}
function showFormAsModel() {
    let form = $( '#msg-form' ).dialog({
        height: 450,
        width: 750,
        title: 'msg Form',
        modal: true,
        buttons: {
            "submit": function() {
                savemsg();
                form.dialog( "close" );
            },
            Cancel: function() {
                form.dialog( "close" );
            }
        }
    });
}
function savemsg() {
    let msg = {
        date: $('#date').val(),
        title: $('#title').val(),
        body: $('#body').val()
    };
    console.log(msg);
    // repository.addAnnouncment(msg);
    let url = "http://localhost:9090/announcment";
    let requestMethod = "post";

    fetch(url, {
        method: 'post',
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(msg)
    }).then(() => {
        // After add/update then refresh the list
        getAnnouncments();
    });
}
function saveRequest() {
    let url = "http://localhost:9090/announcment";
    let requestMethod = "post";

    let msg = {
        date: $('#date').val(),
        title: $('#title').val(),
        body: $('#body').val()
    };
    console.log(msg);
    requestMethod = "post";
    console.log(msg);
    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(msg)
    }).then(() => {
        alert("announcmnet added successfully");
        window.location.href = 'http://localhost:9090/coordinator.html';
    });

    alert("announcmnet added successfully");
    getAnnouncments();
    // history.back();
}
