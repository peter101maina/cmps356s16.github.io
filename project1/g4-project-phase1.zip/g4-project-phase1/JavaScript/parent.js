/**
 * Created by Alya on 4/25/2016.
 */
'use strict';

$(document).ready(function () {
    let user = JSON.parse(localStorage.user);
    $('#userFullName').html(user.username);
    getAnnouncement().then(announcemnets=>displayAnnouncment(announcemnets));
    getChildren(user.username).then(children => fillChildrenDD(children));
    $("#ChildrenDD").on('change', onStudentChange);

});




function getAnnouncement() {
    let url = "http://localhost:9090/announcment";
    return fetch(url).then(response => response.json());


}
function displayAnnouncment(annoucments) {

    // console.log(annoucments);

    let htmlTemplate = $('#announcment-template').html(),
        requestsTemplate = Handlebars.compile(htmlTemplate)
    // console.log(announcments);

    $('#announcment-list').html(requestsTemplate({annoucments}));
}

function  getChildren(username) {
    let url = `http://localhost:9090/parent/children/${username}`;
    return fetch(url).then(response => response.json());


}
function getStudent(studnetId) {
    let url = `http://localhost:9090/tasks/${studnetId}`;
    return fetch(url).then(response => response.json());
}
function getmsgs(studnetId) {
    let url = `http://localhost:9090/msgs/${studnetId}`;
    return fetch(url).then(response => response.json());
}
function showMsgs() {
    $("#msg-list").show();
    let student = $("#ChildrenDD").val();

    getmsgs(student).then(msgs => {
        displayMsgs(msgs);
    }).catch(err => console.log(err));
}

function onStudentChange() {
    // $("#msgs_button").show();
    // $("#msg-list").hide();
    let selectedStudent = $(this).val();
    getStudent(selectedStudent).then(studnet => {
        displayStudenttask(studnet);
        getmsgs(selectedStudent).then(msgs => {
            showMsgs(msgs);
        }).catch(err => console.log(err))
    }).catch(err => console.log(err))
}

function fillChildrenDD(children) {
    for(let child of children) {
        $("<option>", {
            value: child.studentId,
            text: child.firstName +"  "+ child.lastName
        }).appendTo($("#ChildrenDD"))
    }
}
function displayStudenttask(tasks) {

    console.log(tasks);
    let htmlTemplate = $('#task-template').html(),
        requestsTemplate = Handlebars.compile(htmlTemplate)
    // console.log(announcments);

    $('#task-list').html(requestsTemplate({tasks}));
}
function displayMsgs(msgs) {

    // console.log(annoucments);

    let htmlTemplate = $('#msg-template').html(),
        requests = Handlebars.compile(htmlTemplate)
    // console.log(announcments);

    $('#msg-list').html(requests({msgs}));
}
