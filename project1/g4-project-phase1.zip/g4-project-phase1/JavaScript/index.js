/**
 * Created by Alya on 4/24/2016.
 */

'use strict'

$(document).ready(function () {
    $('#login').on('click', redirect);
});

function redirect(event) {
    event.preventDefault();

    let userInfo = {
        username: $('#username').val(),
        password: $('#password').val(),
    };
    userInfo.requestedPage = isParentCordinatorOrTeacher(userInfo.username);


    // console.log(userInfo);
    let isCorrect;

    localStorage.user = JSON.stringify(userInfo);

    if (userInfo.requestedPage == 'teacher'){
        userInfo.redirectTo = '/teacher.html';
        verifyTeacher(userInfo).then(response => {
            // console.log(response);
            isCorrect=response;
            if (isCorrect === false)
                alert("Enter a correct password");
            else
                window.location = userInfo.redirectTo;
        });}
    if (userInfo.requestedPage == 'coordinator'){
        userInfo.redirectTo = '/coordinator.html';
        verifyCoord(userInfo).then(response => {
            // console.log(response);
            isCorrect=response;
            if (isCorrect === false)
                alert("Enter a correct password");
            else
                window.location = userInfo.redirectTo;
        });}
    if (userInfo.requestedPage == 'parent'){
        userInfo.redirectTo = '/parent.html';
        verifyParent(userInfo).then(response => {
            // console.log(response);
            isCorrect=response;
            if (isCorrect === false)
                alert("Enter a correct password");
            else
                window.location = userInfo.redirectTo;
        });}

}

function isParentCordinatorOrTeacher(username) {

    if (username.startsWith("coordinator"))
        return "coordinator";
    if (username.startsWith("teacher"))
        return "teacher";
    else
        return "parent";

}

function verifyCoord(userInfo) {

    return new Promise((resolve, reject) => {
        getCoirdinatorId(userInfo.username).then(staff => {

            staff.userId = parseInt(staff.staffNo);

            return getCoordinator(staff.userId);
        }).then(staff => {
            let isCorrect = false;

            if (userInfo.password == staff.password) {
                isCorrect = true;
            }
            resolve(isCorrect);

        });
    }).catch( err => {alert("User dosens't exist")});

}



function verifyTeacher(userInfo) {

    return new Promise((resolve, reject) => {
        getTeacherId(userInfo.username).then(staff => {

            staff.userId = parseInt(staff.staffNo);

            return getTeacher(staff.userId);
        }).then(staff => {
            let isCorrect = false;

            if (userInfo.password == staff.password) {
                isCorrect = true;
            }
            resolve(isCorrect);

        });
    }).catch( err => {alert("User dosens't exist")});

}

function verifyParent(userInfo) {

    return new Promise((resolve, reject) => {
        getParentId(userInfo.username).then(staff => {

            staff.qatariId = parseInt(staff.userId);
            // console.log('staff.userId',staff.userId);
            return getParent(staff.userId);
        }).then(staff => {
            let isCorrect ;
            if (userInfo.password == staff.password) {
                isCorrect = true;
            }
            resolve(isCorrect);

        });
    }).catch( err => {alert("User dosens't exist")});

}
function getCoordinator(staffno) {
    let url = `http://localhost:9090/coordinator/${staffno}`;
    return fetch(url).then(response => response.json());
}
function getCoirdinatorId(username) {
    let url = `http://localhost:9090/coordinator/users/${username}`;
    return fetch(url).then(response => response.json());
}

function getTeacher(staffNo) {
    let url = `http://localhost:9090/teacher/${staffNo}`;
    return fetch(url).then(response => response.json());
}
function getTeacherId(username) {
    let url = `http://localhost:9090/teacher/users/${username}`;
    return fetch(url).then(response => response.json());
}
function getParent(staffNo) {
    let url = `http://localhost:9090/parent/${staffNo}`;
    return fetch(url).then(response => response.json());
}

function getParentId(username) {
    let url = `http://localhost:9090/parent/users/${username}`;
    return fetch(url).then(response => response.json());
}