/**
 * Created by Alya on 4/29/2016.
 */
'use strict'
$(document).ready(function () {
});
function getAllParents(){
    let url = "http://localhost:9090/parent";
    return fetch(url).then(response => response.json());
}
function getAllTeachers(){
    let url = "http://localhost:9090/teacher";
    return fetch(url).then(response => response.json());
}
function addChild() {
    // let user1 = JSON.parse(localStorage.user);
    let htmlTemplate = $('#add-form-template').html(),
        taskTemplate = Handlebars.compile(htmlTemplate);

    $('#task-form').html(taskTemplate({}));
    // showFormAsModel();
    getAllParents().then(parents => fillParentDD(parents));
    getAllTeachers().then(teachers => fillTeacherDD (teachers));
    // getChildren(user1.username).then(children => fillChildrenTDD(children));
    //savetask();
}
function addPChild() {
    // let user1 = JSON.parse(localStorage.user);
    let htmlTemplate = $('#addp-form-template').html(),
        taskTemplate = Handlebars.compile(htmlTemplate);

    $('#taskp-form').html(taskTemplate({}));
    // showFormAsModel();
    // getAllParents().then(parents => fillParentDD(parents));
    getAllTeachers().then(teachers => fillTeacherDDc (teachers));
    // getChildren(user1.username).then(children => fillChildrenTDD(children));
    //savetask();
}
function fillParentDD(parents) {
    for(let p of parents) {
        $("<option>", {
            value: p.qatariId,
            text: p.firstName +"  "+ p.lastName
        }).appendTo($("#parentDD"))
    }
}
function fillTeacherDD(teachers) {
    for(let t of teachers) {
        $("<option>", {
            value: t.staffNo,
            text: t.firstName +"  "+ t.lastName
        }).appendTo($("#TeacherDD"))
    }
}
function fillTeacherDDc(teachers) {
    for(let t of teachers) {
        $("<option>", {
            value: t.staffNo,
            text: t.firstName +"  "+ t.lastName
        }).appendTo($("#cTeacherDD"))
    }
}
function saveTasks() {
    let url = "http://localhost:9090/all_children";
    let requestMethod = "post";
    let parentId = $('#parentDD').val();
    let child = {
        studentId: $('#studentId').val(),
        firstName: $('#firstName').val(),
        lastName: $('#lastName').val(),
        dob: $('#date').val(),
        gender: $('#Gender').val(),
        parentId: $('#parentDD').val(),
        SchoolGrade: $('#Grade').val(),
        teacherId: $('#TeacherDD').val()
    };
    console.log(child);
    requestMethod = "post";

    let studentId = $('#studentId').val();
    console.log(child);
    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(child)
    }).then(() => {
        alert("child was registered successfully");
        window.location.href = 'http://localhost:9090/register.html';
    });

    // alert("announcmnet added successfully");
    getAllParents();
    // history.back();
}

    function saveNewParent() {
        let url = "http://localhost:9090/parent";
        let requestMethod = "post";
        // let parentId = $('#parentDD').val();
        let parent = {
            qatariId: $('#qatari_ID').val(),
            firstName: $('#pfirstName').val(),
            lastName: $('#plastName').val(),
            mobile: $('#mobile').val(),
            email: $('#email').val(),
            username: $('#username').val(),
            password: $('#password').val(),
            students:[{
                studentId: $('#studentId_').val(),
                firstName: $('#cfirstName').val(),
                lastName: $('#clastName').val(),
                dob: $('#cdate').val(),
                gender: $('#cGender').val(),
                SchoolGrade: $('#cGrade').val(),
                teacherId: $('#cTeacherDD').val()
            }
            ]

        };
        console.log(parent);
        requestMethod = "post";

        let studentId = $('#studentId').val();
        console.log(parent);
        fetch(url, {
            method: requestMethod,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(parent)
        }).then(() => {
            alert("child was registered successfully");
            window.location.href = 'http://localhost:9090/register.html';
        });

        // alert("announcmnet added successfully");
        getAllParents();
        // history.back();
    }


