/**
 * Created by Alya on 4/25/2016.
 */
'use strict';

$(document).ready(function () {
    let user = JSON.parse(localStorage.user);
    $('#userFullName').html(user.username);
    // getAnnouncement().then(announcemnets=>displayAnnouncment(announcemnets));
    getChildren(user.username).then(children => fillChildrenDD(children));
    $("#ChildrenDD").on('change', onStudentChange);
    $("#tasksStatus").on('change', onStudentChange);
});

function  getChildren(username) {
    let url = `http://localhost:9090/teacher/children/${username}`;
    return fetch(url).then(response => response.json());
}
function getAllTasks(studentId) {
    let url = `http://localhost:9090/tasks/${studentId}`;
    return fetch(url).then(response => response.json());
}
function getPendingTasks(studnetId) {
    let url = `http://localhost:9090/ptasks/${studnetId}`;
    return fetch(url).then(response => response.json());

}
function getSurahId(surahId) {
    let url = `http://localhost:9090/surah/${surahId}`;
    return fetch(url).then(response => response.json());
}
function getCompletedTasks(studnetId) {
    let url = `http://localhost:9090/ctasks/${studnetId}`;
    return fetch(url).then(response => response.json());
}
function getmsgs(studnetId) {
    let url = `http://localhost:9090/msgs/${studnetId}`;
    return fetch(url).then(response => response.json());
}
function getAllmsgs() {
    let url = "http://localhost:9090/all_msgs";
    return fetch(url).then(response => response.json());
}


function getAllSurahs(){
    let url = "http://localhost:9090/surahs";
    return fetch(url).then(response => response.json());

}
function showMsgs() {
    $("#msg-list").show();
    let student = $("#ChildrenDD").val();

    getmsgs(student).then(msgs => {
        displayMsgs(msgs);
    }).catch(err => console.log(err));
}

function onStudentChange() {

    let selectedStudent = $(ChildrenDD).val();
    let selectedStatus = $(tasksStatus).val();
    console.log(selectedStatus);
    if (selectedStatus=='pending'){
        getPendingTasks(selectedStudent).then(studnet => {
            displayStudentPtask(studnet);
        }).catch(err => console.log(err))
    }
    if (selectedStatus=='completed'){
        getCompletedTasks(selectedStudent).then(studnet => {
            displayStudenttask(studnet);
            // getmsgs(selectedStudent).then(msgs => {
            //     showMsgs(msgs);
            // }).catch(err => console.log(err))
        }).catch(err => console.log(err))
    }
    if (selectedStatus=='all') {
        getAllTasks(selectedStudent).then(studnet => {
            displayStudenttask(studnet);
            // getmsgs(selectedStudent).then(msgs => {
            //     showMsgs(msgs);
            // }).catch(err => console.log(err))
        }).catch(err => console.log(err))
    }
}

function fillChildrenDD(children) {
    for(let child of children) {
        $("<option>", {
            value: child.studentId,
            text: child.firstName +"  "+ child.lastName
        }).appendTo($("#ChildrenDD"))
    }
}



function fillChildrenTDD(children) {
    for(let child of children) {
        $("<option>", {
            value: child.studentId,
            text: child.firstName +"  "+ child.lastName
        }).appendTo($("#ChildrenTDD"))
    }
}
function fillSurahDD(surahs) {
    for(let surah of surahs) {
        $("<option>", {
            value: surah.id,
            text: surah.englishName
        }).appendTo($("#surahsDD"))
    }
}


function displayStudenttask(tasks) {

    console.log(tasks);
    let htmlTemplate = $('#task-template').html(),
        requestsTemplate = Handlebars.compile(htmlTemplate)
    // console.log(announcments);

    $('#task-list').html(requestsTemplate({tasks}));
}
function displayStudentPtask(tasks) {

    console.log(tasks);
    let htmlTemplate = $('#ptask-template').html(),
        requestsTemplate = Handlebars.compile(htmlTemplate)
    // console.log(announcments);

    $('#task-list').html(requestsTemplate({tasks}));
}
function displayMsgs(msgs) {

    // console.log(annoucments);

    let htmlTemplate = $('#msg-template').html(),
        requests = Handlebars.compile(htmlTemplate)
    // console.log(announcments);

    $('#msg-list').html(requests({msgs}));
}
function addMsg() {
    let htmlTemplate = $('#msg-form-template').html(),
        heroTemplate = Handlebars.compile(htmlTemplate);

    $('#msg-form').html(heroTemplate({}));
    // showFormAsModel();
    savemsg();
}

function addTask() {
    let user1 = JSON.parse(localStorage.user);
    let htmlTemplate = $('#add-form-template').html(),
        taskTemplate = Handlebars.compile(htmlTemplate);

    $('#task-form').html(taskTemplate({}));
    // showFormAsModel();
    getAllSurahs().then(surahs => fillSurahDD(surahs));
    getChildren(user1.username).then(children => fillChildrenTDD(children));
    //savetask();
}
function savemsg() {
    let msg = {
        date: $('#msgdate').val(),
        title: $('#title').val(),
        body: $('#body').val(),
        studentId: $('#studentId').val()
    };
    console.log(msg);
    let url = "http://localhost:9090/all_msgs";
    let requestMethod = "post";

    fetch(url, {
        method: 'post',
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(msg)
    }).then(() => {
        // After add/update then refresh the list
        getAllmsgs();
    });
}
function fetchTask(taskId) {
    let url = `http://localhost:9090/all_tasks/${taskId}`;
    return fetch(url).then(response => response.json());
}
function updateTask(taskId) {
    console.log("taskId", taskId);
    fetchTask(taskId).then(task => {
        console.log(task);

        let htmlTemplate = $('#task-form-template').html(),
            heroTemplate = Handlebars.compile(htmlTemplate);

        $('#update-form').html(heroTemplate(task));
        //
        // //Select the heroType in the Dropdown
        // //$('#heroType').val(hero.heroType);
        // // showFormAsModel();
    }).catch(err => console.log(err));
}
// function updateTask(taskId) {
//     console.log("taskId", taskId);
//     ftechTask(taskId).then(task => {
//         console.log(task);
//
//         let htmlTemplate = $('#task-form-template').html(),
//             heroTemplate = Handlebars.compile(htmlTemplate);
//
//         $('#task-form').html(heroTemplate(task));
//
//         //Select the heroType in the Dropdown
//         $('#heroType').val(task.heroType);
//         showFormAsModel();
//
//     }).catch(err => console.log(err));
// }

// function showFormAsModel() {
//     let heroForm = $( "#update-form" ).dialog({
//         height: 450,
//         width: 750,
//         title: 'Hero Form',
//         modal: true,
//         buttons: {
//             "Submit": function() {
//                 saveTasks();
//                 heroForm.dialog( "close" );
//             },
//             Cancel: function() {
//                 heroForm.dialog( "close" );
//             }
//         }
//     });
// }

function saveRequest() {
    let url = "http://localhost:9090/all_msgs";
    let requestMethod = "post";

    let msg = {
        date: $('#msgdate').val(),
        title: $('#title').val(),
        body: $('#body').val(),
        studentId : $('#studentId').val()
    };
    console.log(msg);
    requestMethod = "post";
    console.log(msg);
    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(msg)
    }).then(() => {
        alert("message was sent successfully");
        window.location.href = 'http://localhost:9090/teacher.html';
    });

    // alert("announcmnet added successfully");
    getAllmsgs();
    // history.back();
}

function newCompletedTask(dec) {

    let val = dec.completedDate;
    let sId = dec.taskId;
    let exist = false;
    let changes;

    let array = changes.filter(function (a) {
        return a.taskId == val;
    })[0];

    if (typeof array != "undefined" && array != null && array.length > 0) {
        array.completedDate = val;
        exist = true;
    }

    if (!exist) {
        changes.push(
            {
                "completedDate": val,
                "taskId": sId
            })
    }
}




function saveTasks() {
    let url = "http://localhost:9090/all_tasks";
    let requestMethod = "post";
    let surahId = $('#surahsDD').val();
    let sName;
    getSurahId(surahId).then (surah =>{
         sName = surah.englishName;
    });
    console.log('surahName',sName);
    let task = {
        taskId: $('#taskId').val(),
        studentId: $('#ChildrenTDD').val(),
       surahId: $('#surahsDD').val(),
       surahName: sName,
        fromAya: $('#selectedFromAyah').val(),
        toAya: $('#selectedToAyah').val(),
        type:$('#taskType').val(),
        dueDate:$('#taskdate').val(),
    };
    console.log(task);
    requestMethod = "post";

    let taskId = $('#taskId').val();
    console.log(task);
    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(task)
    }).then(() => {
        alert("message was sent successfully");
        window.location.href = 'http://localhost:9090/teacher.html';
    });
    getAllTasks();
}