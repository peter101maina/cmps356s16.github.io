'use strict'
let express = require('express');
let msgController = require('../HalaqaMetrash/controller/msgController')
let staffController = require('../HalaqaMetrash/controller/StaffController')
let studentController = require('../HalaqaMetrash/controller/studentController')
let tasksController = require('../HalaqaMetrash/controller/tasksController')

let bodyParser = require('body-parser')

let app = express();

app.use(bodyParser.urlencoded({extended:true}));
//aut-deserialize the body of incoming request to a json object
app.use(bodyParser.json());

//Allow serving static files
console.log(__dirname);
app.use(express.static(__dirname));

let port = 9090;

app.get('/', (request, response) => {

});
app.get('/coordinator', (req, res) => {
    staffController.getCoordinator(req,res);
});
app.get('/coordinator/users/:cUSER', (req, res) => {
    staffController.getCoordinatorByName(req,res);
});
app.get('/coordinator/:staffno', (req, res) => {
    staffController.fetchCoordinator(req,res);
});
app.get('/surah/:id', (req, res) => {
tasksController.getSurahName(req,res);
});
app.get('/teacher', (req, res) => {
    staffController.getTeacher(req,res);
});
app.get('/teacher/users/:tUSER', (req, res) => {
   staffController.getTeacherByName(req,res);
});
app.get('/teacher/:staffno', (req, res) => {
    staffController.fetchTeacher(req,res);
});
app.get('/parent', (req, res) => {
    studentController.getParent(req,res);
});
app.get('/all_children', (req, res) => {
    staffController.getAllChildren(req,res);
});
app.get('/parent/users/:pUSER', (req, res) => {
    studentController.getParentByName(req,res);
});
app.get('/tasks/:studentId', (req, res) => {
    tasksController.getTasks(req,res);
});
app.get('/ptasks/:studentId', (req, res) => {
    tasksController.getPendingTasks(req,res);
});
app.get('/ctasks/:studentId', (req, res) => {
    tasksController.getCompletedTasks(req,res);
});
app.get('/msgs/:studentId', (req, res) => {
    msgController.getMsgss(req,res);
});
app.get('/parent/:qid', (req, res) => {
    studentController.fetchParent(req,res);
});
app.get('/announcment', (req, res) => {
    msgController.getAnnouncmnet(req, res);
});
app.get('/surahs', (req, res) => {
    tasksController.getAllSurahs(req,res);
});
app.get('/all_msgs', (req, res) => {
    msgController.getAllMsgs(req,res);
});
app.get('/all_tasks', (req, res) => {

    tasksController.getAllTasks(req,res);
});
app.get('/tasks/:taskid', (req, res) => {
    tasksController.getTask(req,res);
});
app.delete('/all_tasks/:id', (req, res) => {
    tasksController.deleteTask(req,res);
});
app.get('/all_tasks/:taskId', (req, res) => {
    tasksController.gettaskss(req,res);
});
app.listen(port, function () {
    console.log("Server listening @ http://localhost:" + port);
});
app.get('/parent/children/:qid', (req, res) => {
    studentController.getChildren(req,res);
});
app.get('/teacher/children/:qid', (req, res) => {
    staffController.getStudentsTeacher(req,res);
});
app.post('/announcment', (req, res) => {
   msgController.addAnnouncment(req,res);
});
app.post('/all_msgs', (req, res) => {
    msgController.addMsg(req,res);
});
app.post('/all_children', (req, res) => {
    studentController.addChildren(req,res);
});
app.post('/parent', (req, res) => {
    studentController.addNewChildrenNewParent(req,res);
});
app.put('/all_tasks', (req, res) => {
    tasksController.updateTask(req,res);
   });

