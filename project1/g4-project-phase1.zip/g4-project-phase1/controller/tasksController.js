/**
 * Created by Alya on 4/30/2016.
 */
/**
 * Created by Alya on 4/30/2016.
 */
'use strict'
class tasksController {
    constructor() {
        this.Repository = require('./../repository/tasksRepository');
    }
    getTasks(req,res){
        let studentId = req.params.studentId;
        // console.log('req.params.pUSER', puser);
        this.Repository.getTasks(parseInt(studentId)).then(p => {
            console.log(JSON.stringify(p, null, 2));
            res.json(p);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    getSurahName(req,res){
        let id = req.params.id;
        this.Repository.getSurahName(parseInt(id)).then(s => {
            console.log(JSON.stringify(s, null, 2));
            res.json(s);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    getTask(req,res){
        let taskid = req.params.taskid;
        // console.log('req.params.qid', qid);
        this.Repository.getTask(taskid).then(p => {
            console.log(JSON.stringify(p, null, 2));
            res.json(p);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    getPendingTasks(req,res){
        let studentId = req.params.studentId;
        // console.log('req.params.pUSER', puser);
        this.Repository.getPendingTasks(parseInt(studentId)).then(p => {
            console.log(JSON.stringify(p, null, 2));
            res.json(p);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    getCompletedTasks(req,res){
        let studentId = req.params.studentId;
        // console.log('req.params.pUSER', puser);
        this.Repository.getCompletedTasks(parseInt(studentId)).then(p => {
            console.log(JSON.stringify(p, null, 2));
            res.json(p);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    gettaskss(Req,res){
        let taskId = req.params.taskId;
        this.Repository.gettaskss(parseInt(taskId)).then(p => {
            console.log(JSON.stringify(p, null, 2));
            res.json(p);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    getAllSurahs (req,res){
        this.Repository.getAllSurahs().then(a => {
            console.log(JSON.stringify(a, null, 2));
            res.json(a);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    getAllTasks(req,res){
            this.Repository.getAllTasks().then(a => {
            console.log(JSON.stringify(a, null, 2));
            res.json(a);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    deleteTask(req,res){
        let taskId = req.params.id;
        // the problem cannot read taskId
        this.Repository.deleteTask(taskId).then(() => {
            res.status(200).send("Task deleted");
        }).catch(err => {
            res.status(500).send(err);
        });
    }
    updateTask(req,res){
        let task = req.body;
        this.Repository.updateTask(task).then(() => {
            res.status(200).send("Task updated successfully");
        }).catch(err => {
            console.log(err);
            res.status(500).send(err);
        });
    }
}
module.exports = new tasksController();