/**
 * Created by Alya on 4/30/2016.
 */
'use strict'
class msgController {
    constructor() {
        this.Repository = require('./../repository/msgRepository');
    }

    getAnnouncmnet(req, res) {
        this.Repository.getAnnouncment().then(a => {
            console.log(JSON.stringify(a, null, 2));
            res.json(a);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    addAnnouncment (req,res) {
        let announcment = req.body;
        console.log(announcment);
        this.Repository.addAnnouncment(announcment).then((announcment)=> {
                let urlOfNewHero = "/announcmnet";
                res.location(urlOfNewHero)
                res.status(201).send(`Created and available @ ${urlOfNewHero}`);
            })
            .catch(err => res.status(500).send(err));
    }
    addMsg(req,res){
        let msg = req.body;
        console.log(msg);
        this.Repository.addMsg(msg).then((msg)=> {
                let urlOfNewHero = "/all_msgs";
                res.location(urlOfNewHero)
                res.status(201).send(`Created and available @ ${urlOfNewHero}`);
            })
            .catch(err => res.status(500).send(err));
    }
    getMsgss(req,res){
        let studentId = req.params.studentId;
        this.Repository.getMsgss(parseInt(studentId)).then(p => {
            console.log(JSON.stringify(p, null, 2));
            res.json(p);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    getAllMsgs(req,res){
        this.Repository.getAllMsgs().then(a => {
            console.log(JSON.stringify(a, null, 2));
            res.json(a);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
}
module.exports = new msgController();