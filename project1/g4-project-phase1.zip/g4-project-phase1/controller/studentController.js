/**
 * Created by Alya on 4/30/2016.
 */

'use strict'
class studentController {
    constructor() {
        this.Repository = require('./../repository/studentRepository');
    }
    getParent(req,res){
        this.Repository.getParent().then(p => {
            res.json(p);
        });
    }
    getParentByName(req,res){
        let puser = req.params.pUSER;
        // console.log('req.params.pUSER', puser);
        this.Repository.getParentByName(puser).then(p => {
            console.log(JSON.stringify(p, null, 2));
            res.json(p);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    fetchParent(req,res){
        let qid = req.params.qid;
        // console.log('req.params.qid', qid);
        this.Repository.fetchParent(parseInt(qid)).then(p => {
            console.log(JSON.stringify(p, null, 2));
            res.json(p);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    getChildren(req,res){
        let qid = req.params.qid;
        // console.log('req.params.qid', qid);
        this.Repository.getChildren(qid).then(p => {
            console.log(JSON.stringify(p, null, 2));
            res.json(p);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    addChildren(Req,res){
        let child = Req.body;
        console.log(child);
        this.Repository.addChildren(child).then((student)=> {
                let urlOfNewHero = "/all_children";
                res.location(urlOfNewHero)
                res.status(201).send(`Created and available @ ${urlOfNewHero}`);
            })
            .catch(err => res.status(500).send(err));
    }
    addNewChildrenNewParent(req,res){
        let child = req.body;
        console.log(child);
        this.Repository.addNewChildrenNewParent(child).then((students)=> {
                let urlOfNewHero = "/parent";
                res.location(urlOfNewHero)
                res.status(201).send(`Created and available @ ${urlOfNewHero}`);
            })
            .catch(err => res.status(500).send(err));
    }
}
module.exports = new studentController();