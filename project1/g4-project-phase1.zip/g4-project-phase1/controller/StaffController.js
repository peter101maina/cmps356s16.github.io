/**
 * Created by Alya on 4/30/2016.
 */
'use strict'
class StaffController {
    constructor() {
        this.Repository = require('./../repository/staffRepository');
    }

    getCoordinator(req,res){
        this.Repository.getCoordinator().then(c => {
            res.json(c);
        });
    }
    getTeacher(req,res){
        this.Repository.getTeacher().then(t => {
            res.json(t);
        });
    }
    getCoordinatorByName(req,res){
        let cuser = req.params.cUSER;
        // console.log('req.params.cUSER', cuser);
        this.Repository.getCoordinatorByName(cuser).then(c => {
            console.log(JSON.stringify(c, null, 2));
            res.json(c);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    getTeacherByName (req,res){
        let tUSER = req.params.tUSER;
        // console.log('req.params.tUSER', tUSER);
        this.Repository.getTeacherByName(tUSER).then(t => {
            console.log(JSON.stringify(t, null, 2));
            res.json(t);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    fetchCoordinator(req,res){
        let staffno = req.params.staffno;
        // console.log('req.params.staffno', staffno);
        this.Repository.fetchCoordinator(parseInt(staffno)).then(s => {
            console.log(JSON.stringify(s, null, 2));
            res.json(s);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    fetchTeacher(req,res){
        let staffno = req.params.staffno;
        // console.log('req.params.staffno', staffno);
        this.Repository.fetchTeacher(parseInt(staffno)).then(s => {
            console.log(JSON.stringify(s, null, 2));
            res.json(s);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }
    getAllChildren(req,res){
        this.Repository.getAllChildren().then(p => {
            res.json(p);
        });
    }
    getStudentsTeacher(req,res){let qid = req.params.qid;
        // console.log('req.params.qid', qid);
        this.Repository.getStudentsTeacher(qid).then(p => {
            console.log(JSON.stringify(p, null, 2));
            res.json(p);
        }).catch(err => {
            res.send("Failed :" + err);
        });}
    
}
module.exports = new StaffController();