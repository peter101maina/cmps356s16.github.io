/**
 * Created by Alya on 4/30/2016.
 */
'use strict';

class tasksRepository {

    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }
    getTasks(studentId) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(tasks => {
                tasks = tasks.filter(t=>t.studentId==studentId);
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getSurahName(surahId){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/surah.json').then(surahs => {
                surahs = surahs.filter(a=> a.id == surahId );
                resolve(surahs);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getTask(taskId) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(tasks => {
                tasks = tasks.filter(t=>t.studentId==studentId);
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getPendingTasks(studentId) {
        return new Promise((resolve, reject) => {
            this.getTasks(studentId).then(tasks => {
                tasks = tasks.filter(t=>t.completedDate==null);
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getCompletedTasks(studentId) {
        return new Promise((resolve, reject) => {
            this.getTasks(studentId).then(tasks => {
                tasks = tasks.filter(t=>t.completedDate!=null);
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }
    gettaskss(taskId) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(tasks => {
                tasks = tasks.filter(a=> a.taskId == taskId );
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getAllSurahs() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/surah.json').then(everything => {
                resolve(everything);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getAllTasks() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(everything => {
                resolve(everything);
            }).catch(err => {
                reject(err);
            });
        });
    }
    addTasks(task) {
        return new Promise((resolve, reject) => {
            this.getAllTasks().then(tasks => {
                let maxId = Math.max.apply(Math, tasks.map(h => h.taskId)) + 1;
                task.taskId = maxId;
                tasks.push(task);
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(()=> resolve(task))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
    deleteTask(taskId) {
        return new Promise((resolve, reject) => {
            this.getAllTasks().then(tasks => {
                let len = tasks.length;
                let foundAt = -1;
                for (let i = 0; i < len; i++) {
                    if (tasks[i].taskId == taskId) {
                        foundAt = i;
                        console.log('at',i);
                        break;
                    }
                }
                if (foundAt >= 0) {
                    tasks.splice(foundAt, 1);
                }
                console.log("repository.deleteTask", taskId);

                return this.writeJsonFile('./data/task.json', tasks);
            }).then((tasks) => {
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }
    updateTask(task) {
        return new Promise((resolve, reject) => {
            this.getAllTasks().then(tasks => {
                let len = tasks.length;
                for(let i=0; i<len; i++){
                    if (tasks[i].taskId == task.taskId){
                        tasks[i] = task;
                        break;
                    }
                }
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(()=> resolve())
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
    CompletedTask(task) {
        return new Promise((resolve, reject) => {
            this.getAllDetailedRequests().then(tasks => {
                tasks = tasks.filter(r => r.completedDate != null );
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        })
    }

}

module.exports = new tasksRepository();