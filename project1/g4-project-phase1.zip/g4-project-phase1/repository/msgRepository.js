/**
 * Created by Alya on 4/30/2016.
 */
/**
 * Created by TOSHIBA on 4/24/2016.
 */
'use strict';

class msgRepository {

    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }
    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }
    getAnnouncment() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/announcment.json').then(announcments => {
                announcments = announcments.filter(a=> a.studentId == null);
                resolve(announcments);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getAnnouncemntAndMsgs() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/announcment.json').then(everything => {
                resolve(everything);
            }).catch(err => {
                reject(err);
            });
        });
    }
    addAnnouncment(announcmet) {
        return new Promise((resolve, reject) => {
            this.getAnnouncemntAndMsgs().then(announcments => {
                announcments.push(announcmet);
                return this.writeJsonFile('./data/announcment.json', announcments);
            }).then(()=> resolve(announcmet))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
    addMsg(msg) {
        return new Promise((resolve, reject) => {
            this.getAnnouncemntAndMsgs().then(announcments => {
                announcments.push(msg);
                return this.writeJsonFile('./data/announcment.json', announcments);
            }).then(()=> resolve(msg))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
    getMsgss(studentId) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/announcment.json').then(msgs => {
                msgs = msgs.filter(a=> a.studentId == studentId);
                resolve(msgs);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getAllMsgs() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/announcment.json').then(msgs => {
                msgs = msgs.filter(a=> a.studentId != null);
                resolve(msgs);
            }).catch(err => {
                reject(err);
            });
        });
    }
}
module.exports = new msgRepository();