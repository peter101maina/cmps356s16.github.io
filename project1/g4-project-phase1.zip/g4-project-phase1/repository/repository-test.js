/**
 * Created by TOSHIBA on 4/24/2016.
 */
'use strict'

// let repo = require('./repository.js');
// repo.getTasks().then( requests => {
//     console.log(requests);
// });

let repository = require ('./repository');
// repository.getCoordinator().then( c =>{
//    console.log(c);
// });

// repository.getCoordinator("coordinator").then(c=> {
//     console.log(c);
// });

// repository.fetchCoordinator(500).then(c=> {
//     console.log(c);
// });
// repository.getTeacher().then(t=>{
//     console.log(t);
// });
// repository.getTeacherByName("teacher1").then(t=>{
//     console.log(t);
// });
// repository.fetchTeacher(502).then(t=>{
//     console.log(t);
// });
// repository.getParent().then(t=>{
//     console.log(t);
// });
// repository.getParentByName("juha").then(t=>{
//     console.log(t);
// });
// repository.fetchParent(12).then(t=>{
//     console.log(t);
// });
// repository.getAnnouncment().then(t=>{
//     console.log(t);
// });
// repository.getChildren("juha").then(t=>{
//     console.log(t);
// });
// repository.getAllChildren().then(t=>{
//     console.log(t);
// });
//let task= {
//   "studentId": 3,
//    "surahId": 2,
//    "surahName": "Aal-e-Imran",
//    "fromAya": 14,
//   "toAya": 18,
//    "type": "Revision",
//    "dueDate": "3/04/2016"}
//
//
//repository.addTasks(task).then (t=> console.log(t));
//repository.getAllTasks().then(t=> console.log(t));
// let msg = {
//     "date" : "3/04/2016",
//     "title" : "test" ,
//     "body":"this is test msg ",
//     "studentId":2
// }
// console.log(msg);
// repository.addMsg(msg).then (t=> console.log(t));
//repository.getAllMsgs().then(t=> console.log(t));
// repository.getAnnouncment().then(t=> console.log(t));
// repository.getTasks(1).then(t=>{
//     console.log(t);
// });
// repository.getMsgs(1).then(t=>{
//     console.log(t);
// });
// repository.getCompletedTasks(1).then(t=>{
//     console.log(t);
// });
// repository.getSurahName(2).then(t=>{
//     console.log(t);
// });
// let child= {
//     "parentId": 34,
//     "firstName": "Bintt",
//     "lastName": "Ibnn",
//     "dob": "1/3/2015",
//     "gender": "F",
//     "schoolGrade": 4,
//     "teacherId": 502
//
// }
// repository.addChildren(child).then(p=> console.log(p));
// let parent = {
//     "qatariId":100,
//         "firstName":"Juha",
//         "lastName":"Dahak",
//         "mobile":"7777-888",
//         "email":"juha@test.com",
//         "username":"juha",
//         "password":"password",
//         "students":[
//             {"studentId":1,
//                 "firstName":"Ibn Juha",
//                 "lastName":"Dahak",
//                 "dob":"1/1/2009",
//                 "gender":"M",
//                 "schoolGrade":4,
//                 "teacherId":501
//             }
//         ]
//     }
// repository.addNewChildrenNewParent(parent).then(p=> console.log(p));
// repository.deleteTask(8).then (p=> console.log(p));
// repository.getStudentsTeacher("teacher1").then(t=>{console.log(t)});
// repository.getMsgss(5).then(t=>{console.log(t)});
// repository.getAnnouncemntAndMsgs().then(t=>{console.log(t)});
let task ={
    "taskId": 2,
    "studentId": 5,
    "surahId": 3,
    "surahName": "Aal-e-Imran",
    "fromAya": 9,
    "toAya": 13,
    "type": "Revision",
    "dueDate": "1/04/2016",
    "completedDate": "2/04/2016",
    "masteryLevel": "Ok",
    "comment": "Ok work"
}
console.log(task);
repository.updateTask(task).then();
console.log(task);