/**
 * Created by Alya on 4/30/2016.
 */
/**
 * Created by TOSHIBA on 4/24/2016.
 */
'use strict';

class repository {

    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }
    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }
    
    getParent() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(parent => {
                resolve(parent);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getParentByName(username) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(parent => {
                parent = parent.filter(p=>p.username==username);
                resolve(parent[0]);
            }).catch(err => {
                reject(err);
            });
        });
    }
    fetchParent(qatariId) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(parent => {
                parent = parent.filter(p=> p.qatariId == qatariId);
                resolve(parent);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getChildren(username) {
        return new Promise((resolve, reject) => {
            this.getParentByName(username).then(parent => {
                let students = parent.students;
                // console.log(students);
                resolve(students);
            }).catch(err => {
                reject(err);
            });
        });
    }
    addChildren(child) {
        return new Promise((resolve, reject) => {
            this.getParent().then(parents => {
                let parent = parents.filter(p=> child.parentId == p.qatariId);
                console.log(parent);
                for (var i =0; i<parents.length;i++) {
                    for (var j = 0; j < parents[i].students.length; j++) {
                        var maxId = Math.max.apply(Math, parents[i].students.map(h => h.studentId)) + 1;
                    }
                }
                for (var i =0; i<parent.length;i++) {
                    for (var j = 0; j < parent[i].students.length; j++) {
                        // let maxId = Math.max.apply(Math, parent[i].students.map(h => h.studentId)) + 1;
                        child.studentId = maxId;
                        parent[i].students.push(child);
                        break;
                    }
                }
                console.log(parent);
                return this.writeJsonFile('./data/student.json', parents);
            }).then(()=> resolve(child))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
    addNewChildrenNewParent(child)  {
        return new Promise((resolve, reject) => {
            this.getParent().then(parents => {
                for (var i =0; i<parents.length;i++) {
                    for (var j = 0; j < parents[i].students.length; j++) {
                        var maxId = Math.max.apply(Math, parents[i].students.map(h => h.studentId)) + 1;
                    }
                }
                child.studentId=maxId;
                parents.push(child);
                return this.writeJsonFile('./data/student.json', parents);
            }).then(()=> resolve(child))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

}

module.exports = new repository();