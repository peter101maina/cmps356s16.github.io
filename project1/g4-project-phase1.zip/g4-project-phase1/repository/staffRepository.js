/**
 * Created by Alya on 4/30/2016.
 */

'use strict';

class staffRepository {

    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }
    getCoordinator() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(coordinator => {
                coordinator = coordinator.filter(c=> c.isCoordinator ===1 );
                resolve(coordinator[0]);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getTeacher() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(teacher => {
                teacher = teacher.filter(t=> t.isCoordinator !==1 );
                resolve(teacher);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getCoordinatorByName(username) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(coordinator => {
                coordinator = coordinator.filter(c=> c.isCoordinator === 1 ).filter(c=>c.username===username);
                resolve(coordinator[0]);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getTeacherByName(username) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(teacher => {
                teacher = teacher.filter(t=> t.isCoordinator !== 1 ).filter(t=>t.username===username);
                resolve(teacher[0]);
            }).catch(err => {
                reject(err);
            });
        });
    }
    fetchCoordinator(staffno) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(coordinator => {
                coordinator = coordinator.filter(c=> c.staffNo == staffno);
                resolve(coordinator[0]);
            }).catch(err => {
                reject(err);
            });
        });
    }
    fetchTeacher(staffno) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(teacher => {
                teacher = teacher.filter(t=> t.staffNo == staffno);
                resolve(teacher[0]);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getAllChildren() {
        return new Promise((resolve, reject) => {
            this.getParent().then(parents => {
                let students=[];
                // let StudentsArray;
                for (var i =0; i<parents.length;i++) {
                    for (var j = 0; j < parents[i].students.length; j++) {
                        students.push(parents[i].students[j]);
                    }
                }
                // console.log(students);
                if(students.length>0){
                    resolve(students);
                }
                else{
                    reject("No records");
                }
            }).catch(err => {
                reject(err);
            });
        });
    }
    getStudentsTeacher(username) {
        return new Promise((resolve, reject) => {
            this.getAllChildren().then(studnets => {
                // let students = children.students;
                // console.log('test1');
                let students_array=[]
                this.getTeacherByName(username).then(teacher => {
                    let t = teacher.staffNo;
                    // console.log(t);
                    for (var i = 0 ; i<studnets.length;i++){
                        // console.log('at',i);
                        if (studnets[i].teacherId == t){
                            students_array.push(studnets[i]);
                            // console.log(students_array[i]);
                        }
                    }
                    resolve(students_array);
                })}).catch(err => {
                reject(err);
            });
        });
    }

}

module.exports = new staffRepository();