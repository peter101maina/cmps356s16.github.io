/**
 * Created by TOSHIBA on 4/24/2016.
 */
'use strict';

class repository {

    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }
    
    getCoordinator() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(coordinator => {
               coordinator = coordinator.filter(c=> c.isCoordinator ===1 );
                resolve(coordinator[0]);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getTeacher() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(teacher => {
                teacher = teacher.filter(t=> t.isCoordinator !==1 );
                resolve(teacher);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getParent() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(parent => {
                resolve(parent);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getCoordinatorByName(username) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(coordinator => {
                coordinator = coordinator.filter(c=> c.isCoordinator === 1 ).filter(c=>c.username===username);
                resolve(coordinator[0]);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getTeacherByName(username) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(teacher => {
                teacher = teacher.filter(t=> t.isCoordinator !== 1 ).filter(t=>t.username===username);
                resolve(teacher[0]);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getParentByName(username) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(parent => {
                parent = parent.filter(p=>p.username==username);
                resolve(parent[0]);
            }).catch(err => {
                reject(err);
            });
        });
    }
    fetchCoordinator(staffno) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(coordinator => {
                coordinator = coordinator.filter(c=> c.staffNo == staffno);
                resolve(coordinator[0]);
            }).catch(err => {
                reject(err);
            });
        });
    }
    fetchTeacher(staffno) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(teacher => {
                teacher = teacher.filter(t=> t.staffNo == staffno);
                resolve(teacher[0]);
            }).catch(err => {
                reject(err);
            });
        });
    }
    fetchParent(qatariId) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(parent => {
                parent = parent.filter(p=> p.qatariId == qatariId);
                resolve(parent);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getAnnouncment() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/announcment.json').then(announcments => {
                announcments = announcments.filter(a=> a.studentId == null );
                resolve(announcments);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getAnnouncemntAndMsgs() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/announcment.json').then(everything => {
                resolve(everything);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getChildren(username) {
        return new Promise((resolve, reject) => {
            this.getParentByName(username).then(parent => {
                let students = parent.students;
                // console.log(students);
                resolve(students);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getAllChildren() {
        return new Promise((resolve, reject) => {
            this.getParent().then(parents => {
                let students=[];
                // let StudentsArray;
                for (var i =0; i<parents.length;i++) {
                    for (var j = 0; j < parents[i].students.length; j++) {
                        students.push(parents[i].students[j]);
                    }
                }
                // console.log(students);
                if(students.length>0){
                    resolve(students);
                }
                else{
                    reject("No records");
                }
            }).catch(err => {
                reject(err);
            });
        });
    }
    addAnnouncment(announcmet) {
        return new Promise((resolve, reject) => {
            this.getAnnouncemntAndMsgs().then(announcments => {
                announcments.push(announcmet);
                return this.writeJsonFile('./data/announcment.json', announcments);
            }).then(()=> resolve(announcmet))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
    addMsg(msg) {
        return new Promise((resolve, reject) => {
            this.getAnnouncemntAndMsgs().then(announcments => {
                announcments.push(msg);
                return this.writeJsonFile('./data/announcment.json', announcments);
            }).then(()=> resolve(msg))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
    getTasks(studentId) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(tasks => {
                tasks = tasks.filter(t=>t.studentId==studentId);
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getSurahName(surahId){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/surah.json').then(surahs => {
                surahs = surahs.filter(a=> a.id == surahId );
                resolve(surahs);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getTask(taskId) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(tasks => {
                tasks = tasks.filter(t=>t.studentId==studentId);
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getPendingTasks(studentId) {
        return new Promise((resolve, reject) => {
            this.getTasks(studentId).then(tasks => {
                tasks = tasks.filter(t=>t.completedDate==null);
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getCompletedTasks(studentId) {
        return new Promise((resolve, reject) => {
            this.getTasks(studentId).then(tasks => {
                tasks = tasks.filter(t=>t.completedDate!=null);
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getMsgss(studentId) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/announcment.json').then(msgs => {
                msgs = msgs.filter(a=> a.studentId == studentId );
                resolve(msgs);
            }).catch(err => {
                reject(err);
            });
        });
    }
    gettaskss(taskId) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(tasks => {
                tasks = tasks.filter(a=> a.taskId == taskId );
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getAllMsgs() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/announcment.json').then(msgs => {
                msgs = msgs.filter(a=> a.studentId != null );
                resolve(msgs);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getAllSurahs() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/surah.json').then(everything => {
                resolve(everything);
            }).catch(err => {
                reject(err);
            });
        });



    }
    getAllTasks() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(everything => {
                resolve(everything);
            }).catch(err => {
                reject(err);
            });
        });
    }
    addTasks(task) {
        return new Promise((resolve, reject) => {
            this.getAllTasks().then(tasks => {
                let maxId = Math.max.apply(Math, tasks.map(h => h.taskId)) + 1;
                task.taskId = maxId;
                tasks.push(task);
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(()=> resolve(task))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
    getStudentsTeacher(username) {
        return new Promise((resolve, reject) => {
            this.getAllChildren().then(studnets => {
                // let students = children.students;
                // console.log('test1');
                let students_array=[]
                this.getTeacherByName(username).then(teacher => {
                    let t = teacher.staffNo;
                    // console.log(t);
                    for (var i = 0 ; i<studnets.length;i++){
                        // console.log('at',i);
                        if (studnets[i].teacherId == t){
                            students_array.push(studnets[i]);
                            // console.log(students_array[i]);
                        }
                    }
                    resolve(students_array);
            })}).catch(err => {
                reject(err);
            });
        });
    }
    deleteTask(taskId) {
        return new Promise((resolve, reject) => {
            this.getAllTasks().then(tasks => {
                let len = tasks.length;
                let foundAt = -1;
                for (let i = 0; i < len; i++) {
                    if (tasks[i].taskId == taskId) {
                        foundAt = i;
                        console.log('at',i);
                        break;
                    }
                }
                if (foundAt >= 0) {
                    tasks.splice(foundAt, 1);
                }
                console.log("repository.deleteTask", taskId);

                return this.writeJsonFile('./data/task.json', tasks);
            }).then((tasks) => {
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }
    addChildren(child) {
     return new Promise((resolve, reject) => {
         this.getParent().then(parents => {
             let parent = parents.filter(p=> child.parentId == p.qatariId);
             console.log(parent);
                    for (var i =0; i<parents.length;i++) {
                        for (var j = 0; j < parents[i].students.length; j++) {
                            var maxId = Math.max.apply(Math, parents[i].students.map(h => h.studentId)) + 1;
                    }
                }
                 for (var i =0; i<parent.length;i++) {
                     for (var j = 0; j < parent[i].students.length; j++) {
                         // let maxId = Math.max.apply(Math, parent[i].students.map(h => h.studentId)) + 1;
                         child.studentId = maxId;
                         parent[i].students.push(child);
                         break;
                     }
                 }
                 console.log(parent);
             return this.writeJsonFile('./data/student.json', parents);
         }).then(()=> resolve(child))
             .catch(err => {
                 console.log(err);
                 reject(err);
             });
     });
 }
    addNewChildrenNewParent(child)  {
        return new Promise((resolve, reject) => {
            this.getParent().then(parents => {
                for (var i =0; i<parents.length;i++) {
                    for (var j = 0; j < parents[i].students.length; j++) {
                        var maxId = Math.max.apply(Math, parents[i].students.map(h => h.studentId)) + 1;
                    }
                }
                child.studentId=maxId;
                parents.push(child);
                return this.writeJsonFile('./data/student.json', parents);
            }).then(()=> resolve(child))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
    updateTask(task) {
        return new Promise((resolve, reject) => {
            this.getAllTasks().then(tasks => {
                let len = tasks.length;
                for(let i=0; i<len; i++){
                    if (tasks[i].taskId == task.taskId){
                        tasks[i] = task;
                        break;
                    }
                }
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(()=> resolve())
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
    CompletedTask(task) {
            return new Promise((resolve, reject) => {
                this.getAllDetailedRequests().then(tasks => {
                    tasks = tasks.filter(r => r.completedDate != null );
                    resolve(tasks);
                }).catch(err => {
                    reject(err);
                });
            })
    }

}

module.exports = new repository();