
$(document).ready(function () {

    let user = JSON.parse(localStorage.user);
    $('#userFullname').html(user.firstName+" "+user.lastName);

    getTasks();
    $('#tasks-list').on('click', 'a.deleteButton', deleteTask);

});
function getTasks() {
    let user = JSON.parse(localStorage.user);

    fetchTasks(user.staffNo).then(tasks=>displayTasks(tasks) )
        .catch(err => console.log(err));
}
function addTask() {
    let htmlTemplate = $('#addTask-form-template').html(),
        taskTemplate = Handlebars.compile(htmlTemplate);

    $('#addTask-form').html(taskTemplate({}));
    showFormAsModel();
}

function showFormAsModel() {
    let taskForm = $( '#addTask-form' ).dialog({
        height: 450,
        width: 750,
        title: 'Add Task Form',
        modal: true,
        buttons: {
            "Submit": function() {
                saveTask();
                taskForm.dialog( "close" );
            },
            Cancel: function() {
                taskForm.dialog( "close" );
            }
        }
    });
}

function fetchTasks(staffNo) {
    let url = `http://localhost:9080/api/tasks`;
    return fetch(url).then(response => response.json());
}
function displayTasks(tasks) {

    let htmlTemplate = $('#tasks-template').html(),
        sTemplate = Handlebars.compile(htmlTemplate)

    $('#tasks-list').html(sTemplate({tasks}));

}
function deleteTask(event) {
    event.preventDefault();
    if (!confirm('Confirm Cancel?')) {
        return;
    }
    let taskId = $(this).attr('data-taskId');

    let url = `http://localhost:9080/api/tasks/${taskId}`;
    fetch(url, {method: 'delete'}).then(() => {
        //After successful delete remove the row from the HTML table
        $(this).closest('tr').remove();
    }).then(() => {
        //After delete then refresh the list
        getTasks();
    });
}
