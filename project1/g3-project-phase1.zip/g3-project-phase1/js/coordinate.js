/**
 * Created by N on 4/27/16.
 */
"use strict";
function displayMAnnoForm() {
    let htmlTemplate = $('#anno-form-template').html(),
        msgTemplate = Handlebars.compile(htmlTemplate);
            $('#div_form').html(msgTemplate({}));


}

function saveannouncement() {
    let today = new Date();
    let mDate = today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();
    let msg = {
        title: $('#title').val(),
        body: $('#message').val(),
        date: mDate
    };

    let url = "http://localhost:9080/api/annoucments/";
    let requestMethod = "post";


    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(msg)
    }).then(() => {
        //After add/update then refresh the list
        alert("your Annoucment has been sent");
    });


}

function fetchParents() {
    let url = `http://localhost:9080/api/students`;
    return fetch(url).then(response => response.json());
}

function checkParentExist(parentId){
    console.log("checking for parent"+parentId);
    return new Promise((resolve, reject) => {
        fetchParents().then(parents=> {
            console.log(" PARENTs are "+JSON.stringify(parents));
            let parent = parents.filter(p=> p.qatariId === parentId)[0];
            console.log(" PARENT IS "+parent);
            if (parent) {
                resolve(parent);
            }
            else {
                reject("err");
            }
        });
    });
}
function saveparent() {


    let parentId=parseInt($('#parentId').val());
    let url = "http://localhost:9080/api/students/";
    let requestMethod = "post";



let student ={

    firstName: $('#firstname').val(),
    lastName: $('#lastname').val(),
    dob: $('#dob').val(),
    gender:$('input[name=sex]:checked', '#add-parent').val(),
    schoolGrade:parseInt($('#schoolGrade').val()),
    teacherId:parseInt($('#teacherId').val())

};
    checkParentExist(parentId).then(p => {
        console.log("parent found");
        p.students.push(student);
        requestMethod="put";

        fetch(url, {
            method: requestMethod,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(p)
        }).then(() => {
            //After add/update then refresh the list
            alert("parent has been Updated");
        });

    }).catch(err=>{
        console.log("parent NOT found");
        //console.log(err);
        let parent = {
            qatariId: parentId,
            firstName: $('#pfirstname').val(),
            lastName: $('#plastname').val(),
            mobile: $('#mobileno').val(),
            email: $('#emailid').val(),
            username: $('#pusername').val(),
            password: $('#password').val(),

            students:[student]
        };

        fetch(url, {
            method: requestMethod,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(parent)
        }).then(() => {
            //After add/update then refresh the list
            alert(" parent has been added");
        });

    });


    function displayTasks() {
        getTasks().then(tasks => {
            let htmlTemplate = $('#Children-template').html(),
                heroesTemplate = Handlebars.compile(htmlTemplate)

            $('#ChildrenTasks').html(heroesTemplate({tasks}));
        }).catch(err => console.log(err));

    }
    function getTasks() {
        let url = `http://localhost:9080/api/tasks`;
        return fetch(url).then(response => response.json());
    }
    function fetchTask() {
        let url = `http://localhost:9080/api/tasks`;
        return fetch(url).then(response => response.json());
    }


}
