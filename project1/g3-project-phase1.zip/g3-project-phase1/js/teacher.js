/**
 * Created by Mariam on 4/26/2016.
 */
'use strict'
$(document).ready(function () {
    console.log("tyeacher paeg lodedd ");
    let user = JSON.parse(localStorage.user);
    let teacherId = user.staffNo;

    console.log("teacherId=" + JSON.stringify(localStorage.user));

    getStudents(teacherId).then(students => fillStudentsDD(students))
        .catch(err => console.log(err));

    $("#studentsDD").on('change', onStudentChange);
});


$(document).ready(function () {
    console.log("tyeacher paeg lodedd ");



});

function getSurahs() {
    let url = `http://localhost:9080/api/surahs`;
    return fetch(url).then(response => response.json());
}

function getStudents(teacherId) {
    let url = `http://localhost:9080/api/students/teacher/${teacherId}`;
    return fetch(url).then(response => response.json());
}
function getParent(studentid) {
    let url = `http://localhost:9080/api/parents/${studentid}`;
    return fetch(url).then(response => response.json());
}
function getStudentTasks(studentId) {
    let url = `http://localhost:9080/api/tasks/student/${studentId}`;
    return fetch(url).then(response => response.json());
}


function fillSurahsDD(surahs) {
    for (let surah of surahs) {
        $("<option>", {
            value: surah.id,
            text: surah.name + " " + surah.englishName
        }).appendTo($("#surahsDD"))
    }

    $("#surahsDD").on('change', onSurahChange);
}
function fillStudentsDD(students) {
    for (let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName + " " + student.lastName
        }).appendTo($("#studentsDD"))
    }
}


function displayTasks(tasks) {
    let htmlTemplate = $('#tasks-template').html(),
        heroesTemplate = Handlebars.compile(htmlTemplate)

    $('#tasks-list').html(heroesTemplate({tasks}));
}
function onSurahChange() {
    let selectedSurahId = parseInt($("#surahsDD").val());

console.log("selected durah = "+selectedSurahId);
        UpdateSurahParameter(selectedSurahId);

}
function onStudentChange() {
    let selectedStudentId = $("#studentsDD").val();

    getStudentTasks(selectedStudentId).then(tasks => {
        displayTasks(tasks);
    }).catch(err => console.log(err));
}
function fetchDeleteTask(taskid) {
    let url = `http://localhost:9080/api/task/${taskid}`;
    return fetch(url).then(response => response.json());
}

function deleteTask(taskid) {
    if (!confirm('Confirm delete?')) {
        return;
    }

    //Get the data-heroId custom attribute associated with the clicked Link
    //Note this refers to the link that was clicked (i.e., the source of the click event)
    //let heroId = $(this).attr('data-heroId');
    // console.log("deleteHero.heroId: ", heroId);

    let url = `http://localhost:9080/api/task/${taskid}`;
    //console.log("deleteHero.heroId", heroId);
    fetch(url, {method: 'delete'}).then(() => {
        //After successful delete remove the row from the HTML table
        $(this).closest('tr').remove();
    }).then(() => {
        //After delete then refresh the list
        onStudentChange();
    }).catch(err => console.log(err));


}

function UpdateSurahParameter(selectedSurahId) {

    getSurahs().then(surahs=>{
        let surah  = surahs.filter(s=>s.id === selectedSurahId)[0];

        $('#fromAya').attr('max',surah.ayaCount);
        $('#toAya').attr('max',surah.ayaCount);

        $('#fromAya').val(1);
        $('#toAya').val(1);
    });
}


function displayMSGForm() {
    let htmlTemplate = $('#msg-form-template').html(),
        msgTemplate = Handlebars.compile(htmlTemplate);

    let studentid = parseInt($('#studentsDD').val());

    if (studentid) {
        getParent(studentid).then(parent=> {
            $('#div_form').html(msgTemplate({parent}));
        });

    }
    else alert("Please choose any student");


}

function displayTaskForm(taskid) {

    if(taskid)
    {
        console.log("show form in edit mode");
        fetchTask(taskid).then(task => {

            let htmlTemplate = $('#task-form-template').html(),
                taskTemp = Handlebars.compile(htmlTemplate);
console.log("task = " + JSON.stringify(task));
            $('#div_add_form').html(taskTemp({task}));

            getSurahs().then(surahs => {
                    fillSurahsDD(surahs);

                    //Select the heroType in the Dropdown
                    $('#surahsDD').val(task.surahId);
                console.log("task surah id ="+task.surahId);
                    getSurahs().then(surahs=>{
                        let surah  = surahs.filter(s=>s.id === task.surahId)[0];

                        $('#fromAya').attr('max',surah.ayaCount);
                        $('#toAya').attr('max',surah.ayaCount);

                        $('#fromAya').val(task.fromAya);
                        $('#toAya').val(task.toAya);
                        console.log("aya ="+task.fromAya);

                        $('#dd').val(task.dueDate);
                    });


                })
                .catch(err => console.log(err));


            showFormAsModel();

        }).catch(err => console.log(err));
    }
    else {
        console.log("show form in add mode");
        let htmlTemplate = $('#task-form-template').html(),
            taskTemplate = Handlebars.compile(htmlTemplate);
        let studentid = parseInt($('#studentsDD').val());
        if (studentid) {

            $('#div_add_form').html(taskTemplate({}));
            showFormAsModel();
            getSurahs().then(surahs => {
                    fillSurahsDD(surahs);

                })
                .catch(err => console.log(err));



        }
        else alert("Please choose any student");
    }



}

function saveMSG() {
    let today = new Date();
    let mDate = today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();
    let msg = {
        parentId: parseInt($('#parentID').val()),
        studentId: parseInt($('#studentsDD').val()),
        title: $('#title').val(),
        body: $('#message').val(),
        date: mDate,

    };

    let url = "http://localhost:9080/api/messages/";
    let requestMethod = "post";


    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(msg)
    }).then(() => {
        //After add/update then refresh the list
        alert("your message has been sent");
    });
}


function addTask() {

}

function saveTask() {
    let selectedSurahId = parseInt($("#surahsDD").val());
    getSurahs().then(surahs=> {
        let surah = surahs.filter(s=>s.id === selectedSurahId)[0];


        let task = {
            studentId: parseInt($('#studentsDD').val()),
            surahName: surah.englishName,
            fromAya: parseInt($('#fromAya').val()),
            toAya:parseInt( $('#toAya').val()),
            type: $('input[name=type]:checked', '#add_form').val(),
            dueDate: $('#dd').val()


        };

        let url = "http://localhost:9080/api/tasks/";
        let requestMethod = "post";

        let taskId = $('#taskid').val();

        //In case of update make the method put and append the id to the Url
        if (taskId != '') {
            task.taskId = parseInt(taskId);
            task.completedDate=$('#compDate').val();
            task.comment=($('#comment').val()).trim();
            task.masteryLevel= ($('#masterLevel').val()).trim()   ;
            url += taskId;
            requestMethod = "put";
        }
        fetch(url, {
            method: requestMethod,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(task)
        }).then(() => {
            //After add/update then refresh the list
            alert("your task has been Saved");
            onStudentChange();
        });
    });




}

function fetchTask(taskId) {
    let url = `http://localhost:9080/api/tasks/${taskId}`;
    return fetch(url).then(response => response.json());
}

function showFormAsModel() {
    let taskForm = $( "#div_add_form" ).dialog({
        height: 600,
        width: 750,
        title: 'Add Task',
        modal: true,
        buttons: {
            "Submit": function() {
                saveTask();
                taskForm.dialog( "close" );
            },
            Cancel: function() {
                taskForm.dialog( "close" );
            }
        }
    });
}