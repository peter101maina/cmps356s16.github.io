/**
 * Created by N on 4/28/16.
 */

"use strict";

$(document).ready(function () {
    console.log("tyeacher paeg lodedd ");
    let user = JSON.parse(localStorage.user);
    let username = user.username;

    console.log("username=" + JSON.stringify(localStorage.user));
    fillSChildresDD(user.students)


    $("#childrenDD").on('change', onChildrenChange);
});



function fillSChildresDD(children) {
    for (let child of children) {
        $("<option>", {
            value: child.studentId,
            text: child.firstName
        }).appendTo($("#childrenDD"))
    }}

function onChildrenChange() {
    $("#Message-div").empty();
    let selectedStudentId = $("#childrenDD").val();

    getStudentTasks(selectedStudentId).then(tasks => {
        displayTasks(tasks);
    }).catch(err => console.log(err));
}
function displayTasks(tasks) {
    let htmlTemplate = $('#Children-template').html(),
        heroesTemplate = Handlebars.compile(htmlTemplate)

    $('#ChildrenTasks').html(heroesTemplate({tasks}));
}
function fetchTask(taskId) {
    let url = `http://localhost:9080/api/tasks/${taskId}`;
    return fetch(url).then(response => response.json());
}


function getStudentTasks(studentId) {
    let url = `http://localhost:9080/api/tasks/student/${studentId}`;
    return fetch(url).then(response => response.json());
}

function getAnnoucenments()
{
    console.log("getting announcements");
    fetchAnnoucenments().then(ann=>displayAnoucenments(ann) )
        .catch(err => console.log(err));

}
function getChildMessages()
{
    console.log("getting getChildMessages");
let studentId=parseInt($('#childrenDD').val());
    fetchMessages(studentId).then(msg=>displayMessages(msg) )
        .catch(err => alert("no messages"));

}

function fetchAnnoucenments() {

    let url = `http://localhost:9080/api/annoucments`;
    return fetch(url).then(response => response.json());
}
function fetchMessages(studentId) {

    let url = `http://localhost:9080/api/messages/${studentId}`;
    return fetch(url).then(response => response.json());
}



function displayAnoucenments(ann) {

console.log("displaying announcements");
    let htmlTemplate = $('#annoucenment-template').html(),
        aTemplate = Handlebars.compile(htmlTemplate);

    $('#annoucenment').html(aTemplate({ann}));


}
function displayMessages(msg) {

    console.log("displaying announcements");
    let htmlTemplate = $('#Message-template').html(),
        aTemplate = Handlebars.compile(htmlTemplate);

    $('#Message-div').html(aTemplate({msg}));



}