/**
 * Created by Mariam on 4/26/2016.
 */
function validate()
{
    if( document.StudentRegistration.password.value == "" )
    {
        alert( "Please provide Parent Password!" );
        document.StudentRegistration.password.focus() ;
        return false;
    }


    if( document.StudentRegistration.pusername.value == "" )
    {
        alert( "Please provide Parent username!" );
        document.StudentRegistration.pusername.focus() ;
        return false;
    }
    
    
    if( document.StudentRegistration.firstname.value == "" )
    {
        alert( "Please provide Student First Name!" );
        document.StudentRegistration.firstname.focus() ;
        return false;
    }

    if( document.StudentRegistration.lastname.value == "" )
    {
        alert( "Please provide Student Last Name!" );
        document.StudentRegistration.lastname.focus() ;
        return false;
    }
    
    if( document.StudentRegistration.parentId.value == "" )
    {
        alert( "Please provide your parent Id!" );
        document.StudentRegistration.parentId.focus() ;
        return false;
    }

    if ( ( StudentRegistration.sex[0].checked == false ) && ( StudentRegistration.sex[1].checked == false ) )
    {
        alert ( "Please choose your Gender: Male or Female" );
        return false;
    }

    if( document.StudentRegistration.teacherId.value == "null" )
    {
        alert( "Please provide your teacher Id!" );

        return false;
    }

    if( document.StudentRegistration.schoolGrade.value == "null" )
    {
        alert( "Please provide student school Grade!" );

        return false;
    }


    var email = document.StudentRegistration.emailid.value;
    atpos = email.indexOf("@");
    dotpos = email.lastIndexOf(".");
    if (email == "" || atpos < 1 || ( dotpos - atpos < 2 ))
    {
        alert("Please enter correct email ID")
        document.StudentRegistration.emailid.focus() ;
        return false;
    }
    if( document.StudentRegistration.dob.value == "" )
    {
        alert( "Please provide your DOB!" );
        document.StudentRegistration.dob.focus() ;
        return false;
    }
    if( document.StudentRegistration.mobileno.value == "" ||
        isNaN( document.StudentRegistration.mobileno.value) ||
        document.StudentRegistration.mobileno.value.length != 10 )
    {
        alert( "Please provide a Mobile No in the format 123." );
        document.StudentRegistration.mobileno.focus() ;
        return false;
    }
    return( true );
}