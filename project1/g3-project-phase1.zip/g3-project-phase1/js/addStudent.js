/**
 * Created by Mariam on 4/27/2016.
 */
$(document).ready(function () {

    let user = JSON.parse(localStorage.user);
    $('#userFullname').html(user.firstname+" "+user.lastname);
    $('#register').on('click', registerParent);

});

function registerParent(){

    let parent={
        qatariId:$('#qatarId').val(),
        firstName:$('#PfirstName').val(),
        lastName:$('#PlastName').val(),
        mobile:$('#mobileNo').val(),
        email:$('#email').val(),
        username:$('#userName').val(),
        password:$('#userPassword').val(),
        students:[{
            firstName:$('#firstName').val(),
            lastName:$('#lastName').val(),
            dob:$('#dob').val(),
            gender:$('#gender').val(),
            schoolGrade:$('#schoolgrade').val(),
            parentUserName:$('#parentsDD').val()}]
    }
    let url = "http://localhost:9080/api/parents/";
    let method = "post";

    fetch(url, {
        method: method,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(parent)
    }).then(() => {
        //After add/update then refresh the list
        alert("pare added")
        window.location="/Coordinate.html";
    });
}



