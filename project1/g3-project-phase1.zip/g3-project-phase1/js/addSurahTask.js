/**
 * Created by Mariam on 4/27/2016.
 */
'use strict'
$(document).ready(function () {

    let user = JSON.parse(localStorage.user);
    $('#userFullname').html(user.firstname+" "+user.lastname);
    getSurahs().then(surahs => fillSurahsDD(surahs))
        .catch(err => console.log(err));


    $('#add').on('click', addTask);
    $("#surahsDD").on('change', onSurahChange);
    $("#fromAya").on('change', onAyaChange);


});
function fillSurahsDD(surahs) {
    var su=surahs
    for(let surah of surahs) {
        $("<option>", {
            value: surah.id,
            text: surah.englishName
        }).appendTo($("#surahsDD"))
    }
}
function  addTask(){

}
function onSurahChange(){
    let id=$('#surahsDD').val()
    let sDetails=su.filter(s=>s.id==id)
    let maxi=sDetails.ayaCount
    $('#fromAya').attr('max',maxi)
    $('#toAya').attr('max',"8")

}
function getSurahs(){
    let url = "http://localhost:9080/api/surahs";
    return fetch(url).then(response => response.json())
}