/**
 * Created by Mariam on 4/26/2016.
 */
"use strict";
let express = require('express'),
    bodyParser = require('body-parser')
//open = require('open');

let app = express();
//Allow serving static files
app.use(express.static(__dirname));

let port = 9080;

app.use(bodyParser.urlencoded({extended:true}));
//aut-deserialize the body of incoming request to a json object
app.use(bodyParser.json());


let userRepository = require('./repository/UserRepo');
let userController = require('./controllers/LoginController');
let studentRepository = require('./repository/StudentRepo');
let taskController = require('./controllers/TaskController');
let surahController = require('./controllers/SurahController');
let msgController= require('./controllers/MsgController')
let annController=require('./controllers/AnnouncementController');
let studentController=require('./controllers/StudentController');


app.get('/about', (req, res) => {
    res.send(`Welcome to Client-Server WebApp Example!!! <br>
    <p>
        Urls: <br>
        - http://localhost:9080/student.html to interact with the list of students <br>
        - http://localhost:9080/api/students  to get students as a json document <br>
        - http://localhost:9080/api/students/2015001 to get details of student 2015001 as a json document <br><br>
        - http://localhost:9080/hero.html to interact with the list of heros <br>
        - http://localhost:9080/api/heroes to get heroes as a json document <br>
        - http://localhost:9080/api/heroes/1 to get hero 1 as a json document <br>
        - Use Postman to test post/put/delete http://localhost:9080/api/heroes <br>
    </p>`);
});






app.get('/', (req, res) => {
   // res.status(201).send(`./html/loginPage.html`);
    res.redirect(`./html/loginPage.html`);
});

app.post('/', (req, res) => {
    let userInfo = req.body;
    let un=userInfo.username;
    let pw=userInfo.password;
    
console.log("app.post.req.body", userInfo);
userRepository.userLogin(un,pw).then(user =>{
    if (user.qatariId) {
        user.redirectTo = '/html/Perant.html'
    }
    
    else if(user.staffNo){
        if(user.isCoordinator){

            user.redirectTo = '/html/Coordinate.html'
        }
        else {
            
            user.redirectTo = '/html/teacher.html'
        }
    }
    res.json(user);
} );
  
});

app.get('/api/students', (req, res) => {
    studentRepository.getParents().then(students => {
    res.json(students);
});
});
app.post('/api/students', (req, res) => {    studentController.addParent(req, res)});

app.put('/api/students/', (req, res) => {    studentController.updateParent(req, res)});




app.get('/api/tasks/:taskId', (req, res) => taskController.getTask(req, res));

app.get('/api/tasks/student/:studentId', (req, res) => taskController.getTasksByStudentId(req, res));

app.get('/api/parents/:studentId', (req, res) => {
    let studentId = req.params.studentId;
    console.log('req.params.studentId', studentId);
    studentId=parseInt(studentId);
    studentRepository.getParents().then(parents => {
        console.log(JSON.stringify(parents, null, 2));
        for (let p of parents)
        {
            for(let s of p.students )

                {
                    if(s.studentId===studentId)
                    {
                        res.json(p);
                        break;
                    }

                }
        }

    }).catch(err => {
        res.status(500).send(`error`);
    });
});


app.get('/api/students/teacher/:id', (req, res) => {
    let teacherId = req.params.id;
    console.log('req.params.id', teacherId);
    studentRepository. getStudentOfTeacher(parseInt(teacherId)).then(students => {
        console.log(JSON.stringify(students, null, 2));
        res.json(students);
    }).catch(err => {
        res.status(201).send(`Created and available @ ${urlOfNewHero}`);
    });
});


app.get('/api/parents/:id', (req, res) => studentController.getStudentOfParent(req, res));
app.get('/api/surahs', (req, res) => surahController.getSurahs(req, res));
app.get('/api/heroes', (req, res) => taskController.getTaskByType(req, res));
app.get('/api/heroes/:id', (req, res) => taskController.getTask(req, res));
app.post('/api/messages/', (req, res) => msgController.addMsg(req, res));
app.get('/api/messages/:id', (req, res) => msgController.getStudentMessages(req, res));
app.post('/api/annoucments/', (req, res) => annController.addAnnoucement(req, res));
app.post('/api/tasks/', (req, res) => taskController.addTask(req, res));
app.put('/api/tasks/:id', (req, res) => taskController.updateTask(req, res));
app.delete('/api/task/:id', (req, res) => taskController.deleteTask(req, res));
app.get('/api/annoucments/', (req, res) => annController.getAnnoucements(req, res));
app.get('/api/tasks/', (req, res) => taskController.getTasks(req, res));
app.listen(port, function(){console.log('Students App is running my app on http://localhost:' + port+'/html/loginPage.html');
});