/**
 * Created by Mariam on 4/25/2016.
 */
'use strict'

class TaskRepository {
    constructor() {
        this.fs = require('fs');
    }
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }
    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }
    getTasks() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(t => {


                        resolve(t);
                    }) .catch(err => {
                console.log(err);
                    reject(err);
                });
            });
    }


    getTaskByStudentId(studentId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks = tasks.filter(t => t.studentId === studentId);

                resolve(tasks);
            });


        })

    }



    getTaskByType(type) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                if (type=="Completed")
                {tasks = tasks.filter(t => t.completedDate);}
                else
                {tasks = tasks.filter(t => !(t.completedDate));}

                if (tasks.length > 0) {
                    resolve(tasks);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getTaskById(taskId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks= tasks.filter(t => t.taskId === taskId);
                if (tasks.length > 0) {
                    resolve(tasks[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getTaskOfStudentwithtID(teacherId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let studentRepository = require('../repository/StudentRepo');
                studentRepository.getStudentOfTeacher(teacherId).then(students => {


                    let tasks2=[]
                    for(let s of students){
                        {
                            let t= tasks.filter(t=>t.student.studentId===s.studentId)

                            for(let tas of t)
                                tasks2.push(tas)
                        }
                    }

                    if (tasks2.length > 0) {
                        resolve(tasks2);
                    }
                    else {
                        reject("No records found");
                    }
                })
            });
        });
    }
    getTaskOfStudentByType(studentId,type) {
        return new Promise((resolve, reject) => {
            this.getTaskByStudentId(studentId).then(tasks => {

                if (type=="Completed")
                {tasks = tasks.filter(t => t.completedDate);}
                else
                {tasks = tasks.filter(t => !(t.completedDate));}
                if (tasks.length > 0) {
                    resolve(tasks);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }


    getTaskOfParentstudent(username) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let studentRepository = require("../repository/StudentRepo");
                studentRepository.getStudentOfParent(username).then(students =>{
                    let t = [];
                    for (let task of tasks)
                    {
                        for (let student of students )
                        {
                            if(task.studentId==student.studentId)
                                t.push(task);
                        }
                    }

                    if (t.length > 0) {
                        resolve(t);
                    }
                    else {
                        reject("No records found");
                    }

                })
            })
        });
    }




    addTask(task) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                //Get the last Id used +1
                let maxId = Math.max.apply(Math, tasks.map(t => t.taskId)) + 1;
                console.log("maxId", maxId);

                task.taskId = maxId;

                console.log("addTask", task);
                tasks.push(task);
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(()=> resolve(task))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    updateTask(task) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let len = tasks.length;
                for(let i=0; i<len; i++){
                    if (tasks[i].taskId == task.taskId) {
                        tasks[i] = task;
                        break;
                    }
                }
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(()=> resolve())
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    deleteTask(taskId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let len = tasks.length;
                console.log('length ='+len);
                let foundAt = -1;
                for (let i = 0; i < len; i++) {
                    if (tasks[i].taskId == taskId) {
                        foundAt = i;
                        console.log('task found');
                        break;
                    }
                }
                if (foundAt >= 0) {
                    tasks.splice(foundAt, 1);
                    console.log('task found @'+foundAt);
                }
                console.log("task deleted", taskId);

                return this.writeJsonFile('./data/task.json', tasks);
            }).then(() => {
                resolve();
            }).catch(err => {
                console.log(err);
                reject(err);
            });
        });
    }



}

module.exports = new  TaskRepository ();