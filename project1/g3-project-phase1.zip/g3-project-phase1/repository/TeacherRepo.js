/**
 * Created by Mariam on 4/26/2016.
 */

'use strict'
class TeacherRepo {
    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }





    getTeachers() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(t => {

                resolve(t);
            }).catch(err => {
                reject(err);
            });
        });
    }






}
module.exports= new TeacherRepo();