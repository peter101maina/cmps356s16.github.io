/**
 * Created by Mariam on 4/26/2016.
 */

'use strict'

class MsgRepo {
    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }



    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }

    getMessages() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/msg.json').then(m => {
                resolve(m);
            }).catch(err => {
                reject(err);
            });
        });
    }







    getMessageByStudentId(studentId) {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                console.log(studentId);
                messages.forEach(m =>{
                    console.log("****"+m.studentId);
                });
                messages = messages.filter(m => m.studentId === studentId);
                if (messages.length > 0) {
                    resolve(messages);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    addMessage(message) {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                let maxId = Math.max.apply(Math, messages.map(m => m.messageId)) + 1;
                console.log("maxId", maxId);

                message.messageId = maxId;

                console.log("addMessage", message);
                messages.push(message);
                return this.writeJsonFile('./data/msg.json', messages);
            }).then(()=> resolve(message))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }




    
    
}
module.exports= new MsgRepo();