/**
 * Created by Mariam on 4/26/2016.
 */
'use strict'

class HeroRepository {
    constructor() {
        this.fs = require('fs');
    }

    //Read a file and convert its content to a json object
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }

    getTeachers() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(t => {
                resolve(t);
            }).catch(err => {
                reject(err);
            });
        });
    }


    getParents() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(p => {
                resolve(p);
            }).catch(err => {
                reject(err);
            });
        });
    }


    getCoordinators() {
        return new Promise((resolve, reject) => {
            this.getTeachers().then(t => {
                t=t.filter(teacher => teacher.isCoordinator ===1);
                resolve(t);
            }).catch(err => {
                reject(err);
            });
        });
    }


    userLogin(username,password){
        return new Promise((resolve, reject) => {
            this.getTeachers().then(ts=> {
                ts = ts.filter(t => t.username === username && t.password === password);
                if (ts.length > 0) {

                        resolve(ts[0]);
                }else{
                    this.getCoordinators().then(cs=> {
                        cs = cs.filter(c => c.username === username && c.password === password);
                        if (cs.length > 0) {

                            resolve(cs[0]);
                        }else{

                            this.getParents().then(ps=> {
                                ps = ps.filter(p => p.username === username && p.password === password);
                                if (ps.length > 0) {

                                    resolve(ps[0]);
                                }else{

                               reject("Error username / passsword incorrect");

                                }
                            });
                            
                        }
                    });
                    
                }
            });
        });
    }

    


    getHero(heroId) {
        return new Promise((resolve, reject) => {
            this.getTeachers().then(heroes => {
                heroes = heroes.filter(h => h.id === heroId);
                if (heroes.length > 0) {
                    resolve(heroes[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    addHero(hero) {
        return new Promise((resolve, reject) => {
            this.getTeachers().then(heroes => {
                //Get the last Id used +1
                let maxId = Math.max.apply(Math, heroes.map(h => h.id)) + 1;
                console.log("maxId", maxId);

                hero.id = maxId;

                console.log("heroController.addHero", hero);
                heroes.push(hero);
                return this.writeJsonFile('./data/hero.json', heroes);
            }).then(()=> resolve(hero))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    updateHero(hero) {
        return new Promise((resolve, reject) => {
            this.getTeachers().then(heroes => {
                let len = heroes.length;
                for(let i=0; i<len; i++){
                    if (heroes[i].id == hero.id) {
                        heroes[i] = hero;
                        break;
                    }
                }
                return this.writeJsonFile('./data/hero.json', heroes);
            }).then(()=> resolve())
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    deleteHero(heroId) {
        return new Promise((resolve, reject) => {
            this.getTeachers().then(heroes => {
                // Look for the hero to be deleted then remove it
                let len = heroes.length;
                let foundAt = -1;
                for (let i = 0; i < len; i++) {
                    if (heroes[i].id == heroId) {
                        foundAt = i;
                        break;
                    }
                }
                if (foundAt >= 0) {
                    heroes.splice(foundAt, 1);
                }
                console.log("heroController.deleteHero", heroId);

                //Save the heros back to the file
                return this.writeJsonFile('./data/hero.json', heroes);
            }).then(() => {
                resolve();
            }).catch(err => {
                reject(err);
            });
        });
    }
}

module.exports = new HeroRepository();