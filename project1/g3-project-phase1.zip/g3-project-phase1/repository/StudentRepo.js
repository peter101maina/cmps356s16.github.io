/**
 * Created by Mariam on 4/26/2016.
 */

'use strict'
class StudentRepo {
    constructor() {
        this.fs = require('fs');
    }
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }
    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }
    getParents() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(parents => {

                resolve(parents);
            }).catch(err => {
                reject(err);
            });})
        //  });
    }
    getParentByUesrName(username) {
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {

                parents = parents.filter(p => p.username === username);
                if (parents.length > 0) {
                    resolve(parents[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getStudents(){
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {
                let students=[];
                for(var i=0;i<parents.length;i++){
                    for(var j=0;j<parents[i].students.length;j++)
                    {
                        students.push(parents[i].students[j]);
                    }
                }
                if (students.length > 0) {
                    resolve(students);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getStudentOfTeacher(teacherId){
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                students = students.filter(s => s.teacherId === teacherId);
                if (students.length > 0) {
                    resolve(students);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getStudentSParents(username){
        return new Promise((resolve, reject) => {
            this.getParentByUesrName(username).then(parent => {
                let students = parent.students;
                if (students.length > 0) {
                    resolve(students);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }



    getStudentById(studentId){
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                students = students.filter(s => s.studentId === studentId);

                if (students.length > 0) {
                    resolve(students[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    addParent(parent) {
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {

                this.getStudents().then(students=>{
                    let maxId = Math.max.apply(Math, students.map(s => s.studentId)) + 1;
                    console.log("maxId", maxId);

                    for(let i=0;i<parent.students.length;i++)

                        parent.students[i].studentId=(i+maxId);

                    console.log("addParent", parent);
                    parents.push(parent);
                    return this.writeJsonFile('./data/student.json', parents);
                }).then(()=> resolve(parent))
                    .catch(err => {
                        console.log(err);
                        reject(err);
                    });});

        });
    }

    updateParent(parent) {
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {
                this.getStudents().then(students=> {
                    let maxId = Math.max.apply(Math, students.map(s => s.studentId)) + 1;

                    for(let student of parent.students){
                        if(student.studentId!==undefined){
                            maxId=maxId+1;
                            student.studentId=maxId;
                        }
                    }
                    let len = parents.length;
                    for (let i = 0; i < len; i++) {
                        if (parents[i].qatariId === parent.qatariId) {
                            parents[i] = parent;
                            break;
                        }
                    }
                    return this.writeJsonFile('./data/student.json', parents);
                });
            }).then(()=> resolve())
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

}
module.exports= new StudentRepo();