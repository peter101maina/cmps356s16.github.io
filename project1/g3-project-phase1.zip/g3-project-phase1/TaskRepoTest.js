/**
 * Created by Mariam on 4/25/2016.
 */
'use strict'
let SectionRepository = require('./repository/AnnouncementRepo.js');



SectionRepository.getAnnoucements().then(Annoucements => {

    console.log(Annoucements);
});

