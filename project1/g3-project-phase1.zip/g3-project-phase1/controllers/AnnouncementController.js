/**
 * Created by N on 4/28/16.
 */
'use strict'
class AnnouncementController {
    constructor() {
        this.msgRepo = require('../repository/AnnouncementRepo');
    }

    addAnnoucement(req, res) {
        let anno = req.body;

        this.msgRepo.addAnnoucement(anno).then((m)=> {


                res.status(201).send(`Created and available `);
            })
            .catch(err => res.status(500).send(err));
    }

    getAnnoucements(req, res) {
        this.msgRepo.getAnnoucements().then(annoucements => {
            res.json(annoucements);
        }).catch(err => res.status(500).send(err));
    }


}
module.exports = new AnnouncementController();