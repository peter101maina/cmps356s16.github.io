/**
 * Created by Mariam on 4/26/2016.
 */
'use strict'
class LoginController
{
    constructor() {
        this.userRepository = require('../repository/UserRepo');
    }

    getParents(req, res) {
        this.userRepository.getParents().then(p => {
            res.json(p);
        });
    }


    getCoordinators(req, res) {
        this.userRepository.getCoordinators().then(c => {
            res.json(c);
        });
    }
    
    getTeachers(req, res) {
        this.userRepository.getTeachers().then(t => {
            res.json(t);
        });
    }
    
    
   
    

    addHero(req, res) {
        let hero = req.body;

        this.userRepository.addHero(hero).then((hero)=> {
                let urlOfNewHero = `/api/heroes/${hero.id}`;
                res.location(urlOfNewHero)
                res.status(201).send(`Created and available @ ${urlOfNewHero}`);
            })
            .catch(err => res.status(500).send(err));
    }

    updateHero(req, res) {
        let hero = req.body;

        this.userRepository.updateHero(hero).then(() => {
            res.status(200).send("Hero updated successfully");
        }).catch(err => {
            console.log(err);
            res.status(500).send(err);
        });
    }

    deleteHero(req, res) {
        let heroId = req.params.id;

        this.userRepository.deleteHero(heroId).then(() => {
            res.status(200).send("Hero deleted");
        }).catch(err => {
            res.status(500).send(err);
        });
    }
}

module.exports = new LoginController();