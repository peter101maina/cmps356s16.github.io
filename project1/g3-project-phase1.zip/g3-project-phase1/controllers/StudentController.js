/**
 * Created by Mariam on 4/26/2016.
 */

'use strict'
class StudentController{
    constructor() {
        this.studentRepository = require('../repository/StudentRepo.js');
    }

    getStudents(req, res) {
        this.studentRepository.getStudents().then(students => {
            res.json(students);
        });
    }
    getStudent(req, res) {
        let studentId=req.params.studentId
        this.studentRepository.getStudentById(studentId).then(student => {
            res.json(student);
        });
    }

    getParents(req, res) {
        this.studentRepository.getParents().then(parents => {
            res.json(parents);
        });
    }

    getParentByUserName (req, res) {
        let username = req.params.username;
        console.log('req.params.username', username);
        this.studentRepository.getParentByUN(username).then(parent => {
            console.log(JSON.stringify(parent, null, 2));
            res.json(parent);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }
    getStudentOfParent (req, res) {
        let username = req.params.username;
        console.log('req.params.username', username);
        this.studentRepository.getStudentSParents(username).then(student => {
            console.log(JSON.stringify(student, null, 2));
            res.json(student);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    addParent(req, res) {
        let parent = req.body;
console.log("adding parent => " + parent);
        this.studentRepository.addParent(parent).then((parent)=> {
                let urlOfNewParents = `/api/parents/${parent.username}`;
                res.location(urlOfNewParents)
                res.status(201).send(`Created and available @ ${urlOfNewParents}`);
            })
            .catch(err => res.status(500).send(err));
    }
    updateParent(req, res) {
        let parent = req.body;
        console.log("updating parent => " + parent);
        this.studentRepository.updateParent(parent).then((parent)=> {
                let urlOfNewParents = `/api/parents/${parent.username}`;
                res.location(urlOfNewParents)
                res.status(201).send(`Created and available @ ${urlOfNewParents}`);
            })
            .catch(err => res.status(500).send(err));
    }



}

module.exports = new StudentController();
