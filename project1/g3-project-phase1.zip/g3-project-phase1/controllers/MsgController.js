/**
 * Created by N on 4/27/16.
 */
'use strict'
class MsgController {
    constructor() {
        this.msgRepo = require('../repository/MsgRepo');
    }

    addMsg(req, res) {
        let msg = req.body;

        this.msgRepo.addMessage(msg).then((m)=> {


            res.status(201).send(`Created and available `);
            })
            .catch(err => res.status(500).send(err));
    }

    getStudentMessages(req,res){

        let id = parseInt(req.params.id);
       console.log('req.params.id', id);
        this.msgRepo.getMessageByStudentId(id).then(msg => {
            console.log(JSON.stringify(msg, null, 2));
            res.json(msg);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });






    }

}
module.exports = new MsgController();