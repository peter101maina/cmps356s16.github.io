"use strict";
let express = require('express'),
    bodyParser = require('body-parser'),
    fs = require('fs'),
    multer = require('multer'),
    path = require('path'),
    uuid = require('node-uuid');

let app = express();
//Allow serving static files
app.use(express.static(__dirname));

let port = 9090;

app.use(bodyParser.urlencoded({extended:true}));
//aut-deserialize the body of incoming request to a json object
app.use(bodyParser.json());

let halaqaMetrashController = require('./HalaqaMetrashController');

app.post('/', (req, res) => {
    let userInfo = req.body;
    console.log("app.post.req.body", userInfo);

    if (userInfo.username.startsWith('teacher')) {
        userInfo.redirectTo = '/TeacherManaging.html';
        res.json(userInfo);
    } else if(userInfo.username.startsWith('coordinator')){
        userInfo.redirectTo = '/Coordinator.html';
        res.json(userInfo);
    }
    else{
        userInfo.redirectTo = '/ParentSlctChildForFollow-up.html';
        res.json(userInfo);
    }
});



app.get('/api/msgs', function(req, res){
    res.sendFile(path.join(__dirname, '/sendMessage.html'));
});
let options = multer.diskStorage(
    {
        destination: 'uploads/',
        filename: function (req, file, cb) {
            let fileName = uuid.v1() + path.extname(file.originalname);
            cb(null, fileName);
        }
    })

app.post('/uploads', multer({ storage: options}).single('msgImage'), (req, res) => {
    console.log("form fields if any", req.body);
    console.log("Uploaded file details", req.file);
    let uploadedFileName = req.file.filename;
    console.log('uploadedFileName', uploadedFileName);

    let imgUrl = `http://localhost:9090/uploads/${uploadedFileName}`;
    console.log('Url of uploaded image', imgUrl);

});

app.get('/api/tasks', (req, res) => halaqaMetrashController.getTasks(req, res));
app.get('/api/tasks/:id', (req, res) => halaqaMetrashController.getTask(req, res));
app.post('/api/tasks/', (req, res) => halaqaMetrashController.addTask(req, res));
app.post('/api/parents/', (req, res) => halaqaMetrashController.addParent(req, res));
app.put('/api/parents/:id', (req, res) => halaqaMetrashController.updateStudent(req, res));
app.put('/api/tasks/:id', (req, res) => halaqaMetrashController.updateTask(req, res));
app.delete('/api/tasks/:id', (req, res) => halaqaMetrashController.deleteTask(req, res));
app.get('/api/teachers/:id', (req, res) => halaqaMetrashController.getTeacher(req, res));
app.get('/api/students',(req, res) => halaqaMetrashController.getStudents(req, res));
app.get('/api/students/:id',(req, res) => halaqaMetrashController.getStudent(req, res));
app.get('/api/studentsByTeacher/:id',(req, res) => halaqaMetrashController.getStudentByteacherId(req, res));
app.get('/api/parentStudents/:id',(req, res) => halaqaMetrashController.getStudentsByParent(req, res));
app.get('/api/parents/:id',(req, res) => halaqaMetrashController.getParent(req, res));
app.get('/api/studentTasks/:id', (req, res) => halaqaMetrashController.getStudentTasks(req, res));
app.get('/api/surahs',(req,res) => halaqaMetrashController.getSurahs(req, res));
app.get('/api/surahs/:id',(req,res) => halaqaMetrashController.getSurah(req, res));
app.get('/api/msgs',(req,res) => halaqaMetrashController.getMsgs(req, res));
app.get('/api/msgs/:id',(req,res) => halaqaMetrashController.getStudentMsgs(req, res));
app.get('/api/announcements',(req,res) => halaqaMetrashController.getAnnouncements(req, res));
app.listen(port, function(){
  console.log('Students App is running my app on http://localhost:' + port);
});