'use strict'
class HalaqaMetrashRepository {
    constructor() {
        this.fs = require('fs');
    }

    //Read a file and convert its content to a json object
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }
    getTasks() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(tasks => {
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getTask(taskId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks = tasks.filter(t => t.taskId === taskId);
                if (tasks.length > 0) {
                    resolve(tasks[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getStudentTasks(studentId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks = tasks.filter(t => t.studentId === studentId);
                if (tasks.length > 0) {
                    resolve(tasks);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    addTask(task) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                //Get the last Id used +1
                let maxId = Math.max.apply(Math, tasks.map(t => t.taskId)) + 1;
                console.log("maxId", maxId);

                task.taskId = maxId;

                console.log("HalaqaMetrashController.addTask", task);
                tasks.push(task);
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(()=> resolve(task))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    updateTask(task) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let len = tasks.length;
                for(let i=0; i<len; i++){
                    if (tasks[i].taskId == task.taskId) {
                        tasks[i] = task;
                        break;
                    }
                }
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(()=> resolve())
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    deleteTask(taskId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                // Look for the task to be deleted then remove it
                let len = tasks.length;
                let foundAt = -1;
                for (let i = 0; i < len; i++) {
                    if (tasks[i].taskId == taskId) {
                        foundAt = i;
                        break;
                    }
                }
                if (foundAt >= 0) {
                    tasks.splice(foundAt, 1);
                }
                console.log("HalaqaMetrashController.deleteTask", taskId);

                //Save the tasks back to the file
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(() => {
                resolve();
            }).catch(err => {
                reject(err);
            });
        });
    }
    getTeachers(){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(teachers => {
                resolve(teachers);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getTeacher(username){
        return new Promise((resolve, reject) => {
            this.getTeachers().then(teachers => {
                teachers  = teachers .filter(t => t.username === username);
                if (teachers.length > 0) {
                    resolve(teachers[0]);}
                else{ reject("No records found");}
               
            });
        });
    }
    getCoordinators() {
        return new Promise((resolve, reject) => {
            this.getTeachers().then(teachers => {
                teachers  = teachers .filter(t => t.username === "coordinator");
                if (teachers.length > 0) {
                    resolve(teachers);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getCoordinator(username){
        return new Promise((resolve, reject) => {
            this.getCoordinators().then(coordinators => {
                coordinators = coordinators.filter(c => c.username === username);
                if (coordinators.length > 0) {
                    resolve(coordinators[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
getStudents() {
    let result=[];
    let i;
    let element;
    return new Promise((resolve, reject) => {
        this.readJsonFile('./data/student.json').then(students => {
            students  = students.map(s=>s.students);
            for(element of students)
            {
                if(element instanceof Array)
                {   for(i=0;i<element.length;i++)
                      {
                          result.push(element[i]);
                      }
                }
            }
            resolve(result);
        }).catch(err => {
            reject(err);
        });
    });
}

getStudent(studentId) {
    return new Promise((resolve, reject) => {
        this.getStudents().then(students => {
            students = students.filter(s => s.studentId === studentId);
            if (students.length > 0) {
                resolve(students[0]);
            }
            else {
                reject("No records found");
            }
        });
    });
}
    getStudentByteacherId(teacherId) {
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                students = students.filter(s => s.teacherId=== teacherId);
                if (students.length > 0) {
                    resolve(students);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getStudentsByParent(lastName) {
        let result=[];

        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                students = students.filter(s => s.lastName === lastName);
                if (students.length > 0) {

                    result.push(students[0]);
                    result.push(students[1]);
                    result.push(students[2]);

                    resolve(result);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getParents() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(parents => {
              //  parents  = parents.map(s=>s=s);
                resolve(parents);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getParent(username){
        let result;
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {
               // console.log(parents);
                parents= parents .filter(p => p.username === username);
                console.log(parents);
                if (parents.length > 0)
                {
                    resolve(parents[0]);}
                else{reject("No records found");}

            });
        });
    }
    addParent(parent) {
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {
                console.log("HalaqaMetrashController.addParent", parent);
                parents.push(parent);
                return this.writeJsonFile('./data/student.json', parents);
            }).then(()=> resolve(parent))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
    updateStudent(student) {
        return new Promise((resolve, reject) => {
            this.getParents().then(students => {
               /*  let maxId = Math.max.apply(Math, students.map(t => t.studentId)) + 1;
                 console.log("maxId", maxId);
                student.studentId = maxId;
*/
                let len = students.length;
                for(let i=0; i<len; i++){
                    if (students[i].username === student.username) {
                        students[i] = student;
                        break;
                    }
                }
                return this.writeJsonFile('./data/student.json', students);
            }).then(()=> resolve())
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

addStudent(student) {
    return new Promise((resolve, reject) => {
        this.getStudents().then(students => {
            //Get the last Id used +1
            let maxId = Math.max.apply(Math, students.map(s => s.studentId)) + 1;
            console.log("maxId", maxId);

            student.studentId = maxId;

            console.log("HalaqaMetrashController.addStudent", student);
            students.push(student);
            return this.writeJsonFile('./data/student.json', students);
        }).then(()=> resolve(student))
            .catch(err => {
                console.log(err);
                reject(err);
            });
    });
}
    getSurahs() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/surah.json').then(surahs => {
                resolve(surahs);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getSurah(id){
        return new Promise((resolve, reject) => {
            this.getSurahs().then(surahs => {
                surahs = surahs.filter(s => s.id === id);
                if (surahs.length > 0) {
                    resolve(surahs[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getMsg(msgId) {
        return new Promise((resolve, reject) => {
            this.getMsgs().then(msgs => {
                msgs = msgs.filter(t => t.messageId === messageId);
                if (msgs.length > 0) {
                    resolve(msgs[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getStudentMsgs(studentId) {
        return new Promise((resolve, reject) => {
            this.getMsgs().then(msgs => {
                msgs = msgs.filter(t => t.studentId === studentId);
                if (msgs.length > 0) {
                    resolve(msgs);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getAnnouncements() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/announcement.json').then(annouc => {
                resolve(annouc);
            }).catch(err => {
                reject(err);
            });
        });
    }

    sendMessage(message) {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                //Get the last Id used +1
                let maxId = Math.max.apply(Math, messages.map(m => m.messageId)) + 1;
                console.log("maxId", maxId);

                message.messageId = maxId;

                console.log("HalaqaMetrashController.sendMessage", message);
                messages.push(message);
                this.writeJsonFile('./data/messages.json', messages);
            }).then(()=> resolve(message))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    getMessages() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/message.json').then(messages => {
                resolve(messages);
            }).catch(err => {
                reject(err);
            });
        });
    }


}
module.exports = new HalaqaMetrashRepository ();