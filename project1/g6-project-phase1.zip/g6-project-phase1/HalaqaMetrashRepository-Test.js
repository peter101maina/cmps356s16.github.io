/**
 * Created by Nour Moslem on 22/04/2016.
 */

'use strict'
let halaqaMetrashRepository = require('./HalaqaMetrashRepository.js');
/*halaqaMetrashRepository.getTeachers().then(teachers =>{
    console.log(teachers);
});
halaqaMetrashRepository.getCoordinators().then(coordinators =>{
    console.log(coordinators);
});
let username ='coordinator';
halaqaMetrashRepository.getCoordinator(username).then(coordinator =>{
    //Displays a pretty-printed multiline JSON representation indented with 2 spaces
    console.log(JSON.stringify(coordinator, null, 2));});*/
/*halaqaMetrashRepository.getStudents().then(result=>{
    console.log(result);
});*/

/*let studentId=2;
halaqaMetrashRepository.getStudent(studentId).then(student=>{
    console.log(student);
}).catch(err=>{
    console.log(err);
});*/
//*let teacher='teacher1';
/*halaqaMetrashRepository.getTeacher(teacher).then(teacher =>{
    console.log(teacher);
});
let teacherId=501;
halaqaMetrashRepository.getStudentByteacherId(teacherId).then(students=> {
console.log(students);
    }).catch(err=> {
        console.log(err);
    });*/
let lastName='Dahak';
halaqaMetrashRepository.getStudentsByParent(lastName).then(parents =>{
    console.log(parents);
}).catch(err=> {
    console.log(err);
});

/*halaqaMetrashRepository.getParents().then(parents =>{
    console.log(parents);
}).catch(err=> {
    console.log(err);
});*/

/*
let lastName='juha';
halaqaMetrashRepository.getParent(lastName).then(parents =>{
    console.log(parents);
}).catch(err=> {
    console.log(err);
});
*/
