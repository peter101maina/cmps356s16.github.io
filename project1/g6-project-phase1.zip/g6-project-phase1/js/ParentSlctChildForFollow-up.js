'use strict'

$(document).ready(function() {
    let user = JSON.parse(localStorage.user);
    console.log("$(document).ready.user", user);
    if (user != 'undefined') {
        $('#username').html(user.username);
    }
    getStudents(user.username);
    $('#studentsDD').on('change', onStudentChange);

});

function getMsg(studentId) {
    let url = `http://localhost:9090/api/msgs/${studentId}`;
    return fetch(url).then(response => response.json());
}
function getAnnouncements() {
    let url = `http://localhost:9090/api/announcements`;
    return fetch(url).then(response => response.json());
}
function getStudents(username) {
    //$('#student-template').empty();
    return fetchParent(username).then(parent => fetchStudents(parent.lastName))
        .then(students=> {
            console.log(students);
            fillStudentsDD(students);
        }).catch(err => console.log(err));
}

function  fetchTasks(studentId) {
    let url = `http://localhost:9090/api/studentTasks/${studentId}`;
    return fetch(url).then(response => response.json());
}
function fetchParent(username) {
    let url = `http://localhost:9090/api/parents/${username}`;
    return fetch(url).then(response => {
        return response.json();
    }).catch(err=>{ console.log(err)});
}
function fetchStudents(lastName){
    let url=`http://localhost:9090/api/parentStudents/${lastName}`;
    return fetch(url).then(response => {
        return response.json();
    }).catch(err=> {console.log(err)});
}

function onStudentChange() {
    let studentId = $(this).val();
    fetchTasks(studentId).then(tasks => {
        tasks = tasks.filter(t=>t.completedDate);
        let htmlTemplate = $('#studentCompletedTasks-template').html(),
            CompletedTasksTemplate = Handlebars.compile(htmlTemplate);
        $('#completedTasks-list').html(CompletedTasksTemplate({tasks}));
    });
    fetchTasks(studentId).then(tasks => {
        tasks = tasks.filter(t=>!(t.completedDate));
        let htmlTemplate = $('#studentTasks-template').html(),
            TasksTemplate = Handlebars.compile(htmlTemplate);
        $('#studentDetails').html(TasksTemplate({tasks}));
    });

    getMsg(studentId).then(msg => {
        displayMsgs(msg);
    }).catch(err => console.log(err));


    getAnnouncements().then(announc => {
        displayAnnouncements(announc);
    }).catch(err => console.log(err));
}
function fillStudentsDD(students) {
    for(let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName
        }).appendTo($("#studentsDD"))
    }
}
function displayMsgs(msgs) {

    let htmlTemplate = $('#msg-template').html(),
        msgTemplate = Handlebars.compile(htmlTemplate);

    console.log('msgTemplate(msg):', msgTemplate(msgs));

    $('#studentmsg').html(msgTemplate({msgs}));

}
function displayAnnouncements(announc) {

    let htmlTemplate = $('#announc-template').html(),
        announceTemplate = Handlebars.compile(htmlTemplate);

    $('#studentAnnounc').html(announceTemplate({announc}));

}