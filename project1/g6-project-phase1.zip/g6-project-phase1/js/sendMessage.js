/**
 * Created by Sarah Kharbach on 22/04/2016.
 */
'use strict'
$(document).ready(function () { // Show name of user on top
    let user = JSON.parse(localStorage.user);
    let studentId = JSON.parse(localStorage.studentId);
    console.log("$(document).ready.user", user);
    if (user != 'undefined') {
        $('#username').html(user.username);
    }
    if (studentId != 'undefined') {
        $('#firstName').html(fetchStudent(studentId).then(student => student.studentId));
    }
    $('#sendMsg').on('click',getTSendMsgTemplate);

});

function fetchStudent(studentId){
    let url=  `http://localhost:9090/api/students/${studentId}`;
    return fetch(url).then(response => response.json());
}

function getTSendMsgTemplate() {
    let url = "http://localhost:9090/messages/sendMessage"; // For now, this is the path but it should be changed!!
    return fetch(url).then(response => response.json());

    function sendMsgForm(event) {

        event.preventDefault();


        let uploadedFileName = req.file.filename;
        let MessageInfo = {
            id: $('#messageId').val,
            senderName: $('#senderName').val,
            receiverName: $('#receiverName').val,
            subject: $('#msgSubject').val(),
            body: $('#messageBody').val(),
            imgURL: `http://localhost:9090/uploads/${uploadedFileName}`,
        };
        console.log("Send Message", MessageInfo);
        console.log('Url of uploaded image', imgURL);
    }


    let url =  "http://localhost:9090/api/messages/sendMessage";
    // let url = "http://localhost:9090/messages/sendMessage.html";

    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(MessageInfo)
    }).then(response => response.json()
        .then(user => {
            window.location = "ParentSlctChildForFollow-up.html";
        })
    ).catch(err=> {
        console.log(err)
    });
}
