'use strict'

//When the document is loaded in the browser then fill the students dropdown.
$(document).ready(function(){
    let user = JSON.parse(localStorage.user);
    console.log("$(document).ready.user", user);
    if (user != 'undefined') {
        $('#username').html(user.username);
    }
    getstudents().then(students => fillStudentsDD(students))
        .catch(err => console.log(err));

    $("#studentsDD").on('change', onStudentChange);
});

function getstudents() {
    let url = "http://localhost:9090/api/students";
    return fetch(url).then(response =>response.json());
}
function getMsg(studentId) {
    let url = `http://localhost:9090/api/msgs/${studentId}`;
    return fetch(url).then(response => response.json());
}

function  fetchTasks(studentId) {
    let url = `http://localhost:9090/api/studentTasks/${studentId}`;
    return fetch(url).then(response => response.json());
}

function onStudentChange() {
    let studentId = $(this).val();
    fetchTasks(studentId).then(tasks => {
        tasks = tasks.filter(t=>t.completedDate);
        let htmlTemplate = $('#studentCompletedTasks-template').html(),
            CompletedTasksTemplate = Handlebars.compile(htmlTemplate);
        $('#completedTasks-list').html(CompletedTasksTemplate({tasks}));
    });
    fetchTasks(studentId).then(tasks => {
        tasks = tasks.filter(t=>!(t.completedDate));
        let htmlTemplate = $('#studentTasks-template').html(),
            TasksTemplate = Handlebars.compile(htmlTemplate);
        $('#studentDetails').html(TasksTemplate({tasks}));
    });

    getMsg(studentId).then(msg => {
        displaymsgs(msg);
    }).catch(err => console.log(err));
}
function fillStudentsDD(students) {
    for(let student of students) {
        $("<option>", {
            value: student.studentId,
            text: student.firstName
        }).appendTo($("#studentsDD"))
    }
}

function displaymsgs(msg) {

    let htmlTemplate = $('#msg-template').html(),
        msgTemplate = Handlebars.compile(htmlTemplate);

    console.log('msgTemplate(msg):', msgTemplate(msg[0]));

    $('#studentmsg').html(msgTemplate(msg[0]));

}