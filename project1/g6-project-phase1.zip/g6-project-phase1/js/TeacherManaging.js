
'use strict'
$(document).ready(function () {

    let user = JSON.parse(localStorage.user);
    console.log("$(document).ready.user", user);
    if (user != 'undefined') {
        $('#username').html(user.username);
    }
    $('#students-list').on('click', 'a.displayButton', ListTasks);
    $('#students-list').on('click', 'a.displayButton', getCompletedTasks);
    $('#students-list').on('click', 'a.addButton', addTask);
    $('#duedate').innerHTML=Date.now();
    $('#students-list').on('click','a.messageButton',messageStudent);
    $('#tasks-list').on   ('click','a.deleteButton',deleteTask);
    $('#tasks-list').on   ('click','a.completeButton',completeTask);
    $('#tasks-list').on   ('click','a.updateButton',updateTask);
    $("#surahDD").on('change', OnSurahIdChange);
    $("#surahDD").on('change', OnSurahNameChange);
    $('#HifzLevel').on('change',OnHifzLevelChange);
    getStudents(user.username);
});

function fetchTeacher(username) {
    let url = `http://localhost:9090/api/teachers/${username}`;
    return fetch(url).then(response => {
        return response.json();
    }).catch(err=>{ console.log(err)});
}
function fetchStudents(teacherId){
    let url=`http://localhost:9090/api/studentsByTeacher/${teacherId}`;
    return fetch(url).then(response => {
        return response.json();
    }).catch(err=> {console.log(err)});
}

function getStudents(username) {
    //Empty the myStudent-details div
    fetchTeacher(username).then(teacher => fetchStudents(teacher.staffNo))
        .then(students=> {
            console.log(students);
            displayStudents(students);
        })
        .catch(err => console.log(err));
}

function displayStudents(students) {
    let htmlTemplate = $('#student-template').html(),
        studentsTemplate = Handlebars.compile(htmlTemplate);
    // console.log("htmlTemplate", htmlTemplate);
    //  console.log("studentsTemplate({students})", studentsTemplate({students}));
    $('#students-list').html(studentsTemplate({students}));
}
function ListTasks(event) {
    //Prevent the default browser behavior when a link is clicked
    event.preventDefault();
    //Get the data-studentId custom attribute associated with the clicked Link
    //Note this refers to the link that was clicked (i.e., the source of the click event)
    var studentId = $(this).attr('data-studentId');
    console.log("listTasks.studentId: ", studentId);
    fetchTasks(studentId).then(tasks => {
        tasks=tasks.filter(t=>!(t.completedDate));
        if(tasks)
        {
            let htmlTemplate = $('#studentTasks-template').html(),
            TasksTemplate = Handlebars.compile(htmlTemplate);
        $('#tasks-list').html( TasksTemplate({tasks}));
        }
        else{
            $('#tasks-list').hidePopup();
        }
}).catch(err => console.log(err));

}
function  fetchTasks(studentId) {
    let url = `http://localhost:9090/api/studentTasks/${studentId}`;
    return fetch(url).then(response => response.json());
}
function fetchTask(taskId) {
    let url = `http://localhost:9090/api/tasks/${taskId}`;
    return fetch(url).then(response => response.json());
}
function getCompletedTasks(event){
    //Prevent the default browser behavior when a link is clicked
    event.preventDefault();
    //Get the data-studentId custom attribute associated with the clicked Link
    //Note this refers to the link that was clicked (i.e., the source of the click event)
    let studentId = $(this).attr('data-studentId');
    console.log("listTasks.studentId: ", studentId);
    fetchTasks(studentId).then(tasks => {
        tasks=tasks.filter(t=>t.completedDate);
        let htmlTemplate = $('#studentCompletedTasks-template').html(),
            CompletedTasksTemplate = Handlebars.compile(htmlTemplate);
        $('#completedTasks-list').html( CompletedTasksTemplate ({tasks}));
    });
}
function completeTask(event){
    //Prevent the default browser behavior when a link is clicked
    event.preventDefault();
    //Get the data-studentId custom attribute associated with the clicked Link
    //Note this refers to the link that was clicked (i.e., the source of the click event)
    let taskId = $(this).attr('data-taskId');
    let studentId=$(this).attr('data-studentId');
    console.log("taskId", taskId);
    fetchTask(taskId).then(task => {
        console.log(task);
        let htmlTemplate = $('#complete-task-template').html(),
            cTaskTemplate = Handlebars.compile(htmlTemplate);
        $('#completeTask-form').html(cTaskTemplate(task));
        console.log("htmlTemplate", htmlTemplate);
        console.log("cTaskTemplate({task})", cTaskTemplate(task));
        showFormAsModel2(studentId);

    });
}
function updateTask(event) {
    //Prevent the default browser behavior when a link is clicked
    event.preventDefault();
    //Get the data-studentId custom attribute associated with the clicked Link
    //Note this refers to the link that was clicked (i.e., the source of the click event)
    let taskId = $(this).attr('data-taskId');
    let studentId=$(this).attr('data-studentId');
    getSurahs().then(Surahs => fillSurahsDD(Surahs))
        .catch(err => console.log(err));
    console.log("taskId", taskId);
    fetchTask(taskId).then(task => {
        console.log(task);

        let htmlTemplate = $('#task-form-template').html(),
            TaskTemplate = Handlebars.compile(htmlTemplate);
        $('#task-form').html(TaskTemplate(task));
        console.log("htmlTemplate", htmlTemplate);
        console.log("taskTemplate({task})", TaskTemplate(task));

        //Select the taskSurahId in the Dropdown
       // $('#surahDD').val(task.surahId);
        showFormAsModel(studentId);
    }).catch(err => console.log(err));
}
function addTask(event) {
    //Prevent the default browser behavior when a link is clicked
    event.preventDefault();
    //Get the data-studentId custom attribute associated with the clicked Link
    //Note this refers to the link that was clicked (i.e., the source of the click event)
    let studentId = $(this).attr('data-studentId');
    // let id=$('#studentId').val();
    getSurahs().then(Surahs => fillSurahsDD(Surahs))
        .catch(err => console.log(err));
    let htmlTemplate = $('#task-form-template').html(),
        TaskTemplate = Handlebars.compile(htmlTemplate);

    $('#task-form').html(TaskTemplate({}));
    showFormAsModel(studentId);
}
function showFormAsModel(studentId) {
    let taskForm = $( "#task-form" ).dialog({
        height: 450,
        width: 750,
        title: 'Task Form',
        modal: true,
        buttons: {
            "Submit": function() {
                saveTask(studentId);
                taskForm.dialog( "close" );
            },
            Cancel: function() {
                taskForm.dialog( "close" );
            }
        }
    });
}
function showFormAsModel2(studentId) {
    let taskForm = $( "#completeTask-form" ).dialog({
        height: 550,
        width: 750,
        title: 'Complete Task Form',
        modal: true,
        buttons: {
            "Submit": function() {
                saveCompleteTask(studentId);
                taskForm.dialog( "close" );
            },
            Cancel: function() {
                taskForm.dialog( "close" );
            }
        }
    });
}
function OnSurahIdChange() {
    var selectedSurahId;
    selectedSurahId = $('#surahDD').val();
    console.log(selectedSurahId);
    getSurah(selectedSurahId).then(surah=>
    {
        $('#to').attr('min',2);
        console.log($('#to').attr('min'));
        console.log(surah.ayaCount);
       $('#to').attr('max',surah.ayaCount);
       console.log($('#to').attr('max'));
    }
    ).catch(err=>console.log(err));
    return selectedSurahId;
}
function OnSurahNameChange() {
    var selectedElement;
    selectedElement = $('#surahDD option:selected').text();
    console.log(selectedElement);
    return selectedElement;
}
function OnHifzLevelChange() {
    var selectedLevel;
    selectedLevel = $('#HifzLevel option:selected').val();
    console.log(selectedLevel);
    return selectedLevel;
}
function saveTask(studentId) {
    let taskId = $('#taskId').val();
    let from=$('#from').val();
    let to=$('#to').val();
    let task = {};
    task.studentId=parseInt(studentId);
    task.surahId= OnSurahIdChange() ;
    task.surahName=OnSurahNameChange() ;
    task.fromAya=parseInt(from);
    task.toAya=parseInt(to);
    task.type=$("input[name='type']:checked").val();
    task.dueDate=$('#dueDate').val();
//    console.log(task.type);
    let url = "http://localhost:9090/api/tasks/";
    let requestMethod = "post";

    //In case of update make the method put and append the id to the Url
    if (taskId != '') {
        task.taskId = parseInt(taskId);
        url += taskId;
        requestMethod = "put";
    }

    console.log("saveTask.taskId", taskId);

    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(task)
    }).then(() => {
        //After add/update then refresh the list
        //   ListTasks();
    });
}
function saveCompleteTask(studentId) {
    let taskId = $('#tId').val();
    let task = {};
    task.studentId=parseInt(studentId);
    task.surahId= parseInt($('#surahId').val()) ;
    task.surahName=$('#surahName').val() ;
    task.fromAya=parseInt($('#fromAya').val());
    task.toAya=parseInt($('#toAya').val());
    task.type=$('#type').val();
    task.dueDate=$('#due').val();
    task.completedDate=$('#completeDate').val();
    task.masteryLevel=OnHifzLevelChange();
    task.comment=$('#comment').val();
    let url = "http://localhost:9090/api/tasks/";
    let requestMethod;

    //In case of update make the method put and append the id to the Url
    if (taskId != '') {
        task.taskId = parseInt(taskId);
        url += taskId;
        requestMethod = "put";
    }

    console.log("saveCompletedTask.taskId", taskId);
    console.log(task);
    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(task)
    }).then(() => {
        //After add/update then refresh the list
        //  ListTasks();
    });
}

function deleteTask(event) {
    //Prevent the default browser behavior when a link is clicked
    event.preventDefault();

    // Ask the user to confirm. If they cancel the request then exit this function
    if (!confirm('Confirm delete?')) {
        return;
    }

    //Get the data-taskId custom attribute associated with the clicked Link
    //Note this refers to the link that was clicked (i.e., the source of the click event)
    let taskId = $(this).attr('data-taskId');
    console.log("deleteTask.TaskId: ", taskId);

    let url = `http://localhost:9090/api/tasks/${taskId}`;
    console.log("deleteTask.taskId", taskId);
    fetch(url, {method: 'delete'}).then(() => {
        //After successful delete remove the row from the HTML table
        $(this).closest('tr').remove();
    }).then(() => {
        //After delete then refresh the list
    });
}
function messageStudent(event){
    event.preventDefault();
    var studentId = $(this).attr('data-studentId');
    let studentInfo = {
        studentId: studentId,
    }; 
    localStorage.studentInfo = JSON.stringify(studentInfo);
    window.location ="http://localhost:9090/sendMessage.html";
}
function getSurahs() {
    let url = "http://localhost:9090/api/surahs";
    return fetch(url).then(response => response.json());
}
function getSurah(id) {
    let url = `http://localhost:9090/api/surahs/${id}`;
    return fetch(url).then(response => response.json());
}
function fillSurahsDD(surahs) {
    for(let surah of surahs) {
        $("<option>", {
            value: surah.id,
            text: surah.englishName
        }).appendTo($('#surahDD'))
    }
}