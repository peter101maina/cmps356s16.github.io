
'use strict'
$(document).ready(function () {
    $('#register').on('click', submitForm);
    $('#addChiled').on('click','a.addButton', addAnotherChiled);
    //$('#students-list').on('click', 'a.addButton', addTask);
});
function submitForm(event) {
    event.preventDefault();

    let qatariId = $('#qatarId').val();
    let sGrade=$('#cgrade').val();
    let teacherId=$('#halaqaDD').val();
    let sGrade2=$('#c2grade').val();
    let teacherId2=$('#halaqaDD').val();

    let registerInfo = {
        qatariId: parseInt(qatariId),
        firstName: $('#first').val(),
        lastName: $('#last').val(),
        mobile: $('#mobile').val(),
        email: $('#email').val(),
        username: $('#user').val(),
        password: $('#pwd').val(),
        countries: $('#countries option:selected').text(),

        students:[
            {
                firstName: $('#cfirst').val(),
                lastName: $('#clast').val(),
                dob: $('#cdateOfBirth').val(),
                gender: $('#gender').val(),
                schoolGrade: parseInt(sGrade),
                teacherId:parseInt(teacherId),
            },
            {
                firstName: $('#c2first').val(),
                lastName: $('#c2last').val(),
                dob: $('#c2dateOfBirth').val(),
                schoolGrade: parseInt(sGrade2),
                teacherId:parseInt(teacherId2),
            }

        ]

    };
    registerInfo.students[0].gender= $("input[name='cgender']:checked").val();
    registerInfo.students[0].studentId= 7;
    registerInfo.students[1].gender= $("input[name='cgender']:checked").val();
    registerInfo.students[1].studentId= 8;
    alert("Registration Completed !");
   // console.log("submitForm.registerInfo", registerInfo);

    let url = "http://localhost:9090/api/parents/";
    let requestMethod = "post";

    //let username = $('#user').val();

    //In case of update make the method put and append the id to the Url
   /* if (username == '') {
        registerInfo.username = username;
        url += username;
        requestMethod = "put";
    }*/
    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(registerInfo)
    }).then(() => {
        //After add/update then refresh the list
        //  ListTasks();
    });
}

function addAnotherChiled(event) {
    let htmlTemplate = $('#addChiled-form-template').html(),
        chiledTemplate = Handlebars.compile(htmlTemplate);

    $('#chiled-form').html(chiledTemplate({}));

}


