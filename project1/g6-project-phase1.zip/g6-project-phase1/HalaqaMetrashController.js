/**
 * Created by Nour Moslem on 22/04/2016.
 */
'use strict'
class HalaqaMetrashController {
    constructor() {
        this.halaqaMetrashRepository = require('./HalaqaMetrashRepository');
    }
    getTasks(req, res) {
        this.halaqaMetrashRepository.getTasks().then(tasks => {
            res.json(tasks);
        });
    }

    getTask (req, res) {
        let taskId = req.params.id;
        console.log('req.params.id', taskId);
        this.halaqaMetrashRepository.getTask(parseInt(taskId)).then(task => {
            console.log(JSON.stringify(task, null, 2));
            res.json(task);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }
    getStudentTasks(req, res) {
        let studentId = req.params.id;
        console.log('req.params.id', studentId);
        this.halaqaMetrashRepository.getStudentTasks(parseInt(studentId)).then(task => {
            console.log(JSON.stringify(task, null, 2));
            res.json(task);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    addTask(req, res) {
    let task = req.body;

    this.halaqaMetrashRepository.addTask(task).then((task)=> {
        let urlOfNewTask = `/api/tasks/${task.taskId}`;
        res.location(urlOfNewTask)
        res.status(201).send(`Created and available @ ${urlOfNewTask}`);
    }).catch(err => res.status(500).send(err));
}

    addStudent(req, res) {
        let student = req.body;

        this.halaqaMetrashRepository.addStudent(student).then((student)=> {
           // let urlOfNewTask = `/api/students/${student.studentId}`;
            let urlOfNewTask = `/api/students/${student.studentId}`;
            res.location(urlOfNewTask)
            res.status(201).send(`Created and available @ ${urlOfNewTask}`);
        }).catch(err => res.status(500).send(err));
    }

    updateTask(req, res) {
        let task = req.body;

        this.halaqaMetrashRepository.updateTask(task).then(() => {
            res.status(200).send("Task updated successfully");
        }).catch(err => {
            console.log(err);
            res.status(500).send(err);
        });
    }

    deleteTask(req, res) {
        let taskId = req.params.id;

        this.halaqaMetrashRepository.deleteTask(taskId).then(() => {
            res.status(200).send("Task deleted");
        }).catch(err => {
            res.status(500).send(err);
        });
    }
    getTeacher(req,res){
        let teacher= req.params.id;
        console.log('req.params.id',teacher);
        this.halaqaMetrashRepository.getTeacher(teacher).then(teacher => {
            console.log(teacher);
            res.json(teacher);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }
    getStudents(req,res){
        this.halaqaMetrashRepository.getStudents().then(students => {
            res.json(students);
        });
    }
    getStudent(req,res){
        let studentId = req.params.id;
        console.log('req.params.id', studentId);
        this.halaqaMetrashRepository.getStudent(parseInt(studentId)).then(student => {
            console.log(JSON.stringify(student, null, 2));
            res.json(student);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    updateStudent(req, res) {
        let student = req.body;

        this.halaqaMetrashRepository.updateStudent(student).then(() => {
            res.status(200).send("student updated successfully");
        }).catch(err => {
            console.log(err);
            res.status(500).send(err);
        });
    }

    getStudentsByParent(req,res){
        let lastName =req.params.id;
        console.log('req.params.id',lastName);
        this.halaqaMetrashRepository.getStudentsByParent(lastName).then(students => {
            console.log(JSON.stringify(students, null, 2));
            res.json(students);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }
    getParents(req,res){
        this.halaqaMetrashRepository.getParents().then(parents => {
            res.json(parents);
        });
    }

    getParent(req,res){
        let parent= req.params.id;
        console.log('req.params.id',parent);
        this.halaqaMetrashRepository.getParent(parent).then(parent => {
            console.log(parent);
            res.json(parent);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }
    getStudentByteacherId(req,res){
        let teacherId =req.params.id;
        console.log('req.params.id',teacherId);
        this.halaqaMetrashRepository.getStudentByteacherId(parseInt(teacherId)).then(students => {
            console.log(JSON.stringify(students, null, 2));
            res.json(students);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }
    addParent(req, res) {
        let parent = req.body;

        this.halaqaMetrashRepository.addParent(parent).then((parent)=> {
            let urlOfNewTask = `/api/parents/${parent.qatariId}`;
            res.location(urlOfNewTask)
            res.status(201).send(`Created and available @ ${urlOfNewTask}`);
        }).catch(err => res.status(500).send(err));
    }
    getSurahs(req, res) {
        this.halaqaMetrashRepository.getSurahs().then(surahs => {
            res.json(surahs);
        });
    }
    getSurah(req, res) {
        let surahId = req.params.id;
        console.log('req.params.id', surahId);
        this.halaqaMetrashRepository.getSurah(parseInt(surahId)).then(surah => {
            console.log(JSON.stringify(surah, null, 2));
            res.json(surah);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }
    getMsgs(req, res) {
        this.halaqaMetrashRepository.getMsgs().then(msgs => {
            res.json(msgs);
        });
    }

    getMsg (req, res) {
        let msgsId = req.params.id;
        console.log('req.params.id', msgsId);
                this.halaqaMetrashRepository.getMsg(parseInt(msgsId)).then(msg => {
            console.log(JSON.stringify(msg, null, 2));
            res.json(msg);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }
    getStudentMsgs(req, res) {
        let studentId = req.params.id;
        console.log('req.params.id', studentId);
        this.halaqaMetrashRepository.getStudentMsgs(parseInt(studentId)).then(msg => {
            console.log(JSON.stringify(msg, null, 2));
            res.json(msg);
        }).catch(err => {
            res.status(404).send("Failed :" + err);
        });
    }

    getAnnouncements (req, res) {
        this.halaqaMetrashRepository.getAnnouncements().then(announc => {
            res.json(announc);
        });
    }

}

module.exports = new HalaqaMetrashController();