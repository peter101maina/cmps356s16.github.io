/**
 * Created by root on 4/20/16.
 */
'use strict';
class TeacherRepository{
    constructor() {
        this.fs = require('fs');
    }

    //Read file and convert its content to  json object
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else
                    resolve();

            });
        });
    }

    getTeachers(){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/teacher.json').then(teachers => {
                resolve(teachers);
            }).catch(err => {
                reject(err);
            });
        });
    }
    loginTeacher(username,password) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/teacher.json').then(teachers => {
                teachers = teachers.filter(t => t.username === username);
                if (teachers.length > 0) {
                    let teacher=teachers[0];
                    if(teacher.password===password){
                        delete teacher.password;
                        resolve(teacher);
                    }
                    else{
                        reject('Invalid Password');
                    }
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    
    getCordinators() {
        return new Promise((resolve, reject) => {
            this.getTeachers().then(cordinators => {
                cordinators = cordinators.filter(t => t.hasOwnProperty("isCoordinator"));
                resolve(cordinators);
            });
        });
    }
    fetchTeacher(username){
        return new Promise((resolve, reject) => {
            this.getTeachers().then(teachers => {
                teachers = teachers.filter(t => t.username == username);
                if(teachers.length > 0)
                    resolve(teachers[0]);
                else
                    reject("not found");
            });
        });
    }
    fetchTeacherInfo(id){
        return new Promise((resolve, reject) => {
            this.getTeachers().then(teachers => {
                teachers = teachers.filter(t => t.staffNo == id);
                if(teachers.length > 0)
                    resolve(teachers[0]);
                else
                    reject("not found");
            });
        });
    }
    fetchCoordinator(username){
        return new Promise((resolve, reject) => {
            this.getCordinators().then(cordinators => {
                cordinators = cordinators.filter(c => c.username == username);
                if(cordinators.length > 0)
                    resolve(cordinators[0]);
                else 
                    reject("not found");
            });
        });
    }
}
module.exports = new TeacherRepository();