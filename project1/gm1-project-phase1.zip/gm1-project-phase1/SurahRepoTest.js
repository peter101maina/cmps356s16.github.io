/**
 * Created by root on 4/20/16.
 */
"use strict";
let requestRepository = require("./SurahRepository");
/*requestRepository.getSurahs().then(surahs => {
    console.log(surahs);
});*/
requestRepository.getSurah(1).then(surah=>console.log(surah)).catch(err=>console.log(err));