/**
 * Created by root on 4/20/16.
 */
"use strict";
let taskRepository = require("./TaskRepository");
/*taskRepository.getTasks().then(tasks => {
    console.log(tasks);
});*/
taskRepository.getTaskById(1).then(tasks => {
    console.log(tasks);
});
