/**
 * Created by root on 4/24/16.
 */
'use strict';
class HalaqaRepository{
    constructor() {
        this.fs = require('fs');
    }

    //Read a file and convert its content to a json object
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }

    getHalaqas(){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/halaqa.json').then(halaqas => {
                resolve(halaqas);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getHalaqaByInstructor(staffNo){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/halaqa.json').then(h=>{
                h=h.filter(ha=>ha.staffNo===staffNo);
                if(h.length>0){
                    resolve(h[0]);
                }
                else
                    reject('Not Found');
            });
        });
    }
    getHalaqaById(id){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/halaqa.json').then(h=>{
                h=h.filter(ha=>ha.halaqaID==id);
                if(h.length>0){
                    resolve(h[0]);
                }
                else
                    reject('Not Found');
            });
        });
    }
    assginToHalqa(halaqaId,studentId)
    {
        return new Promise((resolve, reject) => {
            this.getHalaqas().then(halaqas => {
                for(let halaqa of halaqas)
                {
                    //console.log(halaqa);
                    if(halaqa.halaqaID == halaqaId) 
                       halaqa.students.push(studentId);
                }
               return this.writeJsonFile('./res/json/halaqa.json', halaqas);
            }).then(() => {
                resolve();
            }).catch(err => {
                console.log(err);
                reject(err);
            });
        });
        
    }
}
module.exports = new HalaqaRepository();