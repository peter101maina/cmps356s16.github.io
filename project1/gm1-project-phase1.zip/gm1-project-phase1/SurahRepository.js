/**
 * Created by root on 4/20/16.
 */
'use strict';
class SurahRepository{
    constructor() {
        this.fs = require('fs');
    }

    //Read a file and convert its content to a json object
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }

    getSurahs(){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/surah.json').then(surahs => {
                resolve(surahs);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getSurah(id){
        return new Promise((resolve, reject) => {
            this.getSurahs().then(surahs=>{
                surahs=surahs.filter(s=>s.id==id);
                if(surahs.length>0){
                    resolve(surahs[0]);
                }
                else{
                    reject('Surah not found');
                }
            }).catch(err=>{
                reject(err);
            })
        })
    }
}
module.exports = new SurahRepository();