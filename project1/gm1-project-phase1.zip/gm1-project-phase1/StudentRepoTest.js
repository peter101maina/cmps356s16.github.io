/**
 * Created by root on 4/23/16.
 */
'use strict';
let studentRepository = require("./StudentRepository");
/*studentRepository.loginStudent('juha','password').then(teacher=>{
    console.log(teacher)
}).catch(error=>{
    console.log(error)
});
studentRepository.getStudents().then(teachers => {
    console.log(teachers);
});*/
//studentRepository.fetchStudent('juha').then(s=>console.log(s));
//studentRepository.getAllStudents().then(s=>{console.log(s)});
//studentRepository.getAllParents().then(parents =>{console.log(parents)});

//studentRepository.fetchParent(12).then(h => console.log(h));
studentRepository.getSomeStudents([1,3,5]).then(s=>console.log(s));