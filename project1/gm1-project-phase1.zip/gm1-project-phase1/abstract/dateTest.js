/**
 * Created by root on 4/24/16.
 */
console.log(new Date().toJSON());