/**
 * Created by Willowe on 4/24/2016.
 */


'use strict'


function readURL(e) {
    if (this.files && this.files[0]) {
        var reader = new FileReader();
        $(reader).load(function(e) { $('#blah').attr('src', e.target.result); });
        reader.readAsDataURL(this.files[0]);
    }
}

$("#imgInp").change(readURL);

function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            document.getElementById('blah').src =  e.target.result;
        }

        reader.readAsDataURL(input.files[0]);
    }
}
/*
And the HTML:

    <input type='file' id="imgInp" onchange="readURL(this);" />
    <img id="blah" src="#" alt="your image" />


    */