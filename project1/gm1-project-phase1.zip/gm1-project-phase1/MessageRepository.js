

/**
 * Created by Willowe
 */


'use strict';

class MessageRepository {
    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }


    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else
                    resolve();

            });
        });
    }
    getMessages(){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/message.json').then(msg => {
                resolve(msg);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getMessagesByStudentId(id)
    {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/message.json').then(messages => {
                messages = messages.filter(s => s.studentId == id);
                if (messages.length > 0) {
                    resolve(messages);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getMessagesById(id)
    {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/message.json').then(messages => {
                messages = messages.filter(s => s.messageId == id);
                if (messages.length > 0) {
                    resolve(messages[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    addMessage(url ,message){
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                let maxId = Math.max.apply(Math, messages.map(h => h.messageId)) + 1;
                console.log("maxId", maxId);
                message.messageId = maxId;
                message.attachment = url;
                message.timeStamp = new Date();
                message.studentId=parseInt(message.studentId);
                message.instructorId=parseInt(message.instructorId);
                messages.push(message);
                return this.writeJsonFile('./res/json/message.json', messages);
            }).then(()=> resolve(message))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
}//end of class

module.exports = new MessageRepository();