/**
 * Created by root on 4/20/16.
 */


'use strict';
class StudentRepository{
    constructor(){
        let halaqaRepository = require("./HalaqaRepository");
        this.fs = require('fs');
    }
    //Read a file and convert its content to a json object
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }

    getStudents(){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/student.json').then(students => {
                resolve(students);
            }).catch(err => {
                reject(err);
            });
        });
    }
    loginStudent(username, password) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/student.json').then(students => {
                students = students.filter(s => s.username === username);
                if (students.length > 0) {
                    let student=students[0];
                    if(student.password===password){
                        delete student.password;
                        resolve(student);
                    }
                    else{
                        reject('Invalid Password');
                    }
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    fetchStudent(username) {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/student.json').then(students => {
                students = students.filter(s => s.username === username);
                if (students.length > 0) {
                    let student=students[0];
                    delete student.password;
                    resolve(student);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getAllStudents(){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/student.json').then(students => {
                let studentArrays = students.map(s=>{
                    return s.students;
                });
                let allStudents = [];
                for(let i=0; i<studentArrays.length; i++){
                    allStudents = allStudents.concat(studentArrays[i]);
                }
                resolve(allStudents);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getSomeStudents(students){
        return new Promise((resolve, reject) => {
            this.getAllStudents().then(s=>{
                s=s.filter(st=>{
                   for(let stu of students){
                       if(stu==st.studentId){
                           return st;
                       }
                   }
                });
                resolve(s);
            }).catch(err=>reject(err));
        });
    }
    getAllParents(){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/student.json').then(parents => {
                for(let i=0; i<parents.length; i++){
                    delete parents[i].students;
                    delete parents[i].password;
                }
                resolve(parents);
            }).catch(err => {
                reject(err);
            });
        });
    }
    addParent(parent){
        return new Promise((resolve, reject) => {
            this.getStudents().then(parents => {
                parents.push(parent);
                return this.writeJsonFile('./res/json/student.json', parents);
            }).then(() => {
                resolve(parent);
            }).catch(err => {
                    console.log(err);
                    reject(err);
            });
        });
    }

    addStudent(student){
        return new Promise((resolve, reject) => {
      
            this.getAllStudents().then(studentCount =>
            {
                let maxId = Math.max.apply(Math, studentCount.map(h => h.studentId)) + 1;
                student.studentId = maxId;
                delete  student.halaqa;
            }).then(s => this.getStudents()).then(parents =>
                {
                    let parentId = student.parentId;
                    delete  student.parentId;
                    for(let parent of parents)
                    {
                        if(parent.qatariId == parentId)
                        {
                            parent.students.push(student);
                            console.log(parent.students);
                        }
                    }
                    return this.writeJsonFile('./res/json/student.json', parents);
            }).then(() => {
                resolve(student);
            }).catch(err => {
                console.log(err);
                reject(err);
            });
        });
    }
}
module.exports = new StudentRepository();