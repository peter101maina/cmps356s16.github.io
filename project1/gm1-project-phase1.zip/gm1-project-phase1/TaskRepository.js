/**
 * Created by root on 4/23/16.
 */
'use strict';
class TaskRepository{
    constructor() {
        this.fs = require('fs');
    }

    //Read a file and convert its content to a json object
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }

    getTasks(){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/task.json').then(tasks => {
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getTaskById(taskId){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/task.json').then(tasks => {
                tasks = tasks.filter(t => t.taskId === taskId);
                if (tasks.length > 0) {
                    tasks=tasks[0];
                    resolve(tasks);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getTaskByStudentId(studentId){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/task.json').then(tasks => {
                tasks = tasks.filter(t => t.studentId === studentId);
                if (tasks.length > 0) {
                    resolve(tasks);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    deleteTask(taskId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let len = tasks.length;
                let foundAt = -1;
                for (let i = 0; i < len; i++) {
                    if (tasks[i].taskId == taskId) {
                        foundAt = i;
                        break;
                    }
                }
                if (foundAt >= 0) {
                    tasks.splice(foundAt, 1);
                }
                console.log("appjs.deleteTask", foundAt);
                return this.writeJsonFile('./res/json/task.json', tasks);
            }).then(() => {
                resolve();
            }).catch(err => {
                console.log(err);
                reject(err);
            });
        });
    }
    updateTask(task) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let len = tasks.length;
                for(let i=0; i<len; i++){
                    if (tasks[i].taskId == task.taskId) {
                        tasks[i] = task;
                        break;
                    }
                }
                return this.writeJsonFile('./res/json/task.json', tasks);
            }).then(()=> resolve())
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
    addTask(task) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                //Get the last Id used +1
                let maxId = Math.max.apply(Math, tasks.map(t => t.taskId)) + 1;
                console.log("maxId", maxId);

                task.taskId = maxId;
                console.log("heroController.addTask", task);
                tasks.push(task);
                return this.writeJsonFile('./res/json/task.json', tasks);
            }).then(()=> resolve(task))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
}
module.exports = new TaskRepository();