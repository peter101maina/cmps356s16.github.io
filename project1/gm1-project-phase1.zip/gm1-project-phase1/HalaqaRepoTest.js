/**
 * Created by root on 4/24/16.
 */
'use strict';
let halaqaRepository = require("./HalaqaRepository");
/*halaqaRepository.getHalaqas().then(halaqas => {
    console.log(halaqas);
});*/
//halaqaRepository.getHalaqaByInstructor(503).then(h=>{console.log(h)}).catch(e=>{console.log(e)});

halaqaRepository.getHalaqaById(2).then(h=>console.log(h));
