/**
 * Created by root on 4/24/16.
 */
'use strict';
$(document).ready(function(){
    let user = JSON.parse(localStorage.user);
    console.log("$(document).ready.user", user);
    getTeacher(user);
    $('#student-data').hide();
    $('#taskSelectForm').hide();
    $('#studentList').change(fetchTasks);
    $('#taskSelectForm').change(function(){
        $('#student-data').show();
        switch($("input:radio[name ='taskType']:checked").val()){
            case 'pending':
                $('#pendingTable').show();
                $('#completeTable').hide();
                break;
            case 'complete':
                $('#pendingTable').hide();
                $('#completeTable').show();
        }
    });
    $('#messages').on('submit',e=>e.preventDefault());
    $('#logout').click(function(){
        localStorage.clear();
    });
});
function sendMessage(){
    console.log(localStorage.instructorId,$('#studentList').val());
    let htmlTemplate = $('#message-form-template').html(),
        messageTemplate = Handlebars.compile(htmlTemplate);
    $('#message-form').html(messageTemplate({}));
    $('#studentId').hide();
    $('#instructorId').hide();
    $('#studentId').val(parseInt($('#studentList').val()));
    $('#instructorId').val(parseInt(localStorage.instructorId));
    showFormAsModelMessage();
}
function showFormAsModelMessage(){
    let messageForm = $('#message-form').dialog({
        height: 580,
        width: 750,
        title: 'Message form',
        modal: true,
        buttons:{
            "Cancel": function() {
                messageForm.dialog( "close" );
            }
        }
    });
}
function deleteTask(taskIdp) {
    // Ask the user to confirm. If they cancel the request then exit this function
    if (!confirm('Confirm delete?')) {
        return;
    }

    //Get the data-heroId custom attribute associated with the clicked Link
    //Note this refers to the link that was clicked (i.e., the source of the click event)
    let taskId = taskIdp;
    console.log("deleteTask.taskId: ", taskId);

    let url = `http://localhost:9090/api/tasks/${taskId}`;
    console.log("deleteHero.heroId", taskId);
    fetch(url, {method: 'delete'}).then(() => {
        //After successful delete remove the row from the HTML table
        $(this).closest('tr').remove();
    }).then(() => {
        //After delete then refresh the list
        fetchTasks();
    });
}
function getTeacher(user){
    let url = 'http://localhost:9090/api/teachers/' + user.username;
    fetch(url).then(t=>t.json()).then(t=>{
        $('#userFullname').html(t.firstName+' '+t.lastName);
        localStorage.instructorId=t.staffNo;
        getHalaqa(t);
    });
}
function getHalaqa(teacher){
    let url = 'http://localhost:9090/api/halaqas/teacher/' + teacher.staffNo;
    fetch(url).then(h=>h.json()).then(h=>{
        getAllHalaqaStudents(h);
    });
}
function getAllHalaqaStudents(halaqa){
    let url = 'http://localhost:9090/api/halaqastudents';
    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(halaqa.students)
    }).then(response => response.json())
        .then(students => {
            console.log(students);
            let studentList = $("#studentList");
            $.each(students, function() {
                studentList.append($("<option />").val(this.studentId).text(this.studentId+' - '+this.firstName+' '+this.lastName));
            });
        });
}
function fetchTasks(){
    let selId = $('#studentList').val();
    if(!isNaN(parseInt(selId))){
        $('#taskSelectForm').show();
        $("input[name='taskType'][value='pending']").prop("checked",true);
        $('#pendingTable').show();
        $('#completeTable').hide();
        $('#student-data').show();
        console.log(parseInt(selId));
        displayTasks(selId);
    }
    else{
        $('#student-data').hide();
        $('#taskSelectForm').hide();
        $('input[name="taskType"]').prop('checked', false);
    }
}
function displayTasks(studentId){
    let studentInfo = {
        id: studentId
    };
    let url = 'http://localhost:9090/api/tasklist'
    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(studentInfo)
    }).then(response => response.json())
        .then(tasks => {
            console.log(tasks);
            populatePending(tasks);
            populateComplete(tasks);
        }).catch(function(){
        $('#pending-table tbody').empty();
        $('#complete-table tbody').empty();
    });
}
function populatePending(tasks){
    tasks=tasks.filter(t=>!t.hasOwnProperty('completedDate'));
    let htmlTemplate = $('#tasks-template').html(),
        tasksTemplate = Handlebars.compile(htmlTemplate)
    $('#pending-table').html(tasksTemplate({tasks}));
}
function populateComplete(tasks){
    tasks=tasks.filter(t=>t.hasOwnProperty('completedDate'));
    let htmlTemplate = $('#tasks-template').html(),
        tasksTemplate = Handlebars.compile(htmlTemplate)
    $('#complete-table').html(tasksTemplate({tasks}));
}
function completeTask(taskId) {
    let htmlTemplate = $('#complete-task-template').html(),
        completeTaskTemplate = Handlebars.compile(htmlTemplate);
    $('#complete-task-form').html(completeTaskTemplate({}));
    showFormAsModel(taskId);
}
function showFormAsModel(taskId){
    document.getElementById('completeDate').valueAsDate = new Date();
    let completeTaskForm = $('#complete-task-form').dialog({
        height: 400,
        width: 750,
        title: 'Complete Task Form',
        modal: true,
        buttons:{
            "Submit": function() {
                getTask(taskId).then(task=>{
                    let date=$('#completeDate').val().toString().split('-');
                    task.completedDate=date[2]+'/'+date[1]+'/'+date[0];
                    task.masteryLevel=$('#masteryLevel').val();
                    task.comment=$('#comment').val();
                    console.log(task);
                    saveTask(task);
                });
                completeTaskForm.dialog( "close" );
            },
            "Cancel": function() {
                completeTaskForm.dialog( "close" );
            }
        }
    });
}
function getTask(taskId){
    let url = 'http://localhost:9090/api/tasks/'+taskId;
    return fetch(url).then(task=>task.json());
}
function getSurahs(){
    let url = 'http://localhost:9090/api/surahs/';
    return fetch(url).then(surahs=>surahs.json());
}
function updateTask(taskId) {
    getSurahs().then(surahs=>{
        let htmlTemplate = $('#update-task-template').html(),
            completeTaskTemplate = Handlebars.compile(htmlTemplate);
        $('#update-task-form').html(completeTaskTemplate({surahs}));
        $('#fromAya').change(function(){
            $('#fromAyaCountShow').html($(this).val());
            if($('#toAya').val()<$(this).val()){
                $('#toAya').val($(this).val());
                $('#toAyaCountShow').html($(this).val());
            }
        });
        $('#toAya').change(function(){
            $('#toAyaCountShow').html($(this).val());
            if($('#fromAya').val()>$(this).val()){
                $('#fromAya').val($(this).val());
                $('#fromAyaCountShow').html($(this).val());
            }
        });
        $('#surah').change(function(){
            let maxCount = surahs[parseInt($(this).val())-1].ayaCount;
            $('#toAya').prop('max', maxCount);
            $('#fromAya').prop('max', maxCount);
            $('#fromAyaCountShow').html($('#fromAya').val());
            $('#toAyaCountShow').html($('#toAya').val());
        })
        showUpdateFormAsModel(taskId);
    });
}
function showUpdateFormAsModel(taskId){
    let date = new Date();
    date.setDate(date.getDate() + 1);
    document.getElementById('dueDate').valueAsDate = date;
    let completeTaskForm = $('#update-task-form').dialog({
        height: 500,
        width: 750,
        title: 'Update Task Form',
        modal: true,
        buttons:{
            "Submit": function() {
                getTask(taskId).then(task=>{
                    let date=$('#dueDate').val().toString().split('-');
                    task.dueDate=date[2]+'/'+date[1]+'/'+date[0];
                    task.fromAya=parseInt($('#fromAya').val());
                    task.toAya=parseInt($('#toAya').val());
                    task.type=$('#type').val();
                    task.surahId=parseInt($('#surah').val().toString().split('/')[0]);
                    task.surahName=$('#surah').val().toString().split('/')[1];
                    console.log(task);
                    saveTask(task);
                });
                completeTaskForm.dialog( "close" );
            },
            "Cancel": function() {
                completeTaskForm.dialog( "close" );
            }
        }
    });
}
function addTask(){
    getSurahs().then(surahs=>{
        let htmlTemplate = $('#update-task-template').html(),
            completeTaskTemplate = Handlebars.compile(htmlTemplate);
        $('#update-task-form').html(completeTaskTemplate({surahs}));
        $('#fromAya').change(function(){
            $('#fromAyaCountShow').html($(this).val());
            if($('#toAya').val()<$(this).val()){
                $('#toAya').val($(this).val());
                $('#toAyaCountShow').html($(this).val());
            }
        });
        $('#toAya').change(function(){
            $('#toAyaCountShow').html($(this).val());
            if($('#fromAya').val()>$(this).val()){
                $('#fromAya').val($(this).val());
                $('#fromAyaCountShow').html($(this).val());
            }
        });
        $('#surah').change(function(){
            let maxCount = surahs[parseInt($(this).val())-1].ayaCount;
            $('#toAya').prop('max', maxCount);
            $('#fromAya').prop('max', maxCount);
            $('#fromAyaCountShow').html($('#fromAya').val());
            $('#toAyaCountShow').html($('#toAya').val());
        })
        showAddFormAsModel();
    });
}
function showAddFormAsModel(){
    let date = new Date();
    date.setDate(date.getDate() + 1);
    document.getElementById('dueDate').valueAsDate = date;
    let completeTaskForm = $('#update-task-form').dialog({
        height: 500,
        width: 750,
        title: 'Add Task Form',
        modal: true,
        buttons:{
            "Submit": function() {
                let date=$('#dueDate').val().toString().split('-');
                let task={
                    dueDate: date[2]+'/'+date[1]+'/'+date[0],
                    fromAya: parseInt($('#fromAya').val()),
                    toAya: parseInt($('#toAya').val()),
                    type: $('#type').val(),
                    surahId: parseInt($('#surah').val().toString().split('/')[0]),
                    surahName: $('#surah').val().toString().split('/')[1],
                    studentId: parseInt($('#studentList').val())
                }
                console.log(task);
                saveTask(task);
                completeTaskForm.dialog( "close" );
            },
            "Cancel": function() {
                completeTaskForm.dialog( "close" );
            }
        }
    });
}
function saveTask(task) {
    let url = "http://localhost:9090/api/tasks/",
        requestMethod='post';
    if(task.hasOwnProperty('taskId')){
        requestMethod = "put";
        url=url+task.taskId;
        console.log("saveCompleteTask.taskId", task.taskId);
    }
    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(task)
    }).then(() => {
        //After add/update then refresh the list
        fetchTasks();
    });
}