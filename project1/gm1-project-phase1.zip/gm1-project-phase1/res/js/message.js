/**
 * Created by Willowe
 */
'use strict';

$(document).ready(function(){
    getParent().then(parents => fillParentsList(parents))
        .catch(err => console.log(err));

    $("#parent").on('change', onParentChange);
});


function getParent() {
    let url = `http://localhost:9090/api/studentsOnly/`;
    return fetch(url).then(response => response.json());
}

function onParentChange() {
    let pID = $(this).val();

    getParent().then(parent => {
        displayParent(parent);
    }).catch(err => console.log(err));
}

function fillParentsList(parents) {
    for (let parent of parents) {

        $("<option>", {
            value: parent.qatariId,
            text: parent.firstName,


        }).appendTo($("#parent"))
        
    }
}

function displayParent(parents){
    let htmlTemplate = $('#message-template').html(),
        msgTemplate = Handlebars.compile(htmlTemplate);

    $('#parent').html(msgTemplate({parents}));
}