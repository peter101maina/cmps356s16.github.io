/**
 * Created by root on 4/23/16.
 */

'use strict';
$(document).ready(function ()
{
    let user = JSON.parse(localStorage.user);
    console.log("$(document).ready.user", user);
    if(user !== 'undefined'){
        let url = 'http://localhost:9090/api/students/' + user.username;
        fetch(url).then(s=>s.json()).then(s=>{
            $('#userFullname').html(s.firstName+' '+s.lastName);
            displayStudents(s.students);
        });
        let urlA = "http://localhost:9090/api/announcements" ; 
            fetch(urlA).then(s => s.json()).then(announ => displayAnnouncements(announ));
    }
    $('#sel1').change(fetchTasks);
    $('#logout').click(function(){
        localStorage.clear();
    });
});

function fetchTasks(){
    let selId = $(this).val().split(' ')[0]
    if(!isNaN(parseInt(selId))){
        console.log(parseInt(selId));
        $('#student-data').css('visibility','visible');
        displayTasks(selId);
    }
    else{
        $('#student-data').css('visibility','hidden');
    }
}

function showAnnouncemnt(){

    let htmlTemplate = $('#announcement-form-template').html(),
        annoTemplate = Handlebars.compile(htmlTemplate);
    $('#announcement-form').html(annoTemplate({}));
    let annID = $('#announcementDD').val().split(' ')[0];
    let url ="http://localhost:9090/api/announcements/"+annID;
    console.log(url);
    fetch(url).then(s => s.json()).then(announ =>{
        console.log(announ);
        $('#type').html(announ.announcementType);
        $('#body').html(announ.announcementBody);
         document.getElementById("image").src=announ.announcementAttatchment;
        $('#time').html(new Date(announ.timeStamp));
        let title1 = announ.announcementTitle;
        showFormAsModelAnnouncment(title1);
    });
}
function showFormAsModelAnnouncment(title1)
{
    let announcementForm = $('#announcement-form').dialog({
        height: 500,
        width: 650,
        title: title1,
        modal: true,
        buttons: {
            "Cancel": function () {
                announcementForm.dialog("close");
            }
        }
    });
}


function displayTasks(studentId){
    /*let url = 'http://localhost:9090/api/tasks/'+studentId;
     fetch(url).then(tasks=>tasks.json()).then(tasks=>{
     let htmlTemplate = $('#tasks-template').html(),
     tasksTemplate = Handlebars.compile(htmlTemplate)

     $('#tasks-table').html(tasksTemplate({tasks}));
     });*/
    //would be better server-sided, to avoid any data manipulation on get requests
    $('#studentTable tbody').empty();
    let studentInfo = {
        id: studentId
    };
    let url = 'http://localhost:9090/api/tasklist';
    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(studentInfo)
    }).then(response => response.json())
        .then(tasks => {
            let htmlTemplate = $('#tasks-template').html(),
                tasksTemplate = Handlebars.compile(htmlTemplate)
            $('#tasks-table').html(tasksTemplate({tasks}));
        });
    let stud = studentId;
    console.log(stud);
    let mesg = 'http://localhost:9090/api/messages/'+stud;
    fetch(mesg).then(res => res.json()).then(mes =>{
        console.log(mes);
        displayMessage(mes);
    });

}

function displayStudents(students){

    let htmlTemplate = $('#students-template').html(),
        studentsTemplate = Handlebars.compile(htmlTemplate);

    $('#sel1').html(studentsTemplate({students}));
}

function displayAnnouncements(announc) {
    let htmlTemplate = $('#announc-template').html(),
        announceTemplate = Handlebars.compile(htmlTemplate);

    $('#announcementDD').html(announceTemplate({announc}));
}

function displayMessage(mes) {
    let htmlTemplate = $('#message-template').html(),
        mesTemplate = Handlebars.compile(htmlTemplate);

    $('#messageDD').html(mesTemplate({mes}));
}

function showMessage(){

    let htmlTemplate = $('#message-form-template').html(),
        mesTemplate = Handlebars.compile(htmlTemplate);
    $('#message-form').html(mesTemplate({}));
    
    let mesId = $('#messageDD').val().split(' ')[0];
    console.log(mesId);
    let url ="http://localhost:9090/api/message/"+mesId;
    console.log(url);
    fetch(url).then(s => s.json()).then(mesg =>{
        console.log(mesg);
        console.log(mesg.instructorId);
        let url1 = 'http://localhost:9090/api/teacher/'+ mesg.instructorId;
        fetch(url1).then(s => s.json()).then( teacher => {
            $('#teacher').html(teacher.firstName +"--"+teacher.lastName);
        });
        console.log($('#teacher').val());
        console.log(mesg);
        $('#content').html(mesg.content);
        document.getElementById("attach").src=mesg.attachment;
        $('#timeD').html(mesg.timeStamp);
        let title1 = mesg.subject;
        showFormAsModelMessage(title1);
    });
}
function showFormAsModelMessage(title1)
{
    let messageForm = $('#message-form').dialog({
        height: 500,
        width: 650,
        title: title1,
        modal: true,
        buttons: {
            "Cancel": function () {
                messageForm.dialog("close");
            }
        }
    });
}
