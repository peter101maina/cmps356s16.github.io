/**
 * Created by boody on 24/04/2016.
 */
'use strict';
$(document).ready(function () 
{
    let user = JSON.parse(localStorage.user);
    console.log(user);
    let userinfo = 'http://localhost:9090/api/coordinators/'+user.username;
    fetch(userinfo).then(response=>response.json()).then(coordinator=>{
        $('#userFullname').html(coordinator.firstName+' '+coordinator.lastName);
    });
    getParents().then(parents => {
        console.log(parents);
        displayParents(parents);
    });
    $('#logout').click(function(){
        localStorage.clear();
    });
});

function displayParents(parents)
{
    let htmlTemplate = $('#coordinator-template').html(),
        coordinatorTemplate = Handlebars.compile(htmlTemplate);
    $('#parentsTable').html(coordinatorTemplate({parents}));
}

function addParent() {
    let htmlTemplate = $('#parent-form-template').html(), 
        parentTemplate = Handlebars.compile(htmlTemplate);
    $('#parent-form').html(parentTemplate({}));
    showFormAsModel();
}
function addStudent(val){
    let htmlTemplate = $('#student-form-template').html(),
        parentTemplate = Handlebars.compile(htmlTemplate);
    $('#student-form').html(parentTemplate({}));
    getHalaqas().then(halaqas => {
            fillHalaqasList(halaqas)
            console.log(halaqas)
        })
        .catch(err => console.log(err));
    console.log(val);
    $('#schoolGrade').change(function() {
        $('#count').html($(this).val());
    });
    showFormAsModelStudent(val);
}
function showFormAsModel(){
    let parentForm = $('#parent-form').dialog({
        height: 700,
        width: 750,
        title: 'Parent form',
        modal: true,
        buttons:{
            "Submit": function() {
               saveParent();
                parentForm.dialog( "close" );
            },
            "Cancel": function() {
                parentForm.dialog( "close" );
            }
        }
    });
}

function showFormAsModelStudent(val){
    let studentForm = $('#student-form').dialog({
        height: 580,
        width: 750,
        title: 'Student form',
        modal: true,
        buttons:{
            "Submit": function() {
                saveStudent(val);
                studentForm.dialog( "close" );

            },
            "Cancel": function() {
                studentForm.dialog( "close" );
            }
        }
    });
    
}
function getHalaqas() 
{
    let url = `http://localhost:9090/api/halaqas`;
    return fetch(url).then(response => response.json());
}

function fillHalaqasList(halaqas) {
    for (let halaqa of halaqas) {

        $("<option>", {
            value: halaqa.halaqaID,
            text: halaqa.halaqaName,
        }).appendTo($("#halaqa"));
    }
}
function getParents()
{
    let url = 'http://localhost:9090/api/parentsOnly';
    return fetch(url).then(response => response.json());
}

function saveParent()
{
    let parent = {
        qatariId: $('#qatariId').val(),
        firstName: $('#firstName').val(),
        lastName: $('#lastName').val(),
        mobile: $('#mobile').val(),
        email : $('#email').val(),
        username:$('#username').val(),
        countryOfOrigin$:$('#country').val(),
        password:$('#password').val(),
        students: []
    };

    console.log(parent.firstName);
    
    let url = "http://localhost:9090/api/students";
    let requestMethod = "post";
    console.log("here");
    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(parent)
    }).then(() =>{
        getParents().then(parents => displayParents(parents));
    });
    
}

function saveStudent(val){
    let student = {
        firstName: $('#studentFirstName').val(),
        lastName: $('#studentLastName').val(),
        dob: $('#dob').val(),
        gender:$('#gender').val(),
        schoolGrade:$('#schoolGrade').val(),
        halaqa: $('#halaqa').val(),
        parentId:val
    };
    let url = "http://localhost:9090/api/studentsOnly";
    let requestMethod = "post";
    console.log("iamhere");
    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(student)
    }).then(() =>{
        //cons
    });
}

function addAnnouncement(){
    let htmlTemplate = $('#announcement-form-template').html(),
        anouncmentTemplate = Handlebars.compile(htmlTemplate);
    $('#announcement-form').html(anouncmentTemplate({}));
    showFormAsModelAnnouncment();

}

function showFormAsModelAnnouncment(){
    
    let announcementForm = $('#announcement-form').dialog({
        height: 580,
        width: 750,
        title: 'Announcment form',
        modal: true,
        buttons:{
            "Cancel": function() {
                announcementForm.dialog( "close" );
            }
        }
    });
}

