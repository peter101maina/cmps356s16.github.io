/**
 * Created by Willowe
 */


'use strict';
let announcementRepository = require("./AnnouncementRepository");
// announcementRepository.getAnnouncements().then(anc => {
//     console.log(anc);
// });
announcementRepository.getAnnouncement(2).then(ann => console.log(ann));