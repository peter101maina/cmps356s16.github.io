/**
 * Created by root on 4/23/16.
 */
'use strict';
let teacherRepository = require("./TeacherRepository");
// teacherRepository.loginTeacher('coordinator','password').then(teacher=>{
//     console.log(teacher)
// }).catch(error=>{
//     console.log(error)
// });
// teacherRepository.getTeachers().then(teachers => {
//     console.log(teachers);
// });
//

// teacherRepository.getCordinators().then(coordinators => console.log(coordinators));
// teacherRepository.fetchTeacher('teacher1').then(teacher=>console.log(teacher));

teacherRepository.fetchTeacherInfo("502").then(t => console.log(t));



