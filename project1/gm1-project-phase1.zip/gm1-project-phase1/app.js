

/**
 * Created by root on 4/23/16.
 */
"use strict";
// 
let express = require('express'),
    bodyParser = require('body-parser'),
    multer = require('multer'),
    path = require('path'),
    uuid = require('node-uuid');
//open = require('open');
let surahRepository = require("./SurahRepository");
let teacherRepository = require("./TeacherRepository");
let studentRepository = require("./StudentRepository");
let taskRepository = require("./TaskRepository");
let announcementRepository = require("./AnnouncementRepository");
let messageRepository = require("./MessageRepository");
let halaqaRepository = require("./HalaqaRepository");


let app = express();
app.use(express.static(__dirname));
app.use(bodyParser.urlencoded({extended:true}));
//aut-deserialize the body of incoming request to  json object
app.use(bodyParser.json());

let port = 9090;

let options = multer.diskStorage(
    {
        destination : 'img/' ,
        filename: function (req, file, cb) {
            let fileName = uuid.v1() + path.extname(file.originalname);
            cb(null, fileName);
        }
    });


app.get('/',(req,res)=>{
    res.send('Welcome!!!');
});
app.get('/t',(req,res)=>{
    res.send('Welcome Teacher');
});
app.get('/c',(req,res)=>{
    res.send('Welcome Coordinator');
});
app.get('/api/surahs',(req,res)=>{
    surahRepository.getSurahs().then(surahs=>{
        console.log(surahs);
        res.json(surahs);
    });
});
app.get('/api/teachers',(req,res)=>
{
    teacherRepository.getTeachers().then(teachers=>{
        console.log(teachers);
        res.json(teachers);
    });
});
app.get('/api/announcements',(req,res)=>
{
    announcementRepository.getAnnouncements().then(anc=>{
        console.log(anc);
        res.json(anc);
    });
});
app.get('/api/messages',(req,res)=>
{
    messageRepository.getMessages().then(msg=>{
        console.log(msg);
        res.json(msg);
    });
});
app.post('/api/login', (req, res) =>
{
    let userInfo = req.body;
    console.log("app.post.req.body", userInfo);
    teacherRepository.loginTeacher(userInfo.username,userInfo.password).then(teacher=>{
        if(teacher.hasOwnProperty('isCoordinator')){
            userInfo.redirectTo = '/coordinator.html';
        }
        else{
            userInfo.redirectTo = '/teacher.html';
        }
        delete userInfo.password;
        res.json(userInfo);
    }).catch(err1=>
    {
        if(err1!='Invalid Password'){
            studentRepository.loginStudent(userInfo.username,userInfo.password).then(function(){
                userInfo.redirectTo = '/student.html';
                delete userInfo.password;
                res.json(userInfo);
            }).catch(err=>{
                userInfo.error = err;
                res.json(userInfo);
            });
        }
        else{
            userInfo.error = err1;
            res.json(userInfo);
        }
    });
});
//Updated upstream
app.post('/api/tasklist', (req, res) => {
    let studentInfo = req.body;
    console.log("app.post.req.body", studentInfo);
    taskRepository.getTaskByStudentId(parseInt(studentInfo.id)).then(tasks=>{
        console.log(tasks);
        res.json(tasks);
    });
});
//app.get('/api/students/:username', (req, res) => {
//=======

app.get('/api/students', (req, res)=> {
    studentRepository.getStudents().then(students=> {
        console.log(students);
        res.json(students);
    });
});

app.get('/api/students/:username', (req, res) => {
//>>>>>>> Stashed changes
    let username = req.params.username;
    console.log('req.params.username', username);
    studentRepository.fetchStudent(username).then(student => {
        console.log(JSON.stringify(student, null, 2));
        res.json(student);
    }).catch(err => {
        res.send("Failed :" + err);
    });
});
app.get('/api/messages/:id', (req, res) => {
    let studId = req.params.id;
    messageRepository.getMessagesByStudentId(studId).then(mes => {
        console.log(JSON.stringify(mes, null, 2));
        res.json(mes);
    }).catch(err => {
        res.send("Failed :" + err);
    });
});
app.get('/api/message/:id', (req, res) => {
    let mesId = req.params.id;
    messageRepository.getMessagesById(mesId).then(mes => {
        console.log(JSON.stringify(mes, null, 2));
        res.json(mes);
    }).catch(err => {
        res.send("Failed :" + err);
    });
});
app.get('/api/tasks/:id', (req, res) => {
    let id = req.params.id;
    console.log('req.params.id', id);
    taskRepository.getTaskById(parseInt(id)).then(task => {
        console.log(JSON.stringify(task, null, 2));
        res.json(task);
    }).catch(err => {
        res.send("Failed :" + err);
    });
});
app.get('/api/tasks', (req, res)=> {
    taskRepository.getTasks().then(tasks=> {
        console.log(tasks);
        res.json(tasks);
    });
});
app.get('/api/coordinators', (req, res)=> {
    teacherRepository.getCordinators().then(coordinators=> {
        console.log(coordinators);
        res.json(coordinators);
    });
});
app.get('/api/studentsOnly', (req, res)=> {
    studentRepository.getAllStudents().then(students=> {
        console.log(students);
        res.json(students);
    });
});
app.get('/api/parentsOnly', (req, res)=> {
    studentRepository.getAllParents().then(parents=> {
        console.log(parents);
        res.json(parents);
    });
});
app.get('/api/coordinators/:username', (req, res)=> {
    let username = req.params.username;
    console.log('req.params.username', username);
    teacherRepository.fetchCoordinator(username).then(coordinator => {
        console.log(JSON.stringify(coordinator, null, 2));
        res.json(coordinator);
    }).catch(err => {
        res.send("Failed :" + err);
    });
});

app.get('/api/announcements/:id', (req, res)=> {
    let anID = req.params.id;
    console.log(anID);
    announcementRepository.getAnnouncement(anID).then(ann => {
        console.log(JSON.stringify(ann, null, 2));
        res.json(ann);
    }).catch(err => {
        res.send("Failed :" + err);
    });
});

app.get('/api/teachers/:username', (req, res)=> {
    let username = req.params.username;
    console.log('req.params.username', username);
    teacherRepository.fetchTeacher(username).then(teacher => {
        console.log(JSON.stringify(teacher, null, 2));
        res.json(teacher);
    }).catch(err => {
        res.send("Failed :" + err);
    });
});
app.get('/api/halaqas/teacher/:staffNo', (req, res)=> {
    let staffNo = req.params.staffNo;
    console.log('req.params.staffNo', staffNo);
    halaqaRepository.getHalaqaByInstructor(parseInt(staffNo)).then(halaqa => {
        console.log(JSON.stringify(halaqa, null, 2));
        res.json(halaqa);
    }).catch(err => {
        res.send("Failed :" + err);
    });
});

app.get('/api/teacher/:id', (req, res)=> {
    let idNo = req.params.id;
    console.log('req.params.id', idNo);
    teacherRepository.fetchTeacherInfo(idNo).then(teacher => {
        console.log(JSON.stringify(teacher, null, 2));
        res.json(teacher);
    }).catch(err => {
        res.send("Failed :" + err);
    });
});

app.get('/api/halaqas', (req, res)=> {
    halaqaRepository.getHalaqas().then(halaqas=> {
        console.log(halaqas);
        res.json(halaqas);
    });
});

app.post('/api/students', (req, res) => {
    let parent = req.body;
    studentRepository.addParent(parent).then((newParent) =>{
        console.log("here !!! new parent");
        console.log(newParent);
        console.log("DONEE");
        let location = `/api/students/${newParent.username}`;
        console.log(location);
        res.location(location);
        res.status(201).send(location);
    }).catch(err => {
        res.status(500).send(err);
        console.log(err);
    });
});
app.post('/api/studentsOnly', (req, res) => {
    console.log("me");
    let student = req.body;
    let halaqaID = req.body.halaqa;
    console.log(halaqaID);
    console.log(req.body);
    studentRepository.addStudent(student).then((newStudent) => {
        console.log(newStudent);
        console.log("here!!!!");
        console.log(newStudent.halaqa);
        console.log(newStudent.studentId);
        halaqaRepository.assginToHalqa(halaqaID,newStudent.studentId);
        let location = `/api/studentsOnly/${newStudent.firstName}`;
        console.log(location);
        res.location(location);
        res.status(201).send(location);
    }).catch(err => {
        res.status(500).send(err);
        console.log(err);
    });
});

app.post('/upload', multer({ storage: options}).single('msgImage'), (req, res) => {
    console.log(req.body);
    console.log(req.file);
    let announcement = req.body;
    let uploadedFileName = req.file.filename;
    console.log('uploadedFileName', uploadedFileName);
    let imgUrl = `http://localhost:${port}/img/${uploadedFileName}`;
    announcementRepository.addAnnouncment(imgUrl,announcement).then(newAn => {
        console.log(newAn);
        let location = `/api/announcements/${newAn.announcementID}`;
        console.log(location);
        //res.location(location);
        res.status(201);
    }).catch(err => {
        res.status(500).send(err);
        console.log(err);
    });
});
app.post('/message', multer({ storage: options}).single('attachment'), (req, res) => {
    console.log(req.body);
    console.log(req.file);
    let message = req.body;
    let imgUrl='';
    if(req.file!=undefined) {
        let uploadedFileName = req.file.filename;
        console.log('uploadedFileName', uploadedFileName);
        imgUrl = `http://localhost:${port}/img/${uploadedFileName}`;
    }
    messageRepository.addMessage(imgUrl,message).then(newMessage => {
        console.log(newMessage);
        let location = `http://localhost:${port}/img/${newMessage.messageId}`;
        console.log(location);
        res.status(201).end('All done');
    }).catch(err => {
        res.status(500).send(err);
        console.log(err);
    });
});

app.post('/api/halaqastudents', (req, res) => {
    let students = req.body;
    console.log("app.post.req.body", students);
    studentRepository.getSomeStudents(students).then(s=>{
        console.log(s);
        res.json(s);
    });
});
app.delete('/api/tasks/:id', (req, res) =>{
    let taskId = req.params.id;
    console.log(taskId);
    taskRepository.deleteTask(parseInt(taskId)).then(() => {
        res.status(200).send("Task deleted");
    }).catch(err => {
        res.status(500).send(err);
    });
});
app.put('/api/tasks/:id', (req, res) => {
    let task = req.body;

    taskRepository.updateTask(task).then(() => {
        res.status(200).send("Task updated successfully");
    }).catch(err => {
        console.log(err);
        res.status(500).send(err);
    });
});
app.post('/api/tasks/', (req, res) => {
    let task = req.body;
    taskRepository.addTask(task).then(task=> {
            let urlOfNewTask = `/api/heroes/${task.taskId}`;
            res.location(urlOfNewTask)
            res.status(201).send(`Created and available @ ${urlOfNewTask}`);
        })
        .catch(err => res.status(500).send(err));
});
app.listen(port, function () {
    console.log("Listening @ http://localhost:" + port);
});
