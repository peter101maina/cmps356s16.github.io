/**
 * Created by Willowe
 */


'use strict';
let messageRepository = require("./MessageRepository");
// messageRepository.getMessages().then(msg => {
//     console.log(msg);
// });
//messageRepository.getMessagesById(1).then(mes => console.log(mes));
messageRepository.getMessagesById(5).then(mes => console.log(mes));