/**
 * Created by Willowe
 */


'use strict';

class AnnouncementRepository {
    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }


    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else
                    resolve();

            });
        });
    }

    getAnnouncements(){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./res/json/announcement.json').then(anc => {
                resolve(anc);
            }).catch(err => {
                reject(err);
            });
        });
    }

    addAnnouncment(url ,announcement){
        return new Promise((resolve, reject) => {
            this.getAnnouncements().then(announ => {
                let maxId = Math.max.apply(Math, announ.map(h => h.announcementID)) + 1;
                console.log("maxId", maxId);
                announcement.announcementID = maxId;
                announcement.announcementAttatchment = url;
                announcement.timeStamp = new Date();
                announ.push(announcement);
                return this.writeJsonFile('./res/json/announcement.json', announ);
            }).then(()=> resolve(announcement))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }
    
    getAnnouncement(id)
    {
        
        return new Promise((resolve, reject) => {
        this.readJsonFile('./res/json/announcement.json').then(announc => {
            announc = announc.filter(s => s.announcementID == id);
            
        if (announc.length > 0) {
            resolve(announc[0]);
         }
        else {
             reject("No records found");
        }
        });
        });
    }   


}//end of class

module.exports = new AnnouncementRepository();