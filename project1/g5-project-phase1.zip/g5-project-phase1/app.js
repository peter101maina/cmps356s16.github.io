'use strict';
let express = require('express');
let bodyParser = require('body-parser');
let favicon = require('serve-favicon');
let loginController = require('./LoginController.js');
let hmController = require('./HMController.js');

let app = express();


//Allow serving static files
app.use(express.static(__dirname));
let port = process.env.PORT || 9009;
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(favicon(__dirname + '/image/favicon.ico'));
module.exports = app;

app.get('/', (req, res) => {
    res.sendFile('login.html', {root: __dirname});
});

app.post('/', (req, res) => {
    loginController.login(req, res);
});

app.get('/api/student', (req, res) => hmController.getStudentAndTheirTasks(req, res));
app.get('/api/student/:teacherId', (req, res) => hmController.getStudents(req, res));
app.get('/api/children/:studentId', (req, res) => hmController.getStudent(req, res));
app.post('/api/student/:parentId', (req, res) => hmController.addStudent(req, res));

app.get('/api/surah', (req, res) => hmController.getSurahs(req, res));
app.get('/api/surah/:surahId', (req, res) => hmController.getSurah(req, res));

app.get('/api/task', (req, res) => hmController.getTasks(req, res));
app.post('/api/task', (req, res) => hmController.addTask(req, res));
app.get('/api/task/one/:taskId', (req, res) => hmController.getOneTask(req, res));
app.get('/api/task/:studentId', (req, res) => hmController.getTask(req, res));
app.get('/api/allTask', (req, res) => hmController.getTasksAndTheirStudent(req, res));
app.delete('/api/deleteTask/:taskId', (req, res) => hmController.deleteTask(req, res));
app.get('/api/StudentTask/:studentId/:status', (req, res) => hmController.getStudentTaskWithStatus(req, res));
app.put('/api/task', (req, res) => hmController.completeTask(req, res));
app.put('/api/task/task', (req, res) => hmController.updateTask(req, res));


app.post('/api/parent', (req, res) => hmController.addParent(req, res));
app.get('/api/parent/:qid', (req, res) => hmController.getParent(req, res));
app.get('/api/StudentParent/:studentId', (req, res) => hmController.getStudentsParent(req, res));
app.get('/api/parent', (req, res) => hmController.getParents(req, res));

app.get('/api/country', (req, res) => hmController.getCountries(req, res));

app.post('/api/message', (req, res) => hmController.sendMessage(req, res));
app.get('/api/message', (req, res) => hmController.getMessages(req, res));
app.get('/api/message/:to', (req, res) => hmController.getMessage(req, res));
app.get('/api/studentMessage/:studentId', (req, res) => hmController.getMessageForStudent(req, res));
app.get('/api/announcements', (req, res) => hmController.getAnnouncements(req, res));

app.get('/api/halaqa', (req, res) => hmController.getHalaqas(req, res));
// Listening Logic
app.listen(port, function () {
    console.log("HalaqaMetrash App is running on http://localhost:" + port);
});
