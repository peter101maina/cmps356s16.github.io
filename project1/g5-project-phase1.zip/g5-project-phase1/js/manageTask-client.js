'use strict';
var surahList; // global

$(document).ready(function () {
    let constructor = JSON.parse(localStorage.user);
    if (constructor != 'undefined') {
        $('#userFullname').html(constructor.firstName + ' ' + constructor.lastName);
    }
    getStudents().then(students => fillStudentsDD(students))
        .catch(err => console.log(err));
    $('#studentsDD').on('change', onStudentChange);
    $('#taskStatusDD').on('change', onStatusChange);
    $('#task-table').on('click','a.deleteButton', deleteTask);
    $('#task-table').on('click', 'a.updateButton', showUpdateForm);
    $('#task-table').on('click', 'a.completeButton', showCompleteForm);
});

function validateMe() {
    console.log($('#c_MasteryLevelDD').val());


    let due = getDate($('#c_dueDate').val());
    let completed = $('#c_completedDate').val();

    if ($('#c_comment').val().length == 0 ||
        $('#c_completedDate').val().length == 0 ||
        $('#c_MasteryLevelDD').val().length == 0
    ) {
        alert("Some fields are missing");
        $(".error").show();
        return -1;
    } else if (due > completed) {
        alert("Date completed must be greater than due date");
        $(".error").hide();
        $(".pattern").show();
        return -1;
    }
    else {
        completeTask();
        return 0;
    }

}

function getStudents() {
    let teacher = JSON.parse(localStorage.user);
    let url = `http://localhost:9009/api/student/${teacher.staffNo}`;
    return fetch(url).then(response => response.json());
}

function getSurahs() {
    let url = "http://localhost:9009/api/surah";
    return fetch(url).then(res => res.json());
}

function getSurah(surahId) {
    let url = `http://localhost:9009/api/surah/${surahId}`;
    return fetch(url).then(res => res.json());
}

function fillStudentsDD(students) {
    for (let student of students) {
        $("<option>", {
            value: student.studentId,
            text: `${student.studentId} - ${student.firstName} ${student.lastName}`
        }).appendTo($("#studentsDD"))
    }
}

function fetchTask() {
    let selectedStudentId = JSON.parse(localStorage.selectedStudentId);
    let selectedStatus= JSON.parse(localStorage.selectedStatus);
    let url = `/api/StudentTask/${selectedStudentId}/${selectedStatus}`;
    console.log(selectedStatus);
    console.log(selectedStudentId);
    return fetch(url).then(response => response.json());
}

function fetchTaskByTaskId(taskId) {
    let url = `http://localhost:9009/api/task/one/${taskId}`;
    return fetch(url).then(response => response.json());
}

function onStatusChange() {
    //console.log($(this).val());
    let selectedStatus = $(this).val();
    //console.log('onStatusChange.selectedStatus', selectedStatus);
    localStorage.setItem("selectedStatus", JSON.stringify(selectedStatus));
    fetchTask().then(tasks => displayTask(tasks));
}

function onStudentChange() {
    $('#taskStatusDD').val("");
    //console.log($(this).val());
    let selectedStudentId = $(this).val();
    //console.log('onStudentChange.selectedStudentId', selectedStudentId);
    localStorage.setItem("selectedStudentId", JSON.stringify(selectedStudentId));
}

function displayTask(tasks) {

    console.log(tasks);
    $('#task-table').empty();
    let htmlTemplate = $('#task-template').html(),
        taskTemplate = Handlebars.compile(htmlTemplate);
    $('#task-table').html(taskTemplate({tasks}));

}

function getTasks(studentId) {
    let url = `http://localhost:9009/api/student/${studentId}`;
    return fetch(url).then(response => response.json());
}

function deleteTask(event){
    event.preventDefault();

    if (!confirm('Confirm delete?')) {
        return;
    }

    let taskId = $(this).attr('data-taskId');
    console.log("deleteTask.data-taskId ", taskId);

    let url = `http://localhost:9009/api/deleteTask/${taskId}`;
    console.log("deleteTask.taskId", taskId);

    fetch(url, {
        method: 'delete'
    }).then(() => {
        //After successful delete remove the row from the HTML table
        $(this).closest('tr').remove();
    }).then(() => {
        //After delete then refresh the list
        fetchTask().then(tasks => displayTask(tasks));
    });
}

function getToday() {
    let today = new Date();
    let dd = today.getDate();
    let mm = today.getMonth() + 1; //January is 0!
    let yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    today = yyyy + "-" + mm + "-" + dd;
    return today;
}

function getTomorrow() {
    let tomorrow = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
    let tomday = tomorrow.getDate();
    let tommonth = tomorrow.getMonth() + 1;
    let tomyear = tomorrow.getFullYear();
    if (tomday < 10) {
        tomday = '0' + tomday;
    }
    if (tommonth < 10) {
        tommonth = '0' + tommonth
    }
    tomorrow = tomyear + "-" + tommonth + "-" + tomday;
    //tomorrow = tomday+"/"+ tommonth+"/"+tomyear;

    return tomorrow;
}

function getDate(date) {
    let dateString = date;
    let dateParts = dateString.split("/"); //because new Date read it as mm-dd-yyyy
    let today = new Date(dateParts[2], dateParts[1] - 1, dateParts[0]);
    let dd = today.getDate();
    let mm = today.getMonth() + 1; //January is 0!
    let yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    today = yyyy + "-" + mm + "-" + dd;
    return today;
}

function showCompleteForm() {
    let chosentask = {};
    let taskId = $(this).attr('data-taskId');
    fetchTaskByTaskId(taskId).then(task => {
        chosentask = task;
        let htmlTemplate = $('#complete-template').html(),
            completeTemplate = Handlebars.compile(htmlTemplate);

        $('#completesection').html(completeTemplate(task));
        $('#c_completedDate').val(getToday());
        showFormAsModel();

    }).catch(err => console.log(err));
}

function showFormAsModel() {
    let completeForm = $("#completesection").dialog({
        height: 460,
        width: 760,
        title: 'Complete Task',
        modal: true,
        buttons: {
            "Submit": function () {
                if (validateMe() >= 0) {
                    completeForm.dialog("close");
                }

            },
            Cancel: function () {
                completeForm.dialog("close");
            }
        }
    });
}

function showUpdateForm() {
    let selectedTask = {};
    let surahs = [];
    let taskId = $(this).attr('data-taskId');
    fetchTaskByTaskId(taskId).then(task => {
        selectedTask = task;
        return getSurahs();
    }).then(allsurahs => {
        surahs = allsurahs;
        surahList = allsurahs;
        return getSurah(selectedTask.surahId);
    }).then(asurah => {
        let htmlTemplate = $('#update-template').html(),
            updateTemplate = Handlebars.compile(htmlTemplate);
        $('#updatesection').html(updateTemplate(selectedTask));
        fillSurahsDD(surahs);
        $('#u_surahsDD').val(selectedTask.surahId);
        $('#u_dueDate').val(getDate(selectedTask.dueDate));
        if (selectedTask.type === 'Memorization') {
            $("#u_memorization").prop("checked", true);
        }
        else {
            $("#u_revision").prop("checked", true);
        }
        $('#u_fromAya').attr('max', asurah.ayaCount);
        $('#u_toAya').attr('max', asurah.ayaCount);
        $('#u_surahsDD').on('change', onSurahChange);
        $("#u_fromAya").on('change', onFromAyaChange);
        $("#u_toAya").on('change', onToAyaChange);
        showFormAsModel2();
    })
}

function onSurahChange() {
    resetSlider();
    let selectedSurahId = $(this).val();
    getSurah(selectedSurahId).then(surah => {
        $('#u_fromAya').attr('max', surah.ayaCount);
        $('#u_toAya').attr('max', surah.ayaCount);
    }).catch(err => console.log(err));
}

function resetSlider() {
    $("#u_fromAya").val(1);
    $("#u_toAya").val(1);
    $('#u_fromValue').val(1);
    $("#u_toValue").val(1);
}

function onFromAyaChange() {
    let chosenfromAya = $(this).val();
    console.log('#u_fromAya.val()', chosenfromAya)
    $('#u_toAya').val(parseInt(chosenfromAya) + 1)
    $("#u_toValue").val(parseInt(chosenfromAya) + 1);
}

function onToAyaChange() {
    let chosenToAya = parseInt($(this).val());
    let fromAya = parseInt($('#u_fromAya').val())
    // validate
    if (chosenToAya <= fromAya) {
        alert("To Aya must be greater than from Aya");
        $('#u_toAya').val(fromAya + 1);
        $('#u_toValue').val(fromAya + 1);
    }
}

function fillSurahsDD(surahs) {
    for (let surah of surahs) {
        $("<option>", {
            value: surah.id,
            text: `${surah.id}. [${surah.ayaCount} Aya] ${surah.englishName} - ${surah.name}`,
        }).appendTo($("#u_surahsDD"));
    }
}

function showFormAsModel2() {
    let updateForm = $("#updatesection").dialog({
        height: 410,
        width: 760,
        title: 'Update Task',
        modal: true,
        buttons: {
            "Submit": function () {
                /* validateMe2();*/
                updateTask();
                updateForm.dialog("close");
            },
            Cancel: function () {
                updateForm.dialog("close");
            }
        }
    });
}

function completeTask() {

    let cdate = $('#c_completedDate').val();
    cdate = moment(cdate).format("D/MM/YYYY");

    let completedTask = {
        taskId: parseInt($('#c_taskId').val()),
        studentId: parseInt($('#c_studentId').val()),
        surahId: parseInt($('#c_surahId').val()),
        surahName: $('#c_surahName').val(),
        fromAya: parseInt($('#c_fromAya').val()),
        toAya: parseInt($('#c_toAya').val()),
        type: $('#c_type').val(),
        dueDate: $('#c_dueDate').val(),
        completedDate: cdate,
        masteryLevel: $('#c_MasteryLevelDD').val(),
        comment: $('#c_comment').val()
    }
    let url = "http://localhost:9009/api/task";
    fetch(url, {
        method: "put",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(completedTask)
    }).then(() => {
        location.reload();
    }).catch(err => console.log(err));

}

function getSurahName(surahId) {
    let selectedSurah = {};
    for (let s of surahList) {
        if (s.id === surahId) {
            selectedSurah = s;
            break;
        }
    }
    return selectedSurah.englishName;
}

function updateTask() {
    let udate = $('#u_dueDate').val();
    udate = moment(udate).format("D/MM/YYYY");

    let surahName = getSurahName(parseInt($('#u_surahsDD').val()));


    let updatedTask = {
        taskId: parseInt($('#u_taskId').val()),
        studentId: parseInt($('#u_studentId').val()),
        surahId: parseInt($('#u_surahsDD').val()),
        surahName: surahName,
        fromAya: parseInt($('#u_fromAya').val()),
        toAya: parseInt($('#u_toAya').val()),
        type: $('input[name=u_type]:checked').val(),
        dueDate: udate,
    }
    let url = "http://localhost:9009/api/task/task";
    fetch(url, {
        method: "put",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(updatedTask)
    }).then(() => {
        location.reload();
    }).catch(err => console.log(err));

}

