'use strict';

$(document).ready(function () {
    let parent = JSON.parse(localStorage.user);
    if (parent != 'undefined') {
        $('#userFullname').html(parent.firstName + ' ' + parent.lastName);
    }

    getMessages(parent.email).then(messages => displayMessage(messages))
        .catch(err => console.log(err));
    getAnnouncements().then(messages => displayAnnouncement(messages))
        .catch(err => console.log(err));
});


function getMessages(email) {
    let url = `http://localhost:9009/api/message/${email}`
    return fetch(url).then(response => response.json());
}

function getAnnouncements() {
    let url = "http://localhost:9009/api/announcements"
    return fetch(url).then(response => response.json());
}

function displayMessage(messages) {
    console.log(JSON.stringify(messages, null, 2));//display in browser console

    let htmlTemplate = $('#email-template').html(),
        emailTemplate = Handlebars.compile(htmlTemplate);
    console.log('emailTemplate(messages)', emailTemplate(messages));
    $('#email-table').html(emailTemplate({messages}));

}

function displayAnnouncement(messages) {
    console.log(JSON.stringify(messages, null, 2));//display in browser console

    let htmlTemplate = $('#announcement-template').html(),
        announcementTemplate = Handlebars.compile(htmlTemplate);
    console.log('announcementTemplate(messages)', announcementTemplate(messages));
    $('#announcement-table').html(announcementTemplate({messages}));

}