'use strict';

$(document).ready(function () {
    let coordinator = JSON.parse(localStorage.user);
    if (coordinator != 'undefined') {
        $('#userFullname').html(coordinator.firstName + ' ' + coordinator.lastName);
    }
    fetchParents().then(parents => fillParentDD(parents))
        .catch(err => console.log(err));

    fetchHalaqas().then(halaqas => fillHalaqaDD(halaqas))
        .catch(err => console.log(err));

    $("#submit").click(function (event) {
        event.preventDefault();
        // Validate if fields are missing
        if ($('#Fname').val().length == 0 ||
            $('#Lname').val().length == 0 ||
            $('#dob').val().length == 0 || !$("input[name='gender']:checked").val() ||
            $('#grade').val().length == 0 ||
            $('#halaqaDD').val().length == 0
        ) {
            alert("Some fields are missing");
            $(".error").show();
            return;
        }
        else {
            addStudent();
        }

    });

});
function fetchParents() {
    let url = "http://localhost:9009/api/parent";
    return fetch(url).then(response => response.json());
}

function fetchHalaqas() {
    let url = "http://localhost:9009/api/halaqa";
    return fetch(url).then(response => response.json());
}

function fillParentDD(parents) {
    for (let parent of parents) {
        $("<option>", {
            value: parent.qatariId,
            text: `ID[${parent.qatariId}]  -  ${parent.firstName} ${parent.lastName}`
        }).appendTo($("#parentDD"));
    }
}

function fillHalaqaDD(halaqas) {
    for (let halaqa of halaqas) {
        $("<option>", {
            value: halaqa.teacherId,
            text: `${halaqa.halaqaId} - ${halaqa.name}`
        }).appendTo($("#halaqaDD"));
    }
}

function addStudent() {
    let dob = $('#dob').val();
    dob = moment(dob).format("D/MM/YYYY");
    let parentId = parseInt($("#parentDD").val());
    let newStudent = {
        firstName: $('#Fname').val(),
        lastName: $('#Lname').val(),
        dob: dob,
        gender: $('input[name=gender]:checked').val(),
        schoolGrade: parseInt($('#grade').val()),
        teacherId: parseInt($('#halaqaDD').val())
    }
    let url = `http://localhost:9009/api/student/${parentId}`;
    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(newStudent)
    }).then(() => {
        location.reload();
    }).catch(err => console.log(err));

}
