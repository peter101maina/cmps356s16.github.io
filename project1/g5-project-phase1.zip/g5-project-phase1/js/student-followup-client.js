'use strict'

$(document).ready(function () {
    let user = JSON.parse(localStorage.user);
    if (user != 'undefined') {
        $('#userFullname').html(user.firstName + ' ' + user.lastName);
    }

    if (user.isCoordinator == null) {
        $('.coordMenu').hide();
        //$('.parentMenu').hide();
    } else {
        $('.parentMenu').hide();
        // $('.coordMenu').hide();
    }


    getStudents().then(students => filterStudents(students))
        .catch(err => console.log(err));
    getAnnouncements().then(messages => displayAnnouncement(messages))
        .catch(err => console.log(err));

    $('#DD1').on('change', onStudentChange);
    $('#DD2').on('change', onStudentChange);
});

function getStudents() {
    let url = 'http://localhost:9009/api/student'
    return fetch(url).then(response => response.json());
}

function getAnnouncements() {
    let url = "http://localhost:9009/api/announcements"
    return fetch(url).then(response => response.json());
}

function filterStudents(students) {
    let user = JSON.parse(localStorage.user);
    console.log(user.isCoordinator);
    if (user.isCoordinator === 1) {
        //coordinator logic
        fillStudentsDD(students);
    }
    else {
        fillStudentsDD(user.students);
    }
}

function fillStudentsDD(students) {
    for (let student of students) {
        $("<option>", {
            value: student.studentId,
            text: `${student.studentId} - ${student.firstName} ${student.lastName}`
        }).appendTo($(".studentsDD"))
    }
}

function getTasks(studentId) {
    let url = `http://localhost:9009/api/task/${studentId}`;
    return fetch(url).then(response => response.json());
}

function onStudentChange() {
    //console.log($(this).val());
    let selectedStudentId = $(this).val();
    console.log('onStudentChange.selectedStudentId', selectedStudentId);
    getTasks(selectedStudentId).then(tasks => {
        displayFollowUp(tasks);
    }).catch(err => console.log(err));
    getMessages(selectedStudentId).then(message => {
        displayMessages(message);
    }).catch(err => console.log(err));
}

function fetchFollowUp() {
    let url = 'http://localhost:9009/api/allTask';
    return fetch(url).then(response => response.json());
}

function getMessages(studentId) {
    let url = `http://localhost:9009/api/studentMessage/${studentId}`
    return fetch(url).then(response => response.json());
}

function displayFollowUp(tasks) {
    //console.log(JSON.stringify(tasks, null, 2));//display in browser console
    let htmlTemplate = $('#followUp-template').html(),
        followUpTemplate = Handlebars.compile(htmlTemplate);
    //console.log('followUpTemplate(tasks)', followUpTemplate(tasks));
    $('.followUp-table').html(followUpTemplate({tasks}));
}

function displayMessages(messages) {
    console.log(JSON.stringify(messages, null, 2));//display in browser console
    let htmlTemplate = $('#email-template').html(),
        emailTemplate = Handlebars.compile(htmlTemplate);
    $('#email-table').html(emailTemplate({messages}));
}

function displayAnnouncement(messages) {
    console.log(JSON.stringify(messages, null, 2));//display in browser console
    let htmlTemplate = $('#announcement-template').html(),
        announcementTemplate = Handlebars.compile(htmlTemplate);
    console.log('announcementTemplate(messages)', announcementTemplate(messages));
    $('#announcement-table').html(announcementTemplate({messages}));

}