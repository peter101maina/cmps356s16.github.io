'use strict';

$(document).ready(function () {
    let instructor = JSON.parse(localStorage.user);
    if (instructor != 'undefined') {
        $('#userFullname').html(instructor.firstName + ' ' + instructor.lastName);
    }
    getStudents().then(students => fillStudentsDD(students))
        .catch(err => console.log(err));
    $('#studentsDD').on('change', onStudentChange);

    $("#submit").click(function (event) {
        event.preventDefault();
        // Validate if fields are missing
        if ($('#email').val().length == 0 ||
            $('#studentsDD').val().length == 0 ||
            $('#subject').val().length == 0 ||
            $('#content').val().length == 0
        ) {
            alert("Please fill the required fields");
            $(".error").show();
            return;
        }
        else {
            sendMessage();
        }

    });
});

function getStudents() {
    let teacher = JSON.parse(localStorage.user);
    let url = `http://localhost:9009/api/student/${teacher.staffNo}`;
    return fetch(url).then(response => response.json());
}

function getParent(){
    let selectedStudentId = JSON.parse(localStorage.selectedStudentId);
    let url = `http://localhost:9009/api/StudentParent/${selectedStudentId}`;
    return fetch(url).then(response => response.json());
}

function fillStudentsDD(students) {
    for (let student of students) {
        $("<option>", {
            value: student.studentId,
            text: `${student.studentId} - ${student.firstName} ${student.lastName}`
        }).appendTo($("#studentsDD"))
    }
}

function fillEmail(parents) {
    console.log(parent);
    $("#email").empty();
    for (let parent of parents) {
        $("#email").val(parent.email);
    }
}

function onStudentChange() {
    $('#email').val("");
    //console.log($(this).val());
    let selectedStudentId = $(this).val();
    //console.log('onStudentChange.selectedStudentId', selectedStudentId);
    localStorage.setItem("selectedStudentId", JSON.stringify(selectedStudentId));
    getParent().then(parent => fillEmail(parent));
}

function sendMessage() {
    let instructor = JSON.parse(localStorage.user);
    let date = new Date();
    date = moment(date).format("D/MM/YYYY");
    let newMessage = {
        from: instructor.email,
        to: $('#email').val(),
        studentId: parseInt($('#studentsDD').val()),
        subject: $('#subject').val(),
        message: $('#content').val(),
        date: date,
    }

    console.log(newMessage);
    let url = "http://localhost:9009/api/message";
    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(newMessage)
    }).then(() => {
        location.reload();

    }).catch(err => console.log(err));
}
