'use strict';

$(document).ready(function () {
    let coordinator = JSON.parse(localStorage.user);
    if (coordinator != 'undefined') {
        $('#userFullname').html(coordinator.firstName + ' ' + coordinator.lastName);
    }
    $("#submit").click(function (event) {
        event.preventDefault();
        // Validate if fields are missing
        if ($('#subject').val().length == 0 ||
            $('#announcementBox').val().length == 0
        ) {
            alert("Please fill the required fields");
            $(".error").show();
            return;
        }

        else {
            sendMessage();
        }

    });
});

function sendMessage() {
    let date = new Date();
    date = moment(date).format("D/MM/YYYY");
    let newMessage = {
        subject: $('#subject').val(),
        message: $('#announcementBox').val(),
        date: date
    }

    console.log(newMessage);
    let url = "http://localhost:9009/api/message";
    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(newMessage)
    }).then(() => {
        location.reload();
    }).catch(err => console.log(err));
}
