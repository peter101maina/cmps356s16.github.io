'use strict';

var surahList; // Global variable
$(document).ready(function () {
    // Prepare the name on the menu
    let instructor = JSON.parse(localStorage.user);
    if (instructor != 'undefined') {
        $('#userFullname').html(instructor.firstName + ' ' + instructor.lastName);
    }
    // Prepare the dropdown
    getStudents().then(students => fillStudentsDD(students))
        .catch(err => console.log(err));
    getSurahs().then(surahs => {
        surahList = surahs;
        fillSurahsDD(surahs);
    }).catch(err => console.log(err));
    //Set the default for date inputs
    $("#dueDate").val(getTomorrow());
    // Listens to the event
    $('#surahsDD').on('change', onSurahChange);
    $("#fromAya").on('change', onFromAyaChange);
    $("#toAya").on('change', onToAyaChange);

    $("#submit").click(function (event) {
        event.preventDefault();
        // Validate if fields are missing
        if ($('#studentsDD').val().length == 0 ||
            $('#surahsDD').val().length == 0 ||
            $('#fromAya').val().length == 0 || !$("input[name='type']:checked").val() ||
            $('#dueDate').val().length == 0
        ) {
            alert("Some fields are missing");
            $(".error").show();
            return;
        }
        else {
            addTask();
        }

    });
});


function getStudents() {
    let teacher = JSON.parse(localStorage.user);
    let url = `http://localhost:9009/api/student/${teacher.staffNo}`
    return fetch(url).then(response => response.json());
}


function getSurahs() {
    let url = "http://localhost:9009/api/surah";
    return fetch(url).then(res => res.json());
}


function getSurah(surahId) {
    let url = `http://localhost:9009/api/surah/${surahId}`;
    return fetch(url).then(res => res.json());
}

function fillStudentsDD(students) {
    for (let student of students) {
        $("<option>", {
            value: student.studentId,
            text: `${student.studentId} - ${student.firstName} ${student.lastName}`
        }).appendTo($("#studentsDD"));
    }

    // Setting default selected
    let defaultSelected = JSON.parse(localStorage.selectedStudentId);
    if (defaultSelected != 'undefined') {
        $('#studentsDD').val(parseInt(defaultSelected));
    }
}


function fillSurahsDD(surahs) {
    for (let surah of surahs) {
        $("<option>", {
            value: surah.id,
            text: `${surah.id}. [${surah.ayaCount} Aya] ${surah.englishName} - ${surah.name}`,
        }).appendTo($("#surahsDD"));
    }
}

//works
function getToday() {
    let today = new Date();
    let dd = today.getDate();
    let mm = today.getMonth() + 1; //January is 0!
    let yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    today = yyyy + "-" + mm + "-" + dd;
    return today;
}

//works
function getTomorrow() {
    let tomorrow = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
    let tomday = tomorrow.getDate();
    let tommonth = tomorrow.getMonth() + 1;
    let tomyear = tomorrow.getFullYear();
    if (tomday < 10) {
        tomday = '0' + tomday;
    }
    if (tommonth < 10) {
        tommonth = '0' + tommonth
    }
    tomorrow = tomyear + "-" + tommonth + "-" + tomday;
    //tomorrow = tomday+"/"+ tommonth+"/"+tomyear;

    return tomorrow;
}

//works
function onSurahChange() {
    resetSlider();
    let selectedSurahId = $(this).val();
    getSurah(selectedSurahId).then(surah => {
        $('#fromAya').attr('max', surah.ayaCount);
        $('#toAya').attr('max', surah.ayaCount);
    }).catch(err => console.log(err));
}
//Works
function resetSlider() {
    $("#fromAya").val(1);
    $("#toAya").val(1);
    $('#fromValue').val(1);
    $("#toValue").val(1);
}

//Works
function onFromAyaChange() {
    let chosenfromAya = $(this).val();
    console.log('#fromAya.val()', chosenfromAya)
    getSurah($('#surahsDD').val()).then(surah => {
        $('#toAya').val(parseInt(chosenfromAya) + 1)
        //$('#toAya').attr('min', parseInt(chosenfromAya) + 1);
        $("#toValue").val(parseInt(chosenfromAya) + 1);
    }).catch(err => console.log(err));
}

//Works
function onToAyaChange() {
    let chosenToAya = parseInt($(this).val());
    let fromAya = parseInt($('#fromAya').val())
    // validate
    if (chosenToAya <= fromAya) {
        alert("To Aya must be greater than from Aya");
        $('#toAya').val(fromAya + 1);
        $('#toValue').val(fromAya + 1);
    }
}

//works
function getSurahName(surahId) {
    let selectedSurah = {};
    for (let s of surahList) {
        if (s.id === surahId) {
            selectedSurah = s;
            break;
        }
    }
    return selectedSurah.englishName;
}

//works
function addTask() {
    // Ask the user to confirm. If they cancel the request then exit this function
    if (!confirm('Confirm Add?')) {
        return;
    }
    let date = $('#dueDate').val();
    date = moment(date).format("D/MM/YYYY");

    let surahName = getSurahName(parseInt($('#surahsDD').val()));
    let newTask = {
        studentId: parseInt($('#studentsDD').val()),
        surahId: parseInt($('#surahsDD').val()),
        surahName: surahName,
        fromAya: parseInt($('#fromAya').val()),
        toAya: parseInt($('#toAya').val()),
        type: $('input[name=type]:checked').val(),
        dueDate: date
    };

    console.log(newTask);
    let url = "http://localhost:9009/api/task/";
    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(newTask)
    }).then(() => {
        location.reload();
    }).catch(err => console.log(err));


}