'use strict';
$(document).ready(function () {
    $('#incorrectMessage').hide();
    $('#login').on('click', login);

});

function login(event) {
    event.preventDefault();

    let loginInfo = {
        username: $('#username').val(),
        password: $('#password').val()
    };

    let url = "http://localhost:9009/";
    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify((loginInfo))
    }).then(response => response.json())
        .then(user => {
            $('#incorrectMessage').hide();
            localStorage.user = JSON.stringify(user);
            localStorage.selectedStudentId = "";
            window.location = user.redirectTo;
            console.log(user);
        }).catch(err => {
        //console.log(err);
        $('#incorrectMessage').show();
    });

}