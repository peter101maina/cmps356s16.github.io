'use strict';
$(document).ready(function () {

    let coordinator = JSON.parse(localStorage.user);
    if (coordinator != 'undefined') {
        $('#userFullname').html(coordinator.firstName + ' ' + coordinator.lastName);
    }

    fetchCountries().then(countries => fillCountryDD(countries))
        .catch(err => console.log(err));

    fetchHalaqas().then(halaqas => fillHalaqaDD(halaqas))
        .catch(err => console.log(err));

    $("#submit").click(function (event) {
        event.preventDefault();
        // Validate if fields are missing
        if ($('#QID').val().length == 0 ||
            $('#PFname').val().length == 0 ||
            $('#PLname').val().length == 0 ||
            $('#email').val().length == 0 ||
            $('#mobile').val().length == 0 ||
            $('#username').val().length == 0 ||
            $('#pwd').val().length == 0
        ) {
            alert("Some fields are missing");
            $(".error").show();
            return;
        }
        else if (isNaN(parseInt($('#QID').val()))) {
            alert("Make sure your QID is correct and are in number form.");
            $(".pattern").show();
            return;
        }
        else {
            addParent();
        }

    });
});


function fetchCountries(){
    let url = "http://localhost:9009/api/country";
    return fetch(url).then(response => response.json());
}

function fetchHalaqas() {
    let url = "http://localhost:9009/api/halaqa";
    return fetch(url).then(response => response.json());
}

function fillCountryDD(countries){
    for (let country of countries) {
        $("<option>", {
            value: country.name,
            text: `${country.name}`
        }).appendTo($("#countryDD"));
    }
}
function fillHalaqaDD(halaqas) {
    for (let halaqa of halaqas) {
        $("<option>", {
            value: halaqa.teacherId,
            text: `${halaqa.halaqaId} - ${halaqa.name}`
        }).appendTo($("#halaqaDD"));
    }
}


function addParent() {

    let dob = $('#dob').val();
    dob = moment(dob).format("D/MM/YYYY");
    let students = [];
    if ($('#Fname').val().length != 0 || $('#Lname').val().length != 0) {
        // now validate
        if (dob != "Invalid date"
            || !isNaN(parseInt($('#grade').val()))
            || !isNaN(parseInt($('#halaqaDD').val()))
        ) {
            let firstChild = {
                firstName: $('#Fname').val(),
                lastName: $('#Lname').val(),
                dob: dob,
                gender: $('input[name=gender]:checked').val(),
                schoolGrade: parseInt($('#grade').val()),
                teacherId: parseInt($('#halaqaDD').val())
            }
            students.push(firstChild);
        }
        else {
            alert("Invalid input on child Info Only parents info will be register");
        }
    }
    let newParent ={
        qatariId: parseInt($('#QID').val()),
        firstName: $('#PFname').val(),
        lastName: $('#PLname').val(),
        mobile: $('#mobile').val(),
        email: $('#email').val(),
        nationality: $('#countryDD').val(),
        username: $('#username').val(),
        password: $('#pwd').val(),
        students: students
    }
    let url = "http://localhost:9009/api/parent/";
    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(newParent)
    }).then(() => {
        location.reload();
    }).catch(err => console.log(err));

}