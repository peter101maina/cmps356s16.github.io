'use strict';

class LoginController {
    constructor() {
        this.loginRepository = require('./LoginRepository.js');
    }

    login(req, res) {
        let loginInfo = req.body;
        console.log('login.req.body', loginInfo);
        this.loginRepository.login(loginInfo.username, loginInfo.password)
            .then(user => {
                if (user.username.indexOf("teacher") > -1) {
                    user.redirectTo = './manageTask.html';
                }
                else if (user.isCoordinator === 1) {
                    user.redirectTo = './studentFollow-Up.html';
                } else {
                    user.redirectTo = './parent.html';
                }
                //console.log('login.controller',user);
                res.json(user);
            }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

}
module.exports = new LoginController();
