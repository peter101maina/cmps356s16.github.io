'use strict'

class HMRepository {
    constructor() {
        this.fs = require('fs');
    }

//====================    R E A D   A N D   W R I T E  F I L E   ===========================//
    /*Read a file and convert its content to a json object*/
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    /**Writing to a json file**/
    writeJsonFile(filepath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filepath, JSON.stringify(data), error => {
                if (error) {
                    reject("Error in writing to a file. " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }


//=============    R E A D  D A T A   A S  I T   I S  I N   J S O N ======================//
    /*Get all tasks*/
    getTasks() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(tasks => {
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }

    /*Get all halaqas*/
    getHalaqas() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/halaqa.json').then(halaqas => {
                resolve(halaqas);
            }).catch(err => {
                reject(err);
            });
        });
    }

    /*Get all countries*/
    getCountries() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/countries.json').then(countries => {
                resolve(countries);
            }).catch(err => {
                reject(err);
            });
        });
    }

    /*Get all students with parents*/
    getParentsandStudents() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(students => {
                resolve(students);
            }).catch(err => {
                reject(err);
            });
        });
    }

    /*Get all surahs*/
    getSurahs() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/surah.json').then(surahs => {
                resolve(surahs);
            }).catch(err => {
                reject(err);
            });
        });
    }

    /*Get all messages*/
    getMessages() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/message.json').then(messages => {
                resolve(messages);
            }).catch(err => {
                reject(err);
            });
        });
    }


//======  R E A D  D A T A  W I T H  P A R A M E T E R S  O R  ==============//
//================ F I L T E R I N G    D A T A     =========================//

    /*Get my student only- given teacherId as parameter*/
    getMyStudent(teacherId) {
        let students = [];
        return new Promise((resolve, reject) => {
            this.getStudents().then(allstudents => {
                students = allstudents.filter(s => s.teacherId === teacherId);
                resolve(students);
            }).catch(err => {
                reject(err);
            });
        });
    }

    /*Get the parent for a given student - given stduentId as a parameter*/
    getStudentsParent(studentId){
        let parent = [];
        return new Promise((resolve, reject) => {
            this.getParentsandStudents().then(family => {
                for (let aFam of family) {
                    for (let i = 0; i < aFam.students.length; i++)
                        if(aFam.students[i].studentId === studentId)
                            parent.push(aFam);
                }
                resolve(parent);

            }).catch(err => {
                reject(err);
            })
        })
    }

    /*Get one surah with surahId as parameter*/
    getSurah(surahId) {
        return new Promise((resolve, reject) => {
            this.getSurahs().then(surahs => {
                surahs = surahs.filter(s => s.id === surahId);
                if (surahs.length > 0)
                    resolve(surahs[0]);
                else
                    reject(error);
            })
        })
    }

    /*Get all task for the given studentId and attach 
     the student object as an attribute to it*/
    getTask(studentId) {
        let tasks = [];
        let students = [];
        return new Promise((resolve, reject) => {
            this.getTasks().then(allTasks => {
                tasks = allTasks.filter(t => t.studentId === studentId);
                return this.getParentsandStudents();
            }).then(family => {
                for (let aFam of family) {
                    for (let i = 0; i < aFam.students.length; i++)
                        students.push(aFam.students[i]);
                }
                for (let task of tasks) {
                    for (let i = 0; i < students.length; i++) {
                        if (task.studentId === students[i].studentId)
                            task.student = students[i];
                    }
                }
                if (tasks.length > 0) {
                    resolve(tasks);
                }
                else {
                    reject("Student has no task.");
                }

            });
        });
    }

    /* Get all announcements */
    getAnnouncements() {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                messages = messages.filter(m => m.to == null);
                if (messages.length > 0)
                    resolve(messages);
                else
                    reject(error);
            })
        })
    }

    /* Get messages for particular parent*/
    getMessage(email) {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                messages = messages.filter(m => m.to === email);
                if (messages.length > 0)
                    resolve(messages);
                else
                    reject("No email found for that email address.");
            })
        })
    }

    /* Get messages for particular student*/
    getMessageForStudent(studentId) {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                messages = messages.filter(m => m.studentId === studentId);
                if (messages.length > 0)
                    resolve(messages);
                else
                    reject(error);
            })
        })
    }


    getParent(qatariId) {
        return new Promise((resolve, reject) => {
            this.getParentsandStudents().then(parents => {
                parents = parents.filter(p => p.qatariId === qatariId);
                if (parents.length > 0)
                    resolve(parents[0]);
                else
                    reject(err);
            })
        })
    }

    /*get one student given studentId*/
    getStudent(studentId) {
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                students = students.filter(s => s.studentId === studentId);
                if (students.length > 0)
                    resolve(students[0]);
                else
                    reject(err);
            })
        })
    }

    /*Get one task given taskId as parameter*/
    getOneTask(taskId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks = tasks.filter(t => t.taskId === taskId);
                if (tasks.length > 0) {
                    resolve(tasks[0]);
                }
                else {
                    reject("Task not found.");
                }
            });
        });
    }

//==============    F L A T T E N I N G   A R R A Y      =============================//

    /*get all students in flat array of student objects*/
    getStudents() {
        let students = [];
        return new Promise((resolve, reject)=> {
            this.getParentsandStudents().then(family => {
                for (let aFam of family) {
                    for (let i = 0; i < aFam.students.length; i++)
                        students.push(aFam.students[i]);
                }
                resolve(students);
            }).catch(err => {
                reject(err);
            });
        });
    }


//==================== DEALING   WITH   TASK   AND   STUDENTS ======================//

    /*Get all the student and attach their tasks 
     as an array to each student object*/
    getStudentAndTheirTasks() {
        let students = [];
        return new Promise((resolve, reject) => {
            this.getStudents().then(allstudents => {
                students = allstudents;
                return this.getTasks();
            }).then(tasks => {
                // initializes an array of tasks for students
                for (let aStudent of students) {
                    aStudent.tasks = [];
                }
                for (let task of tasks) {
                    for (let i = 0; i < students.length; i++) {
                        if (task.studentId === students[i].studentId)
                            students[i].tasks.push(task);
                    }
                }
                resolve(students);
            }).catch(error => {
                reject(error);
            });
        });
    }

    /*Get all tasks and attach the student object to it*/
    getTasksandTheirStudent() {
        let taskAndStudents = [];
        let students = [];
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                taskAndStudents = tasks;
                return this.getStudents();
            }).then(allstudents => {
                students = allstudents;
                for (let task of taskAndStudents) {
                    for (let i = 0; i < students.length; i++) {
                        if (task.studentId === students[i].studentId)
                            task.student = students[i];
                    }
                }
                resolve(taskAndStudents);
            }).catch(error => {
                reject(error);
            });
        });
    }


    /*Get tasks for Students(with students objects attached) given teacherId*/
    getMyStudentTasks(teacherId) {
        let myStudentTasks = [];
        return new Promise((resolve, reject) => {
            this.getTasksandTheirStudent().then(myStudentTasks => {
                myStudentTasks = myStudentTasks.filter(t => t.student.teacherId === teacherId);
                resolve(myStudentTasks)
            }).catch(error => {
                reject(error);
            });
        })
    }


    /*Task for particular student given their ID and status of their task*/
    getStudentTaskWithStatus(studentId , selectedStatus) {
        return new Promise((resolve, reject) => {
            this.getTask(studentId).then(tasks => {
                if (selectedStatus == "All") {
                    resolve(tasks);
                }
                else if (selectedStatus == "Completed") {
                    tasks = tasks.filter(tasks => tasks.completedDate);
                    resolve(tasks);
                }
                else {
                    tasks = tasks.filter(tasks => tasks.completedDate === undefined);
                    resolve(tasks);
                }
            }).catch(err => console.log(err));
        })
    }

// ============   A D D   /   D E L E T E   J S O N   O B J E C T S   =================//

    /*Add new task for a student*/
    addTask(newTask) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let maxId = Math.max.apply(Math, tasks.map(r => r.taskId)) + 1;
                //console.log("MaxId: " + maxId);
                newTask.taskId = maxId;
                //console.log(newTask);
                tasks.push(newTask);
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(()=> {
                resolve(newTask);
            }).catch(error => reject(error));
        });
    }

    /*Register new parent*/
    addParent(newParent) {
        let newId;
        return new Promise((resolve, reject)=> {
            this.generateStudentId().then(id => {
                newId = id;
                return this.getParentsandStudents();
            }).then(family => {
                if (newParent.students[0]) {
                    newParent.students[0].studentId = newId;
                }
                family.push(newParent);
                return this.writeJsonFile('./data/student.json', family);
            }).then(()=> {
                resolve(newParent);

            }).catch(err => {
                    reject(err);
                });
        })
    }

    /*Register new children with existing parent*/
    addStudent(student, qatariId) {
        return new Promise((resolve, reject) => {
            this.generateStudentId().then(id => {
                student.studentId = id;
                return this.getParentsandStudents();
            }).then(parents => {
                for (let parent of parents) {
                    if (qatariId === parent.qatariId)
                        parent.students.push(student);
                }
                return this.writeJsonFile('./data/student.json', parents);
            }).then(()=> {
                resolve(student);
            }).catch(error => reject(error));
        });
    }


    /*Send messages to particular parent or announcement to all parents*/
    sendMessage(newMessage) {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                let maxId = Math.max.apply(Math, messages.map(m => m.msgId)) + 1;
                //console.log("MaxId: " + maxId);
                newMessage.msgId = maxId;
                //console.log(newTask);
                messages.push(newMessage);
                return this.writeJsonFile('./data/message.json', messages);
            }).then(()=> {
                resolve(newMessage);
            }).catch(error => reject(error));
        });
    }

    /*Delete pending Task*/
    deleteTask(taskId) {
        let deleteTask;
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let len = tasks.length,
                    remThisIndex = -1;
                for (let i = 0; i < len; i++) {
                    if (tasks[i].taskId == taskId) {
                        remThisIndex = i;
                        break;
                    }
                }
                deleteTask = tasks[remThisIndex];
                //removing
                if (remThisIndex >= 0) {
                    tasks.splice(remThisIndex, 1);
                }
                //Update the file
                //console.log(tasks);
                this.writeJsonFile('./data/task.json', tasks);
            }).then(() => {
                resolve();//changed
            }).catch(error => {
                reject(error)
            });
        });
    }

    /*complete task method*/
    completeTask(completedTask) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let len = tasks.length;
                for (let i = 0; i < len; i++) {
                    if (tasks[i].taskId == completedTask.taskId) {
                        tasks[i] = completedTask;
                        break;
                    }
                }
                //console.log(tasks);
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(() => {
                resolve();
            }).catch(error => {
                reject(error)
            });
        });
    }

    /*complete task method*/
    updateTask(updatedTask) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let len = tasks.length;
                for (let i = 0; i < len; i++) {
                    if (tasks[i].taskId == updatedTask.taskId) {
                        tasks[i] = updatedTask;
                        break;
                    }
                }
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(() => {
                resolve();
            }).catch(error => {
                reject(error)
            });
        });
    }


//=====================   F U N C T I O N     H E L P E R     ========================//
    generateStudentId() {
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                let maxId = Math.max.apply(Math, students.map(s => s.studentId)) + 1;
                resolve(maxId);
            }).catch(error => reject(error));
        });
    }


}
module.exports = new HMRepository();