'use strict';

let loginRepository = require('./LoginRepository.js');

loginRepository.getTeachers().then(teachers => {
    //console.log(teachers);
}).catch(err => console.log(err));


loginRepository.getParents().then(parents => {
    //console.log(parents);
}).catch(err => console.log(err));

loginRepository.getAllUsers().then(users => {
    //console.log(users);
}).catch(err => console.log(err));

loginRepository.login("coordinator", "password").then(user => {
    //console.log(user);
}).catch(err => console.log(err));