'use strict';

let hmrepo = require('./HMRepository.js');

/*
hmrepo.getTasks().then(tasks => {
    //console.log(tasks)
}).catch(err => console.log(err));
*/


/*
 hmrepo.getParentsandStudents().then(students => {
    console.log(students)
 console.log(students)
}).catch(err => console.log(err));
*/



/*hmrepo.getTasksandTheirStudent().then(tasks => {
 console.log(tasks);
 }).catch(err => console.log(err));*/
/*
hmrepo.getTask(2).then(task=> {
    //console.log(task);
}).catch(err => console.log(err));

hmrepo.getSurahs().then(surahs=> {
    //console.log(surahs);
}).catch(err => console.log(err));

hmrepo.getSurah(3).then(surah=> {
    //console.log(surah);
}).catch(err => console.log(err));
*/

/*
 */


/*
hmrepo.getMessage("juha@test.com").then(message=> {
 console.log(message);
      console.log(message);
}).catch(err => console.log(err));

 */

/*
 hmrepo.getMessageForStudent(1).then(message=> {
 console.log(message);
 }).catch(err => console.log(err));
 */
/*
hmrepo.getMessageForStudent(1).then(message=> {
     console.log(message);
}).catch(err => console.log(err));
*/

let newTask = {
    studentId: 1,
    surahId: 7,
    surahName: "Al-Araf",
    fromAya: 20,
    toAya: 40,
    type: "Revision",
    dueDate: "3/04/2016"
}
/*hmrepo.addTask(newTask).then(task => {
   // console.log(task);
 }).catch(err => console.log(err));*/

/*
hmrepo.getMessages().then(message=> {
   // console.log(message);
}).catch(err => console.log(err));

hmrepo.getAnnouncements().then(messages=> {
   // console.log(messages);
}).catch(err => console.log(err));

/*
let msg = {
    "to": "abbas@test.com",
    "subject": "Your child progress",
    "message": "Both of your children did really well for their halaqa"
}
hmrepo.sendMessage(msg).then(message=> {
    //console.log(message);
}).catch(err => console.log(err));
*/


/*
let student = {
    firstName: "Ibn Juha",
    lastName: "Dahak",
    dob: "1/1/2009",
    gender: "M",
    schoolGrade: 4,
    teacherId: 503
}
hmrepo.addStudent(student, 12).then((student) => {
    console.log(student);
}).catch(err => console.log(err));
 */

/*
hmrepo.getCountries().then(countries => {
   // console.log(countries);
}).catch(err => console.log(err));
*/

/*
hmrepo.deleteTask(13).then(()=> {
 //console.log(deleted);
 }).catch(err => console.log(err));
*/

/*
hmrepo.getStudentTaskWithStatus(1,"Completed").then(task=> {
    console.log(task);
 }).catch(err => console.log(err));
*/

/*hmrepo.getTask(1).then(tasks => {
 console.log(tasks)
 }).catch(err => console.log(err));*/

/*Works*/
/*
hmrepo.getMyStudent(501).then(student => {
 console.log(student)
 }).catch(err => console.log(err));
*/
/*hmrepo.getOneTask(14).then(t=> console.log(t)).catch(err=>console.log(err));*/

/*
 hmrepo.getStudentsParent(3).then(student => {
 console.log(student);
 }).catch(err => console.log(err));
 */

/*
 hmrepo.getMyStudentTasks(501).then(student => {
 hmrepo.getStudentsParent(3).then(student => {
 console.log(student);
 }).catch(err => console.log(err));
*/

/*
hmrepo.getMyStudentTasks(501).then(student => {
    console.log(student)
 }).catch(err => console.log(err));
*/
/* }).catch(err => console.log(err));
 *!/*/

/*
 hmrepo.getHalaqas().then(halaqas => {
 console.log(halaqas)
 }).catch(err => console.log(err));*/

/*
 hmrepo.generateStudentId().then(id => {
 console.log(id);
 }).catch(err => console.log(err));

 }).catch(err => console.log(err));
 */


let parent = {
    qatariId: 56,
    firstName: "ll",
    lastName: "mm",
    mobile: "9999-8882",
    email: "samira@test.com",
    username: "samira",
    password: "password",
    students: [
        /*  {
         firstName: "Ibn kk",
         lastName: "mm",
         dob: "1/2/2003",
         gender: "M",
         schoolGrade: 6,
         teacherId: 501
         }*/]
}


/*

 hmrepo.addParent(parent).then(parent => {
 console.log(parent);
 }).catch(err => console.log(err));
 */

/*

 hmrepo.getStudents().then(students => {
 console.log(students);
 }).catch(err => console.log(err));*/


/*
 hmrepo.getStudentAndTheirTasks().then(students => {
 console.log(students);
 }).catch(err => console.log(err));*/


/*
 hmrepo.getMyStudentTasks(502).then(tasks => {
 console.log(tasks);
 }).catch(err => console.log(err));
*/

/*
 hmrepo.getOneTask(4).then(t => {
 console.log(t);
 }).catch(err => console.log(err));*/

/*
 let c = {
 studentId: 1,
 surahId: 17,
 surahName: "Al-Isra",
 fromAya: 1,
 toAya: 10,
 type: "Memorization",
 dueDate: "29/04/2016",
 taskId: 13
 }

 /!*
 hmrepo.completeTask(c).then(()=>{}).catch(err => console.log(err));*!/

 hmrepo.updateTask(c).then(()=>{}).catch(err => console.log(err));
 */
