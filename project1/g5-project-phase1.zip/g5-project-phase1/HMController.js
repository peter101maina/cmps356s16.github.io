'use strict';
class HMController {
    constructor() {
        this.hmRepository = require('./HMRepository.js');
    }

    getTasksAndTheirStudent(req, res) {
        this.hmRepository.getTasksandTheirStudent().then(tasks => {
            res.json(tasks);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    getStudentAndTheirTasks(req, res) {
        this.hmRepository.getStudentAndTheirTasks().then(students => {
            res.json(students);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    getStudentTaskWithStatus(req, res){
        this.hmRepository.getStudentTaskWithStatus(parseInt(req.params.studentId),req.params.status).then(tasks => {
            res.json(tasks);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    getTasks(req, res) {
        this.hmRepository.getTasks().then(tasks => {
            res.json(tasks);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    getTask(req, res) {
        this.hmRepository.getTask(parseInt(req.params.studentId)).then(tasks => {
            res.json(tasks);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    deleteTask(req,res){
        let taskId = req.params.taskId;
        //console.log('req.params.taskId', taskId);
        this.hmRepository.deleteTask(parseInt(taskId)).then(() =>{
            res.status(200).send("Task is succefully deleted.")
        }).catch(err => res.status(500).send(err));
    }

    getParent(req, res) {
        this.hmRepository.getParent(parseInt(req.params.qid)).then(parent => {
            res.json(parent);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    getParents(req, res) {
        this.hmRepository.getParentsandStudents().then(parents => {
            res.json(parents);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    getStudentsParent(req, res) {
        this.hmRepository.getStudentsParent(parseInt(req.params.studentId)).then(parent => {
            res.json(parent);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    getSurahs(req, res) {
        this.hmRepository.getSurahs().then(surahs => {
            res.json(surahs);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    getStudents(req, res) {
        this.hmRepository.getMyStudent(parseInt(req.params.teacherId)).then(students => {
            res.json(students);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    getStudent(req, res) {
        this.hmRepository.getStudent(parseInt(req.params.studentId)).then(student=> {
            res.json(student);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    getCountries(req, res) {
        this.hmRepository.getCountries().then(countries => {
            res.json(countries);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    getHalaqas(req, res) {
        this.hmRepository.getHalaqas().then(halaqas => {
            res.json(halaqas);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    getSurah(req, res) {
        this.hmRepository.getSurah(parseInt(req.params.surahId)).then(surah => {
            res.json(surah);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    addTask(req, res) {
        let newTask = req.body;
        this.hmRepository.addTask(newTask).then((newtask)=> {
            let urlOfNewTask = `/api/task/${newtask.taskId}`;
            res.location(urlOfNewTask);
            res.status(201).send("Successfully Created.");
        }).catch(err => res.status(500).send(err));
    }

    addParent(req, res) {
        let parent = req.body;
        this.hmRepository.addParent(parent).then((newParent)=> {
                let urlOfNewParent = `/api/parent/${newParent.qatariId}`;
                res.location(urlOfNewParent)
                res.status(201).send(`Created and available @ ${urlOfNewParent}`);
            })
            .catch(err => res.status(500).send(err));
    }

    addStudent(req, res) {
        let newStudent = req.body;
        this.hmRepository.addStudent(newStudent, parseInt(req.params.parentId)).then((newStudent)=> {
                let urlOfNewStudent = `/api/children/${newStudent.studentId}`;
                res.location(urlOfNewStudent)
                res.status(201).send(`Created and available @ ${urlOfNewStudent}`);
            })
            .catch(err => res.status(500).send(err));
    }

    getMessages(req, res) {
        this.hmRepository.getMessages().then(messages => {
            res.json(messages);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    getMessage(req, res) {
        this.hmRepository.getMessage(req.params.to).then(message => {
            res.json(message);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    getMessageForStudent(req, res) {
        this.hmRepository.getMessageForStudent(parseInt(req.params.studentId)).then(message => {
            res.json(message);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    getAnnouncements(req, res) {
        this.hmRepository.getAnnouncements().then(message => {
            res.json(message);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    sendMessage(req, res) {
        let newMessage = req.body;
        this.hmRepository.sendMessage(newMessage).then(messagesent => {
            let urlOfNewMessage = `/api/message/${messagesent.msgId}`;
            res.location(urlOfNewMessage);
            res.status(201).send("Message is successfully sent.");
        }).catch(err => res.status(500).send(err));
    }

    getOneTask(req, res) {
        this.hmRepository.getOneTask(parseInt(req.params.taskId)).then(task => {
            res.json(task);
        }).catch(error => {
            res.status(404).send("Failed: " + error);
        });
    }

    completeTask(req, res) {
        let completedTask = req.body;
        this.hmRepository.completeTask(completedTask).then(() => {
            res.status(200).send("Task updated successfully");
        }).catch(err => {
            console.log(err);
            res.status(500).send(err);
        });
    }

    updateTask(req, res) {
        let updatedTask = req.body;
        this.hmRepository.updateTask(updatedTask).then(() => {
            res.status(200).send("Task updated successfully");
        }).catch(err => {
            console.log(err);
            res.status(500).send(err);
        });
    }

}

module.exports = new HMController();
