'use strict';

class LoginRepository {
    constructor() {
        this.fs = require('fs');
    }

    //Read a file and convert its content to a json object
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    /*Get all teachers*/
    getTeachers() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(teachers => {
                resolve(teachers);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getParents() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(teachers => {
                resolve(teachers);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getAllUsers() {
        let users = [];
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {
                users = parents;
                return this.getTeachers();
            }).then(teachers => {
                for (let teacher of teachers) {
                    users.push(teacher);
                }
                resolve(users);
            }).catch(err => {
                reject(err);
            });
        })
    }

    login(username, password) {
        return new Promise((resolve, reject) => {
            this.getAllUsers().then(users => {
                users = users.filter(u => {
                    if (u.username === username && u.password === password)
                        return u;
                });
                if (users.length > 0)
                    resolve(users[0]);
                else
                    reject("Users not found.");
            });
        });
    }

}

module.exports = new LoginRepository();
