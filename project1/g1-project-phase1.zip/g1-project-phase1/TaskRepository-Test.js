/**
 * Created by lamyyaalsulaiti on 4/23/16.
 */
'use strict'


let taskRepo = require('./TaskRepository.js');

/*taskRepo.getTasks().then(tasks => {
    console.log(tasks);
});*/

/*let task = {
    studentId: 5,
    surahId: 6,
    surahName: "Al-Anaam",
    fromAya: 17,
    toAya: 21,
    type: "Memorization",
    dueDate: "3/04/2016"
}

taskRepo.addTask(task);*/

let studentId = 2;

taskRepo.getTaskForStudent(studentId).then(tasks => {
    console.log(tasks);
});

/*taskRepo.getCompletedTaskForStudent(studentId).then(tasks => {
    console.log(tasks);
});*/

/*taskRepo.deleteTask(1);*/

/*let task = {
    taskId: 7,
    studentId: 1,
    surahId: 2,
    surahName: "Al-Baqara",
    fromAya: 8,
    toAya: 12,
    type: "Memorization",
    dueDate: "3/03/2016",
    completedDate: "2/04/2016",
    masteryLevel: "Excellent",
    comment: "Excellent work"

}

taskRepo.updateTask(task);*/


