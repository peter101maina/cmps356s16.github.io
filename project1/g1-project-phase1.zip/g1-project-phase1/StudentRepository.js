/**
 * Created by lamyyaalsulaiti on 4/22/16.
 */
'use strict'

class StudentRepository{
    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }

    getStudents() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./student.json').then(students => {
                resolve(students);
            }).catch(err => {
                reject(err);
            });
        });
    }

    addStudent(student) {
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                //Get the last Id used +1
                let maxId = Math.max.apply(Math, students.map(s => s.students.studentId)) + 1;
                console.log("maxId", maxId);

                for(let s of student.students){
                    s.studentId = maxId;
                    maxId++;
                }

                console.log("addStudent", student);
                students.push(student);
                return this.writeJsonFile('./student.json', students);
            }).then(()=> resolve(student))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

}

module.exports = new StudentRepository();