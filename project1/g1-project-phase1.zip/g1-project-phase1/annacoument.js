'use strict'
//When the document is loaded in the browser then fill the heroes dropdown.
$(document).ready(function () {
    getAnnouncements()
});

function fetchAnnouncements() {
    let url = "http://localhost:9080/api/annacouments";
    return fetch(url).then(response => response.json());
}

function getAnnouncements() {
    //Empty the hero-details div
    fetchAnnouncements().then(announcements => displayAnnouncements(announcements))
        .catch(err => console.log(err));
}

function displayAnnouncements(announcements) {
    let htmlTemplate = $('#announcements-template').html(),
        messagesTemplate = Handlebars.compile(htmlTemplate);

    $('#announcements-list').html(messagesTemplate({announcements}));
}

function addAnnacouments() {
    let htmlTemplate = $('#addAnnouncement-form-template').html(),
        sendTemplate = Handlebars.compile(htmlTemplate);

    $('#addAnnouncement-form').html(sendTemplate({}));
    showFormAsModel();
}

function showFormAsModel() {
    let addAnnouncementForm = $("#addAnnouncement-form").dialog({
        height: 550,
        width: 750,
        title: 'Send an Announcement Form',
        modal: true,
        buttons: {
            "Submit": function () {
                saveAnnouncements();
                addAnnouncementForm.dialog("close");
            },
            Cancel: function () {
                addAnnouncementForm.dialog("close");
            }
        }
    })
}

function saveAnnouncements() {
    let announcement = {
        subject: $('#subject').val(),
        content: $('#content').val(),
        url: $('#url').val()
    };
    let url = "http://localhost:9080/api/annacouments";
    let requestMethod = "post";

    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(announcement)
    }).then(() => {
        //After add/update then refresh the list
        getAnnouncements();
    });
}
