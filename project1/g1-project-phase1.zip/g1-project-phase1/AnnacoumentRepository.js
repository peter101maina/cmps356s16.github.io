/**
 * Created by lamyyaalsulaiti on 4/24/16.
 */
'use strict'

class annacoumentRepository{
    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }
    getAnnacouments() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./annacoument.json').then(annacouments => {
                resolve(annacouments);
            }).catch(err => {
                reject(err);
            });
        });
    }

    addAnnacoument(annacoument){
        return new Promise((resolve, reject) => {
            this.getAnnacouments().then(annacouments => {
                console.log("addAnnacoument", annacoument);
                annacouments.push(annacoument);
                return this.writeJsonFile('./annacoument.json', annacouments);
            }).then(()=> resolve(annacoument))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

}

module.exports = new annacoumentRepository();