'use strict'

$(document).ready(function () {
});

function fetchAnnouncements() {
    let url = "http://localhost:9080/api/annacouments";
    return fetch(url).then(response => response.json());
}

function getAnnouncements() {
    //Empty the hero-details div
    fetchAnnouncements().then(announcements => displayAnnouncements(announcements))
        .catch(err => console.log(err));
    showAnnouncementsModel();
}

function displayAnnouncements(announcements) {
    let htmlTemplate = $('#announcements-template').html(),
        announcementTemplate = Handlebars.compile(htmlTemplate);

    $('#announcements-list').html(announcementTemplate({announcements}));
}

function showAnnouncementsModel() {
    let showAccouncementsForm = $("#announcements-list").dialog({
        height: 550,
        width: 750,
        title: 'Annoucements',
        modal: true,
        buttons: {
            "Ok": function () {
                showAccouncementsForm.dialog("close");
            },
            Cancel: function () {
                showAccouncementsForm.dialog("close");
            }
        }
    })
}

function displayMessages(messages) {
    let htmlTemplate = $('#messages-template').html(),
        messagesTemplate = Handlebars.compile(htmlTemplate);
    $('#messages-list').html(messagesTemplate({messages}));
}

function getMessages(studentId) {
    let url = `http://localhost:9080/api/messages/${studentId}`;
    return fetch(url).then(response => response.json());
}


function showMessagesModel() {
    let htmlTemplate = $('#showSTDid-form-template').html(),
        msgTemplate = Handlebars.compile(htmlTemplate);

    let showMessagesForm = $('#showSTDifForm').html(msgTemplate({})).dialog({
        height: 350,
        width: 750,
        title: 'Messages',
        modal: true,
        buttons: {
            "Ok": function () {
                showMessagesForm.dialog("close");
                showMessages();
            },
            Cancel: function () {
                showMessagesForm.dialog("close");
            }
        }
    })
}

function showMessages(){
    let studentID = $('#studentID').val();
    $('#messages-list').empty();
    $('#tasks-list').empty();
    getMessages(studentID).then(messages => {
        displayMessages(messages);
    }).catch(err => console.log(err));
}

function displayTasks(tasks) {
    let htmlTemplate = $('#tasks-template').html(),
        tasksTemplate = Handlebars.compile(htmlTemplate);
    $('#tasks-list').html(tasksTemplate({tasks}));
}

function getTasks(studentId) {
    let url = `http://localhost:9080/api/tasks/${studentId}`;
    return fetch(url).then(response => response.json());
}

function showTasksModel() {
    let htmlTemplate = $('#showSTDid-form-template').html(),
        followUpTemplate = Handlebars.compile(htmlTemplate);

    let showMessagesForm = $('#showSTDifForm').html(followUpTemplate({})).dialog({
        height: 350,
        width: 750,
        title: 'Follow up',
        modal: true,
        buttons: {
            "Ok": function () {
                showMessagesForm.dialog("close");
                showTasks();
            },
            Cancel: function () {
                showMessagesForm.dialog("close");
            }
        }
    })
}

function showTasks(){
    let studentID = $('#studentID').val();
    //empty both the lists to avoid having many lists appearing together
    $('#messages-list').empty();
    $('#tasks-list').empty();
    getTasks(studentID).then(tasks=> {
        displayTasks(tasks);
    }).catch(err => console.log(err));
}
