/**
 * Created by lamyyaalsulaiti on 4/22/16.
 */
'use strict'

let studentRepository = require('./StudentRepository.js');
studentRepository.getStudents().then(students => {
    console.log(students);
});

let student333 = {
    firstname: 'fmkfrekf',
    lastname: 'djejfoeo',
    mobile: '39992999299',
    email: 'doeoek',
    username: 'djoe',
    password: '2kdjkwe',
    students: [
        {
            firstName: "Ibnnnnnn",
            lastName: "Saghir",
            dob: "1/2/2007",
            gender: "M",
            schoolGrade: 6
        },
        {
            firstName: "binnnntttt",
            lastName: "Saghir",
            dob: "1/3/2010",
            gender: "F",
            schoolGrade: 3
        }
    ]
}

studentRepository.addStudent(student333);