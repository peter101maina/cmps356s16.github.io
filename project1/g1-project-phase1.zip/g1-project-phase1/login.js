'use strict'
$(document).ready(function () {
    $('#login').on('click', login);
});

function login(event) {
    event.preventDefault();
    let userInfo = {
        username: $('#username').val(),
            password: $('#password').val(),
        requestedPage: $('#requestedPage').val()
    };
    console.log("login.userInfo", userInfo);
    let url = "http://localhost:9080/";
    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(userInfo)
    }).then(response => response.json())
        .then(user => {
            console.log("Redirect to:", user.redirectTo);
            //store the userInfo in the localStorage so it is available to other pages
            localStorage.user = JSON.stringify(user);
            window.location = user.redirectTo;
        });
}