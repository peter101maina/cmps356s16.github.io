'use strict'
//When the document is loaded in the browser then fill the heroes dropdown.
$(document).ready(function () {
    getMessages();
});

function fetchMessages() {
    let url = "http://localhost:9080/api/messages";
    return fetch(url).then(response => response.json());
}

function getMessages() {
    //Empty the hero-details div
    fetchMessages().then(messages => displayMessages(messages))
        .catch(err => console.log(err));
}

function displayMessages(messages) {
    let htmlTemplate = $('#messages-template').html(),
        messagesTemplate = Handlebars.compile(htmlTemplate);
    $('#messages-list').html(messagesTemplate({messages}));
}

function addMessage() {
    let htmlTemplate = $('#addmessage-form-template').html(),
        sendTemplate = Handlebars.compile(htmlTemplate);

    $('#addmessage-form').html(sendTemplate({}));
    showFormAsModel();
}

function showFormAsModel() {
    let addmessageForm = $("#addmessage-form").dialog({
        height: 550,
        width: 750,
        title: 'Send a message Form',
        modal: true,
        buttons: {
            "Submit": function () {
                saveMessages();
                addmessageForm.dialog("close");
            },
            Cancel: function () {
                addmessageForm.dialog("close");
            }
        }
    })
}

    function saveMessages() {
            let message = {
                studentId: $('#studentID').val(),
                subject: $('#subject').val(),
                messageContent: $('#content').val(),
                url: $('#url').val()
            };
            let url = "http://localhost:9080/api/messages";
            let requestMethod = "post";

            fetch(url, {
                method: requestMethod,
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(message)
            }).then(() => {
                //After add/update then refresh the list
                getMessages();
            });
        }
