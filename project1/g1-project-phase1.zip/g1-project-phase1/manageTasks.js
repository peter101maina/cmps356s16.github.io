
'use strict'
//When the document is loaded in the browser then fill the heroes dropdown.
$(document).ready(function () {
    getTasks();

    /*let user = JSON.parse(localStorage.user);
     console.log("$(document).ready.user", user);
     if (user != 'undefined') {
     $('#username').html(user.username);
     }*/
    $('#tasks-list').on('click', 'a.deleteButton', deleteTask);
});

function deleteTask(event) {
    //Prevent the default browser behavior when a link is clicked
    event.preventDefault();

    // Ask the user to confirm. If they cancel the request then exit this function
    if (!confirm('Confirm delete?')) {
        return;
    }

    //Get the data-taskId custom attribute associated with the clicked Link
    //Note this refers to the link that was clicked (i.e., the source of the click event)
    let taskId = $(this).attr('data-taskId');
    console.log("deleteTask.taskId: ", taskId);

    let url = `http://localhost:9080/api/tasks/${taskId}`;
    console.log("deleteTask.taskId", taskId);
    fetch(url, {method: 'delete'}).then(() => {
        //After successful delete remove the row from the HTML table
        $(this).closest('tr').remove();
    }).then(() => {
        //After delete then refresh the list
        getTasks();
    });
}

function updateTask(taskId) {
    console.log("taskId", taskId);
    fetchTask(taskId).then(task => {
        console.log(task);

        let htmlTemplate = $('#task-form-template').html(),
            taskTemplate = Handlebars.compile(htmlTemplate);

        $('#task-form').html(taskTemplate(task));


        showFormAsModel();

    }).catch(err => console.log(err));
}

function fetchTask(taskId) {
    let url = `http://localhost:9080/api/task/${taskId}`;
    return fetch(url).then(response => response.json());
}

function getTasks() {
    /*$('#hero-details').empty();*/
    fetchTasks().then(tasks => displayTasks(tasks))
        .catch(err => console.log(err));
}

function fetchTasks() {
    let url = "http://localhost:9080/api/tasks";
    return fetch(url).then(response => response.json());
}


function displayTasks(tasks) {
    let htmlTemplate = $('#tasks-template').html(),
        tasksTemplate = Handlebars.compile(htmlTemplate)

    $('#tasks-list').html(tasksTemplate({tasks}));
}

function addTask() {
    let htmlTemplate = $('#task-form-template').html(),
        taskTemplate = Handlebars.compile(htmlTemplate);

    $('#task-form').html(taskTemplate({}));
    showFormAsModel();
}

function showFormAsModel() {
    let taskForm = $( "#task-form" ).dialog({
        height: 450,
        width: 750,
        title: 'Task Form',
        modal: true,
        buttons: {
            "Submit": function() {
                saveTask();
                taskForm.dialog( "close" );
            },
            Cancel: function() {
                taskForm.dialog( "close" );
            }
        }
    });
}

function saveTask() {
    let task = {
        studentId: $('#studentId').val(),
        surahId: $('#surahId').val(),
        surahName: $('#surahName').val(),
        fromAya: $('#fromAya').val(),
        toAya: $('#toAya').val(),
        type: $('#type').val(),
        dueDate: $('#dueDate').val(),
        completedDate: $('#completedDate').val(),
        masteryLevel: $('#masteryLevel').val(),
        comment: $('#comment').val()
    };

    let url = "http://localhost:9080/api/tasks/";
    let requestMethod = "post";

    let taskId = $('#taskId').val();

    //In case of update make the method put and append the id to the Url
    if (taskId != '') {
        task.taskId = parseInt(taskId);
        url += taskId;
        requestMethod = "put";
    }
    console.log("saveTask.taskId", taskId);

    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(task)
    }).then(() => {
        //After add/update then refresh the list
        getTasks();
    });
}