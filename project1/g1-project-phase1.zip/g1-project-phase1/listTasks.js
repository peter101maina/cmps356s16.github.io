/**
 * Created by lamyyaalsulaiti on 4/18/16.
 */
$(document).ready(function(){

    $("#showBtn").on('click', showTasks());
});

function getTasks(studentId , taskState) {
    if(taskState === "completed"){
        let url = `http://localhost:9080/api/completedTasks/${studentId}`;
        return fetch(url).then(response => response.json()); 
    } else if(taskState === "pending"){
        let url = `http://localhost:9080/api/pendingTasks/${studentId}`; 
        return fetch(url).then(response => respone.json());
    }
}

function showTasks() {
    let studentId = $('#studentIddd');
    let taskState = $('#taskState');
    getTasks(studentId , taskState).then(tasks => {
        displayTasks(tasks);
    }).catch(err => console.log(err));
}

function displayTasks(tasks) {

    let htmlTemplate = $('#tasks-template').html(),
        tasksTemplete = Handlebars.compile(htmlTemplate)

    console.log('tasksTemplete', tasksTemplete(tasks));

    $('#tasksList').html(tasksTemplete(tasks));
}


