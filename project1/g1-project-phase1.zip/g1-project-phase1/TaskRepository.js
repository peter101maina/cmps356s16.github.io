/**
 * Created by lamyyaalsulaiti on 4/23/16.
 */
'use strict'

class TaskRepository{
    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    getTasks() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./task.json').then(tasks => {
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }

    addTask(task) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let maxId = Math.max.apply(Math, tasks.map(t => t.taskId)) + 1;
                console.log("maxId", maxId);

                task.taskId = maxId;

                console.log("addTask", task);
                tasks.push(task);
                return this.writeJsonFile('./task.json', tasks);
            }).then(()=> resolve(task))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    getTaskForStudent(studentId){
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks = tasks.filter(t => t.studentId == studentId);
                if (tasks.length > 0) {
                    resolve(tasks);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    fetchTask(taskId){
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks = tasks.filter(t => t.taskId == taskId);
                if (tasks.length > 0) {
                    resolve(tasks);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getPendingTaskForStudent(studentId){
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks = tasks.filter(t => !t.hasOwnProperty('completedDate') && t.studentId == studentId);
                if (tasks.length > 0) {
                    resolve(tasks);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getCompletedTaskForStudent(studentId){
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks = tasks.filter(t => t.hasOwnProperty('completedDate') && t.studentId == studentId);
                if (tasks.length > 0) {
                    resolve(tasks);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    // can be used to update and complete tasks
    updateTask(task){
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let len = tasks.length;
                for(let i=0; i<len; i++){
                    if (tasks[i].taskId == task.taskId) {
                        tasks[i] = task;
                        break;
                    }
                }
                return this.writeJsonFile('./task.json', tasks);
            }).then(()=> resolve())
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    deleteTask(taskId){
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                // Look for the hero to be deleted then remove it
                let len = tasks.length;
                let foundAt = -1;
                for (let i = 0; i < len; i++) {
                    if (tasks[i].taskId == taskId) {
                        foundAt = i;
                        break;
                    }
                }
                if (foundAt >= 0) {
                    tasks.splice(foundAt, 1);
                }
                console.log("deleteTask", taskId);

                return this.writeJsonFile('./task.json', tasks);
            }).then(() => {
                resolve();
            }).catch(err => {
                reject(err);
            });
        });
    }

}

module.exports = new TaskRepository();