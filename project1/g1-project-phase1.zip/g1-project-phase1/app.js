"use strict";

let express = require('express')
let bodyParser = require('body-parser')


let app = express();
app.use(express.static(__dirname));

let port = 9080;

app.use(bodyParser.urlencoded({ extended: true}));
app.use(bodyParser.json());

let annacoumentRepository = require('./AnnacoumentRepository.js');
let messageRepository = require('./MessagesRepository.js');
let studentRepository = require('./StudentRepository.js');
let taskRepository = require('./TaskRepository.js');
let surahRepository = require('./surahRepository.js')



app.get('/about', (req, res) => {
  res.send(`Welcome to Halaqa Metrash <br>
    <p>
        Urls: <br>
        - http://localhost:9080/api/messages to get messages as a json document <br>
        - http://localhost:9080/api/messages/1 to get messages for student with ID 1 as a json document <br><br>
        - http://localhost:9080/api/annacouments to get annacouments as json file <br>
        - http://localhost:9080/api/students to get students as a json document <br>
        - http://localhost:9080/api/tasks to get tasks as a json document <br>
        - http://localhost:9080/api/completedTasks/1 get completed tasks fo student with ID 1 as json document <br>
        - http://localhost:9080/api/pendingTasks/1 get pending tasks for student with ID 1 as json document <br>

    </p>`);
});


app.get('/', function(req, res) {
  res.redirect('http://localhost:9080/login.html');
});

app.post('/', (req, res) => {
  let userInfo = req.body;
  console.log("app.post.req.body", userInfo);

  if (userInfo.requestedPage === 'coordinator') {
    userInfo.redirectTo = '/coordinator.html';
    res.json(userInfo);

  } else if (userInfo.requestedPage === 'teacher') {
    userInfo.redirectTo = '/teacher.html';
    res.json(userInfo);
  }
  else {
    userInfo.redirectTo = '/parent.html';
    res.json(userInfo);
  }
});

app.get('/api/messages', (req, res) => {
  messageRepository.getMessages().then(messages => {
    res.json(messages);
  });
});

app.post('/api/messages', (req, res) => {
  let message = req.body;
  messageRepository.addMessage(message).then((message) =>{
    res.json(message);
  }).catch(err => res.status(500).send(err));
});

app.get('/api/messages/:id', (req, res) => {
  let studentId = req.params.id;
  console.log('req.params.id', studentId);
  messageRepository.getMessagesForStudent(studentId).then(message => {
    console.log(JSON.stringify(message, null, 2));
    res.json(message);
  }).catch(err => {
    res.send("Failed :" + err);
  });
});

app.get('/api/surahs', (req, res) => {
  surahRepository.getSurahs().then(surahs => {
    res.json(surahs);
  });
});

app.get('/api/surahs/:id', (req, res) => {
  let surahId = req.params.id;
  console.log('req.params.id', surahId);
  surahRepository.getSurah(surahId).then(surah => {
    console.log(JSON.stringify(surah, null, 2));
    res.json(surah);
  }).catch(err => {
    res.send("Failed :" + err);
  });
});


app.get('/api/annacouments', (req, res) => {
  annacoumentRepository.getAnnacouments().then(annacouments => {
    res.json(annacouments);
  });
});

app.post('/api/annacouments', (req, res) => {
  let annacoument = req.body;
  annacoumentRepository.addAnnacoument(annacoument).then((annacoument) =>{
    res.json(annacoument);
  }).catch(err => res.status(500).send(err));
});

app.get('/api/students', (req, res) => {
  studentRepository.getStudents().then(students => {
    res.json(students);
  });
});

app.post('/api/students', (req, res) => {
  let student = req.body;
  studentRepository.addStudent(student).then((student) =>{
    res.json(student);
  }).catch(err => res.status(500).send(err));
});


app.get('/api/tasks', (req, res) => {
  taskRepository.getTasks().then(tasks => {
    res.json(tasks);
  });
});

app.post('/api/tasks/', (req, res) => {
  let task = req.body;

  taskRepository.addTask(task).then((task)=> {
        let urlOfNewHero = `/api/heroes/${task.id}`;
        res.location(urlOfNewHero)
        res.status(201).send(`Created and available @ ${urlOfNewHero}`);
      })
      .catch(err => res.status(500).send(err));
});

app.get('/api/tasks/:id', (req, res) => {
  let studentId = req.params.id;
  console.log('req.params.id', studentId);
  taskRepository.getTaskForStudent(studentId).then(task => {
    console.log(JSON.stringify(task, null, 2));
    res.json(task);
  }).catch(err => {
    res.send("Failed :" + err);
  });
});

app.get('/api/task/:id', (req, res) => {
  let taskId = req.params.id;
  console.log('req.params.id', taskId);
  taskRepository.fetchTask(taskId).then(task => {
    console.log(JSON.stringify(task, null, 2));
    res.json(task);
  }).catch(err => {
    res.send("Failed :" + err);
  });
});

app.get('/api/completedTasks/:id', (req, res) => {
  let studentId = req.params.id;
  console.log('req.params.id', studentId);
  taskRepository.getCompletedTaskForStudent(studentId).then(tasks => {
    console.log(JSON.stringify(tasks, null, 2));
    res.json(tasks);
  }).catch(err => {
    res.send("Failed :" + err);
  });
});

app.get('/api/pendingTasks/:id', (req, res) => {
  let studentId = req.params.id;
  console.log('req.params.id', studentId);
  taskRepository.getPendingTaskForStudent(studentId).then(tasks => {
    console.log(JSON.stringify(tasks, null, 2));
    res.json(tasks);
  }).catch(err => {
    res.send("Failed :" + err);
  });
});

app.delete('/api/tasks/:id', (req, res) => {
  let taskId = req.params.id;
  taskRepository.deleteTask(taskId).then(() => {
    res.status(200).send("Task deleted");
  }).catch(err => {
    res.status(500).send(err);
  })
});

app.listen(port, function(){
  console.log('HalaqatMetrash App is running my app on http://localhost:' + port);
});




