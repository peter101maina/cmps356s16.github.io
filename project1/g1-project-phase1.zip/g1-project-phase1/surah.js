$(document).ready(function(){
    getSurahs().then(surahs => fillSurahsDD(surahs))
        .catch(err => console.log(err));
});

function getSurahs() {
    let url = "http://localhost:9080/api/surahs";
    return fetch(url).then(response => response.json());
}

function fillSurahsDD(surahs) {
    for(let surah of surahs) {
        $("<option>", {
            text: surah.name
        }).appendTo($("#surahName"))
    }
}