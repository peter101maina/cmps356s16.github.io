'use strict'

class surahRepository {
    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }
    getSurahs() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./surah.json').then(surahs => {
                resolve(surahs);
            }).catch(err => {
                reject(err);
            });
        });
    }
}

module.exports = new surahRepository();