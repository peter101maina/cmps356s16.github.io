/**
 * Created by lamyyaalsulaiti on 4/24/16.
 */
'use strict'

class MessagesRepository{
    constructor() {
        this.fs = require('fs');
    }
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }
    getMessages() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./message.json').then(messages => {
                resolve(messages);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getMessagesForStudent(studentId) {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                messages = messages.filter(m => m.studentId == studentId);
                resolve(messages);
            });
        });
    }

    addMessage(message){
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                console.log("addMessage", message);
                messages.push(message);
                return this.writeJsonFile('./message.json', messages);
            }).then(()=> resolve(message))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

}

module.exports = new MessagesRepository();