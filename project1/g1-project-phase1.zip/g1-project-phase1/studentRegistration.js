'use strict'
//When the document is loaded in the browser then fill the heroes dropdown.
$(document).ready(function () {
});

function addStudent() {
    let htmlTemplate = $('#Parent-form-template').html(),
        addTemplate = Handlebars.compile(htmlTemplate);

    $('#Parent-form').html(addTemplate({}));
    showParentFormAsModel();
}

function showParentFormAsModel() {
    let addParentForm = $("#Parent-form").dialog({
        height: 550,
        width: 750,
        title: 'Register a student Form',
        modal: true,
        buttons: {
            "Add student": function(){
                showStudentFormAsModel();
            },
            "Done": function () {
                addParentForm.dialog("close");
            },
            Cancel: function () {
                addParentForm.dialog("close");
            }
        }
    })
}

function saveStudent() {
    let student = {
        firstname: $('#parentFN').val(),
        lastname: $('#parentLN').val(),
        mobile: $('#mobile').val(),
        email: $('#email').val(),
        username: $('#username').val(),
        password: $('#password').val(),
        students: [
            {
                firstName: $('#studentFN').val(),
                lastName: $('#studentLN').val(),
                dob: $('#dob').val(),
                gender:$('#gender').val(),
                schoolGrade: $('#schoolGrade').val()
            }
        ]
    };
    let url = "http://localhost:9080/api/students";
    let requestMethod = "post";
    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(student)
    }).then(() => {
    });
}

function showStudentFormAsModel() {
    let htmlTemplate = $('#Student-form-template').html(),
        addTemplate = Handlebars.compile(htmlTemplate);
    let addStudentForm = $('#Student-form').html(addTemplate({})).dialog({
        height: 550,
        width: 750,
        title: 'Add Student',
        modal: true,
        buttons: {
            "Submit": function () {
                saveStudent();
                addStudentForm.dialog("close");
            },
            Cancel: function () {
                addStudentForm.dialog("close");
            }
        }
    })
}

