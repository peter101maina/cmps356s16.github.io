/**
 * Created by sarahalhussaini on 4/26/16.
 */

'use strict';

class SurahRepository {

    constructor() {
        this.utils = require('./Utils');
    }

    getSurahs() {
        return new Promise((resolve, reject) => {
            this.utils.readJsonFile('./data/surah.json').then(surahs => {
                surahs = surahs.map(s => {
                    return {
                        id: s.id,
                        name: s.name,
                        englishName: s.englishName,
                        ayaCount: s.ayaCount,
                        type: s.type
                    }
                });
                resolve(surahs);
            }).catch(err => {
                reject(err);
            });
        });
    }

    fetchSurah(surahId) {
        return new Promise((resolve, reject) => {
            this.getSurahs().then(surahs => {
                surahs = surahs.filter(s => s.id === surahId);
                if (surahs.length > 0) {
                    resolve(surahs[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
}

module.exports = new SurahRepository();