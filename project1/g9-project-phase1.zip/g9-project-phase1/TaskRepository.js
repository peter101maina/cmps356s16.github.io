/**
 * Created by sarahalhussaini on 4/26/16.
 */

'use strict';

class TaskRepository {

    constructor() {
        this.utils = require('./Utils');
    }

    getTasks() {
        return new Promise((resolve, reject) => {
            this.utils.readJsonFile('./data/task.json').then(tasks => {
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }

    fetchTask(taskId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks = tasks.filter(t => t.taskId === taskId);
                if (tasks.length > 0) {
                    resolve(tasks[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getCompletedTasks(teacherStaffNo) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks = tasks.filter(r => r.completedDate != null);
                tasks = tasks.filter(t => t.teacherStaffNo == parseInt(teacherStaffNo));
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        })
    }

    getPendingTasks(teacherStaffNo) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks = tasks.filter(r => r.completedDate == null);
                tasks = tasks.filter(t => t.teacherStaffNo == parseInt(teacherStaffNo));
                resolve(tasks);
            }).catch(err => {
                reject(err);
            });
        })
    }

    addTask(task) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let taskId = tasks[tasks.length - 1].taskId + 1;
                task.taskId = taskId;
                tasks.push(task);
                return this.utils.writeJsonFile('./data/task.json', tasks);
            }).then(() => {
                resolve(task);
            }).catch(err => reject(err));
        });
    }

    deleteTask(taskId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                // Look for the hero to be deleted then remove it
                let len = tasks.length;
                let foundAt = -1;
                for (let i = 0; i < len; i++) {
                    if (tasks[i].taskId == taskId) {
                        foundAt = i;
                        break;
                    }
                }
                if (foundAt >= 0) {
                    tasks.splice(foundAt, 1);
                }

                //Save the heros back to the file
                return this.utils.writeJsonFile('./data/task.json', tasks);
            }).then(() => {
                resolve();
            }).catch(err => {
                reject(err);
            });
        });
    }

    updateTask(task) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let len = tasks.length;
                for (let i = 0; i < len; i++) {
                    if (tasks[i].taskId == task.taskId) {
                        tasks[i] = task;
                        break;
                    }
                }
                return this.utils.writeJsonFile('./data/task.json', tasks);
            }).then(()=> resolve())
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    fetchTaskByStudentId(studentId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks = tasks.filter(t => t.studentId == studentId);
                if (tasks.length > 0) {
                    resolve(tasks);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }


}

module.exports = new TaskRepository();