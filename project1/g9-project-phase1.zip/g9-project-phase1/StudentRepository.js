/**
 * Created by sarahalhussaini on 4/26/16.
 */

'use strict';

class StudentRepository {


    constructor() {
        this.utils = require('./Utils');
    }

    getParents() {
        return new Promise((resolve, reject) => {
            this.utils.readJsonFile('./data/student.json').then(parents => {
                resolve(parents);
            }).catch(err => {
                reject(err);
            });
        });
    }

    fetchParent(qatariId) {
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {
                parents = parents.filter(s => s.qatariId === qatariId);
                if (parents.length > 0) {
                    resolve(parents[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    fetchParentByUsername(username) {
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {
                parents = parents.filter(t => t.username === username);
                if (parents.length > 0) {
                    resolve(parents[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    //
    //fetchStudentsByUsername(username) {
    //    return new Promise((resolve, reject) => {
    //        this.getParents().then(parents => {
    //            parents = parents.filter(t => t.username === username);
    //            if (parents.length > 0) {
    //                return(parents);
    //            }
    //            else {
    //                reject("No records found");
    //            }
    //        }).then(parent => {
    //
    //        }).catch(err => {
    //            reject(err);
    //        });
    //    });
    //}

    getStudents() {
        return new Promise((resolve, reject) => {
            this.utils.readJsonFile('./data/student.json').then(students => {
                let studentArrays = students.map(s => {
                    return s.students;
                });

                students = [].concat(...studentArrays);
                resolve(students);
            }).catch(err => {
                reject(err);
            });
        });
    }

    fetchStudent(studentId) {
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                students = students.filter(s => s.studentId === studentId);
                if (students.length > 0) {
                    resolve(students[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    fetchParentStudents(qatariId) {
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {
                parents = parents.filter(p => p.qatariId === qatariId);
                if (parents.length > 0) {
                    let students = parents[0].students;
                    resolve(students);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    //addParent(parent) {
    //    return new Promise((resolve, reject) => {
    //        this.getParents().then(parents => {
    //            parents.push(parent);
    //            return this.writeJsonFile('./data/student.json', parents);
    //        }).then(() => {
    //            resolve(parent);
    //        }).catch(err => reject(err));
    //    });
    //}

    addParent(parent) {
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                let studentId = students[students.length - 1].studentId + 1;
                parent.students[parent.students.length - 1].studentId = studentId;
                return this.getParents();
            }).then(parents => {
                parent.qatariId = parseInt(parent.qatariId);
                parents.push(parent);
                return this.utils.writeJsonFile('./data/student.json', parents);
            }).then(() => {
                resolve(parent);
            }).catch(err => reject(err));
        });
    }

    updateParent(parent) {
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                let studentId = students[students.length - 1].studentId + 1;
                parent.students[parent.students.length - 1].studentId = studentId;
                return this.getParents();
            }).then(parents => {
                let len = parents.length;
                for (let i = 0; i < len; i++) {
                    if (parents[i].qatariId == parent.qatariId) {
                        parents[i] = parent;
                        break;
                    }
                }
                return this.utils.writeJsonFile('./data/student.json', parents);
            }).then(()=> resolve())
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    getTeacherStudents(staffNo) {
        return new Promise((resolve, reject) => {
            this.getStudents().then(students => {
                students = students.filter(s => s.teacherStaffNo === staffNo);
                resolve(students);
            }).catch(err => {
                reject("No records found");
            });
        });
    }

}

module.exports = new StudentRepository();