'use strict'

$(document).ready(function () {

    getStudents().then(students => fillStudentsDD(students))
        .catch(err => console.log(err));

    $("#studentDD").on('change', onStatusChange);


});

function getStudents() {
    let url = "http://localhost:9080/students";
    return fetch(url).then(response => response.json());
}

function onStatusChange() {
    $('#tasks-list').empty();

    let selectedStudentId = $(this).val();

    fetchTasksById(selectedStudentId).then(tasks => {
        displayTasks(tasks);
    }).catch(err => console.log(err));
}

function displayTasks(task) {
    let htmlTemplate = $('#tasks-template').html(),
        tasksTemplate = Handlebars.compile(htmlTemplate)

    $('#tasks-list').html(tasksTemplate({task}));

}

function fetchTasksById(studentId) {
    let url = `http://localhost:9080/tasks/student/${studentId}`;
    return fetch(url).then(response => response.json());
}

function fillStudentsDD(students) {
    for (let student of students) {
        $("<option>", {
            value: student.studentId,
            text: `${student.firstName} ${student.lastName}`

        }).appendTo($("#studentDD"))
    }
}