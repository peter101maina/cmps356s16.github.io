$(document).ready(function () {

    hideAll();

    getParents().then(parents => fillParentsDD(parents))
        .catch(err => console.log(err));

    getTeachers().then(teachers => fillHalaqaDD(teachers))
        .catch(err => console.log(err));

});


function fillParentsDD(parents) {
    for (let parent of parents) {
        $("<option>", {
            value: parent.qatariId,
            text: `${parent.firstName}  ${parent.lastName}`
        }).appendTo($("#parentsDD"))
    }
}

function getParents() {
    let url = `http://localhost:9080/parents`;
    return fetch(url).then(response => response.json());
}

function fillHalaqaDD(teachers) {
    for (let teacher of teachers) {
        $("<option>", {
            value: teacher.staffNo,
            text: `${teacher.halaqa}  ${teacher.firstName}`
        }).appendTo($("#halaqasDD"))
    }
}

function getTeachers() {
    let url = `http://localhost:9080/teachers`;
    return fetch(url).then(response => response.json());
}


function enableSelect() {
    let select = document.getElementById("parentSelect");
    select.style.display = 'block';
    let info = document.getElementById("parentInfo");
    info.style.display = 'none';
}

function hideAll() {
    let select = document.getElementById("parentSelect");
    select.style.display = 'none';
    let info = document.getElementById("parentInfo");
    info.style.display = 'none';
}


function enableInfo() {
    let select = document.getElementById("parentSelect");
    select.style.display = 'none';
    let info = document.getElementById("parentInfo");
    info.style.display = 'block';
}


function submitForm() {
    let task_type;
    if (document.getElementById('exist').checked) {
        //task_type = document.getElementById('exist').value;
        updateParent();
    }
    else {
        //task_type = document.getElementById('new').value;
        //alert("hello");
        AddParent();

    }


}

function AddParent() {
    //alert("hello");
    let teacherStaffNo = parseInt($('#halaqasDD').val());
    let gender;
    if (document.getElementById('male').checked) {
        gender = document.getElementById('male').value;
    }
    else {
        gender = document.getElementById('female').value;
    }

    let parent = {
        "qatariId": parseInt($('#qatariId').val()),
        "firstName": $('#firstName').val(),
        "lastName": $('#lastName').val(),
        "mobile": $('#mobile').val(),
        "email": $('#email').val(),
        "username": $('#username').val(),
        "password": $('#password').val(),
        "students": [
            {
                "firstName": $('#firstName_s').val(),
                "lastName": $('#lastName_s').val(),
                "dob": $('#dob').val(),
                "gender": gender,
                "schoolGrade": parseInt($('#schoolGrade').val()),
                "teacherStaffNo": teacherStaffNo,
                "parentId": parseInt($('#qatariId').val())
            }
        ]
    };


    let url = "http://localhost:9080/parents";
    let requestMethod = "post";


    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(parent)
    }).then(() => {
        alert("Parent and Student are added Successfully");
        location.reload();
    });
}


function AddToParent(student) {
    let e = document.getElementById("parentsDD");
    let qatariId = e.options[e.selectedIndex].value;
    //alert(qatariId);
    fetchParent(qatariId).then(parent => {
        parent.students.push(student);
        let url = "http://localhost:9080/parents/";
        let requestMethod = "put";
        //parent.qatariId = parseInt(qatariId);
        url += qatariId;


        return fetch(url, {
            method: requestMethod,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(parent)
        });
    }).then(() => {
        alert("Student is added Successfully");
        location.reload();


    });
}

function fetchParent(qatariId) {
    let url = `http://localhost:9080/parents/${qatariId}`;
    return fetch(url).then(response => response.json());
}

function updateParent() {
    //alert("hello");

    let gender;
    if (document.getElementById('male').checked) {
        gender = document.getElementById('male').value;
    }
    else {
        gender = document.getElementById('female').value;
    }
    let teacherStaffNo = parseInt($('#halaqasDD').val());

    let student =
    {
        "firstName": $('#firstName_s').val(),
        "lastName": $('#lastName_s').val(),
        "dob": $('#dob').val(),
        "gender": gender,
        "schoolGrade": parseInt($('#schoolGrade').val()),
        "teacherStaffNo": teacherStaffNo
    };

    AddToParent(student);

}

//let task = {
//    surahId: $('#surahDD').val(),
//    surahName: $('#surahDD').find('option:selected').text(),
//    studentId: $('#studentDD').val(),
//    fromAya: $('#fromAya').val(),
//    toAya: $('#toAya').val(),
//    type:task_type,
//    dueDate: $('#dueDate').val(),
//    //completedDate: $('#completedDate').val()
//};
//
//let url = "http://http://localhost:9080/students";
//let requestMethod = "post";
//
//
//
////console.log("saveTask.heroId", heroId);
//
//fetch(url, {
//    method: requestMethod,
//    headers: {
//        "Content-Type": "application/json"
//    },
//    body: JSON.stringify(task)
//}).then(() => {
//    //After add/update then refresh the list
//    getPTasks();
//
//
//}