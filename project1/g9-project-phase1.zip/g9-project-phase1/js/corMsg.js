'use strict'

$(document).ready(function () {

    getStudents().then(students => fillStudentsDD(students))
        .catch(err => console.log(err));

    $("#studentDD").on('change', onStatusChange);


});

function getStudents() {
    let url = "http://localhost:9080/students";
    return fetch(url).then(response => response.json());
}

function onStatusChange() {
    $('#message-list').empty();

    let selectedStudentId = $(this).val();

    fetchMessageById(selectedStudentId).then(tasks => {
        displayTasks(tasks);
    }).catch(err => console.log(err));
}

function displayTasks(msg) {
    let htmlTemplate = $('#messages-template').html(),
        tasksTemplate = Handlebars.compile(htmlTemplate)

    $('#message-list').html(tasksTemplate({msg}));

}

function fetchMessageById(studentId) {
    let url = `http://localhost:9080/students/messages/${studentId}`;
    return fetch(url).then(response => response.json());
}

function fillStudentsDD(students) {
    for (let student of students) {
        $("<option>", {
            value: student.studentId,
            text: `${student.firstName} ${student.lastName}`

        }).appendTo($("#studentDD"))
    }
}