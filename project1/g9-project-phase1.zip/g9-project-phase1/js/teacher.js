'use strict'

let teacherStaffNo;

$(document).ready(function () {

    let user = JSON.parse(localStorage.user);


    getStaffByUsername(user.username).then(staff => {
        teacherStaffNo = staff.staffNo;
        getPTasks(staff.staffNo);
    })


    $("#requestStatus").on('change', onStatusChange);
    $('#tasks-list').on('click', 'a.deleteButton', deleteTask);


});
function getPTasks() {
    //Empty the request-details div
    $('#tasks-list').empty();

    fetchPTasks(teacherStaffNo).then(task => displayPTasks(task))
        .catch(err => console.log(err));
}

function displayTasks(task) {
    let htmlTemplate = $('#tasks-template').html(),
        tasksTemplate = Handlebars.compile(htmlTemplate)

    $('#tasks-list').html(tasksTemplate({task}));

}


function displayPTasks(task) {
    let htmlTemplate = $('#tasksP-template').html(),
        tasksTemplate = Handlebars.compile(htmlTemplate)

    $('#tasks-list').html(tasksTemplate({task}));

}

function onStatusChange() {
    $('#tasks-list').empty();

    let selectedStatus = $(this).val();

    if (selectedStatus == "Pending") { //waiting
        fetchPTasks().then(task => displayPTasks(task))
            .catch(err => console.log(err));
    } else if (selectedStatus == "Completed") {
        fetchCTasks().then(task => displayTasks(task))
            .catch(err => console.log(err));
    }
}


function addTask() {
    let htmlTemplate = $('#task-form-template').html(),
        taskTemplate = Handlebars.compile(htmlTemplate);

    $('#task-form').html(taskTemplate({}));
    showFormAsModel("save", null);
}

function showFormAsModel(type, task) {

    let today = new Date();
    let tomm = new Date();
    let dd = today.getDate();
    let dt = today.getDate() + 1;
    let mm = today.getMonth() + 1; //January is 0!

    let yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd
    }
    if (mm < 10) {
        mm = '0' + mm
    }
    today = yyyy + '-' + mm + '-' + dd;
    tomm = yyyy + '-' + mm + '-' + dt;

    if (type == "save") {
        $("#dueDate").attr('value', tomm);
    }


    $("#completedDate").attr('value', today);


    getSurahs().then(surahs => fillSurahDD(surahs))
        .catch(err => console.log(err));

    getStudents().then(students => fillStudentsDD(students))
        .catch(err => console.log(err));


    if (type == "update") {
        document.getElementById("selectedValue").value = task.fromAya;
        document.getElementById("selectedValue2").value = task.toAya;

        let task_type = task.type;
        if (task_type == "Memorization") {
            $('#Memorization').prop('checked', true);
            //alert("memo";)
        } else {
            $('#Revision').prop('checked', true);
        }
    }


    let taskForm = $("#task-form").dialog({
        height: 550,
        width: 750,
        title: 'Task Form',
        modal: true,
        buttons: {
            "Submit": function () {
                if (type == "save" || type == "update") {
                    saveTask();
                    taskForm.dialog("close");
                }
                else {
                    let comp = document.getElementById('completedDate').value;
                    //alert(comp);
                    if (task.dueDate <= comp) {
                        complete(task);
                        taskForm.dialog("close");
                    } else {
                        alert("Completed date should be after due date")
                    }

                }

            },
            Cancel: function () {
                taskForm.dialog("close");
            }
        }
    });
}


function saveTask() {
    let task_type;
    if (document.getElementById('Memorization').checked) {
        task_type = document.getElementById('Memorization').value;
    }
    else {
        task_type = document.getElementById('Revision').value;
    }


    let task = {
        surahId: parseInt($('#surahDD').val()),
        surahName: $('#surahDD option:selected').text(),
        studentId: parseInt($('#studentDD').val()),
        studentName: $('#studentDD option:selected').text(),
        fromAya: parseInt($('#selectedValue').text()),
        toAya: parseInt($('#selectedValue2').text()),
        type: task_type,
        dueDate: $('#dueDate').val(),
        teacherStaffNo: teacherStaffNo
        //completedDate: $('#completedDate').val()
    };

    let url = "http://localhost:9080/tasks/";
    let requestMethod = "post";

    let taskId = $('#taskId').val();
    //In case of update make the method put and append the id to the Url
    if (taskId != '') {
        task.taskId = parseInt(taskId);
        url += taskId;
        requestMethod = "put";
    }

    //console.log("saveTask.heroId", heroId);

    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(task)
    }).then(() => {
        //After add/update then refresh the list
        $("#requestStatus").val("Pending");
        getPTasks();
    });
}

function complete(task) {
    //alert("hello");
    let taskId = parseInt($('#CtaskId').val());
    let completedDate = $('#completedDate').val();
    let masteryLevel = $('#masteryLevel').val();
    let comment = $('#comment').val();

    //alert("completedDate =" + completedDate +" masteryLevel= "+masteryLevel);


    task.completedDate = completedDate;
    task.masteryLevel = masteryLevel;
    task.comment = comment;

    //alert("type =" + comptask.type );

    let url = "http://localhost:9080/tasks/";
    let requestMethod = "put";
    url += taskId;
    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(task)
    }).then(() => {
        //After add/update then refresh the list
        getPTasks();
    });

    //alert("complete");
}
function fillSurahDD(surahs) {


    for (let surah of surahs) {
        $("<option>", {
            value: surah.id,
            text: surah.englishName

        }).appendTo($("#surahDD"))
    }
}

function fillStudentsDD(students) {
    getTeacherStudents(teacherStaffNo).then(students => {

        for (let student of students) {
            $("<option>", {
                value: student.studentId,
                text: `${student.firstName} ${student.lastName}`
            }).appendTo($("#studentDD"))
        }

    })
}


function updateTask(taskId) {
    console.log("taskId", taskId);
    fetchTask(taskId).then(task => {
        console.log(task);

        let htmlTemplate = $('#task-form-template').html(),
            heroTemplate = Handlebars.compile(htmlTemplate);


        $('#task-form').html(heroTemplate(task));
        showFormAsModel("update", task);

    }).catch(err => console.log(err));
}

//completeTask({{taskId}})


function deleteTask(event) {
    //Prevent the default browser behavior when a link is clicked
    event.preventDefault();

    // Ask the user to confirm. If they cancel the request then exit this function
    if (!confirm('Confirm delete?')) {
        return;
    }

    //Get the data-heroId custom attribute associated with the clicked Link
    //Note this refers to the link that was clicked (i.e., the source of the click event)
    let taskId = $(this).attr('data-taskId');
    console.log(taskId);

    let url = `http://localhost:9080/tasks/${taskId}`;
    fetch(url, {method: 'delete'}).then(() => {
        //After successful delete remove the row from the HTML table
        $(this).closest('tr').remove();
    }).then(() => {
        //After delete then refresh the list
        getPTasks();
    });
}


function completeTask(taskId) {
    console.log("taskId", taskId);
    fetchTask(taskId).then(task => {
        console.log(task);

        let htmlTemplate = $('#CompleteTask-form-template').html(),
            heroTemplate = Handlebars.compile(htmlTemplate);

        $('#task-form').html(heroTemplate(task));
        showFormAsModel("complete", task);

    }).catch(err => console.log(err));
}

function getSurah(surahId) {
    let url = `http://localhost:9080/surahs/${surahId}`;
    return fetch(url).then(response => response.json());
}

function onSurahChange() {
    //alert($("#surahDD option:selected").val());
    let val = $("#surahDD option:selected").val();
    getSurah(val).then(surah => {
        var slider = document.getElementById("fromAya");
        slider.setAttribute("max", surah.ayaCount);
        document.getElementById("selectedValue").value = 1;

        var slider2 = document.getElementById("toAya");
        slider2.setAttribute("max", surah.ayaCount);
        document.getElementById("selectedValue2").value = 1;
        //alert(surah.ayaCount)

    }).catch(err => console.log(err));
}

function OnSliderChanged(slider) {
    var slider2 = document.getElementById("toAya");
    var selected = document.getElementById("selectedValue").value;
    //alert(selected);
    slider2.setAttribute("min", selected);
    document.getElementById("selectedValue2").value = selected;
}

function getSurahs() {
    let url = "http://localhost:9080/surahs";
    return fetch(url).then(response => response.json());
}

function getStaffByUsername(username) {
    let url = `http://localhost:9080/staff/username/${username}`;
    return fetch(url).then(response => response.json());
}

function getStudents() {
    let url = "http://localhost:9080/students";
    return fetch(url).then(response => response.json());
}

function fetchPTasks() {
    let url = `http://localhost:9080/tasks/pending/${teacherStaffNo}`;
    return fetch(url).then(response => response.json());
}

function fetchCTasks() {
    let url = `http://localhost:9080/tasks/completed/${teacherStaffNo}`;
    return fetch(url).then(response => response.json());
}

function fetchTask(taskId) {
    let url = `http://localhost:9080/tasks/${taskId}`;
    return fetch(url).then(response => response.json());
}

function getTeacherStudents(staffNo) {
    let url = `http://localhost:9080/teachers/students/${staffNo}`;
    return fetch(url).then(response => response.json());
}