$(document).ready(function () {

    $('#send').on('click', sendAnnouncement);

    $('#upload').click(f => {
        setTimeout(function () {
            $('#uploadNotDone').attr({
                "class": "label label-success"
            });

            $('#uploadNotDone').text('Upload Complete!');

        }, 2000);

        $('#uploadNotDone').attr({
            "style": "visibility : visible"
        });

    });

});

function sendAnnouncement() {
    let announcement = {
        subject: $('#subject').val(),
        message: $('#message').val(),
        attachment: $('#attachment').val(),
        imageURL: "",
        type: "announcement"
    }

    console.log(announcement.attachment);

    let url = "http://localhost:9080/messages/";
    let requestMethod = "post";

    fetch(url, {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(announcement)
    }).then(() => {
        //After add/update then refresh the list
        //alert("Message Sent!");
        window.location.href = "http://localhost:9080/announcement.html"
    });

    alert("Announcement Sent!");
    window.location.href = "announcement.html"
}