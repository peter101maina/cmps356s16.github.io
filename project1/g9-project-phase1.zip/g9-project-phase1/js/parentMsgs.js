/**
 * Created by sarahalhussaini on 4/28/16.
 */

$(document).ready(function () {

    let user = JSON.parse(localStorage.user);

    let msgArray;

    getParentByUsername(user.username).then(parent => {
        return getParentMessages(parent.qatariId);
    }).then(msgs => {
        msgArray = msgs;
        return getAnnouncement();
    }).then(ann => {
        for (let i = 0; i < ann.length; i++) {
            msgArray.push(ann[i]);
        }
        console.log(msgArray);
        $('#msgsNo').text(msgArray.length);
        displayMessages(msgArray);
    })

});

function displayMessages(msg) {

    let htmlTemplate = $('#tasks-template').html(),
        tasksTemplate = Handlebars.compile(htmlTemplate)

    $('#message-list').html(tasksTemplate({msg}));

}

function getParentByUsername(username) {
    let url = `http://localhost:9080/parents/username/${username}`;
    return fetch(url).then(response => response.json());
}

function getParentMessages(parentId) {
    let url = `http://localhost:9080/parents/messages/${parentId}`;
    return fetch(url).then(response => response.json());
}

function getAnnouncement() {
    let url = `http://localhost:9080/announcements`;
    return fetch(url).then(response => response.json());
}





