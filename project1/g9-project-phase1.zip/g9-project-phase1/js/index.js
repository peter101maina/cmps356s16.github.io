'use strict'

$(document).ready(function () {

    $('#login').on('click', redirect);
});

function redirect(event) {

    event.preventDefault();

    let userInfo = {
        username: $('#username').val(),
        password: $('#password').val(),
    };

    let url = "http://localhost:9080/";

    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(userInfo)
    }).then(response => response.json())
        .then(user => {
            console.log("Redirect to:", user.redirectTo);
            //store the userInfo in the localStorage so it is available to other pages
            localStorage.user = JSON.stringify(user);

            verifyUser(user).then(isCorrect => {

                console.log(isCorrect);

                if (isCorrect == true)
                    window.location = user.redirectTo;
                else
                    alert("Incorrect password");

            }).catch(err => alert("User doesn't exist"));
        });


}

function verifyUser(userInfo) {

    return new Promise((resolve, reject) => {

        if (userInfo.redirectTo === '/teacher.html') {
            getStaffByUsername(userInfo.username).then(staff => {

                let isCorrect = false;

                if (staff.password == userInfo.password)
                    isCorrect = true;

                resolve(isCorrect);
            }).catch(err =>
                alert("Staff doesn't exist " + err)
            );
        }
        else if (userInfo.redirectTo == '/coordinator.html') {
            getStaffByUsername(userInfo.username).then(staff => {

                let isCorrect = false;

                if (staff.password == userInfo.password)
                    isCorrect = true;

                resolve(isCorrect);
            }).catch(err =>
                alert("Staff doesn't exist " + err)
            );
        }
        else if (userInfo.redirectTo === '/parent.html') {
            getParentByUsername(userInfo.username).then(parent => {
                let isCorrect = false;

                console.log(parent);

                if (parent.password == userInfo.password) {
                    isCorrect = true;
                    userInfo.qatariId = parent.qatariId;
                    localStorage.user = JSON.stringify(userInfo);
                }


                resolve(isCorrect);
            }).catch(err =>
                alert("User doesn't exist")
            );
        }
        else {
            alert("Access Denied");
        }

    });

}

function getStaffByUsername(username) {
    let url = `http://localhost:9080/staff/username/${username}`;
    return fetch(url).then(response => response.json());
}

function getParentByUsername(username) {
    let url = `http://localhost:9080/parents/username/${username}`;
    return fetch(url).then(response => response.json());
}
