/**
 * Created by sarahalhussaini on 4/25/16.
 */

let teacherStaffNo;

$(document).ready(function () {

    //getParents().then(parents => fillParentsDD(parents))
    //    .catch(err => console.log(err));

    //$('#parentsDD').on('change', fillStudents);

    let user = JSON.parse(localStorage.user);

    getStaffByUsername(user.username).then(staff => {
        teacherStaffNo = staff.staffNo;
        fillStudents();
    })


    $('#send').on('click', sendMessage);
    $('#upload').click(f => {
        setTimeout(function () {
            $('#uploadNotDone').attr({
                "class": "label label-success"
            });

            $('#uploadNotDone').text('Upload Complete!');

        }, 2000);

        $('#uploadNotDone').attr({
            "style": "visibility : visible"
        });

    });

    //$('#send').click( function () {
    //    document.getElementById("form2").submit();
    //    sendMessage();
    //
    // });

});

//function fillParentsDD(parents) {
//
//    for(let parent of parents) {
//        $("<option>", {
//            value: parent.qatariId,
//            text: `${parent.firstName} ${parent.lastName}`
//        }).appendTo($("#parentsDD"))
//    }
//}

function fillStudents() {

    //$('#studentsDD').empty();

    //let parentId = $('#parentsDD').val();
    //
    //console.log(parentId);

    getTeacherStudents(teacherStaffNo).then(students => {

        for (let student of students) {
            $("<option>", {
                value: student.studentId,
                text: `${student.firstName} ${student.lastName}`
            }).appendTo($("#studentsDD"))
        }

    })

}

function sendMessage() {

    let parentId;


    let message = {
        subject: $('#subject').val(),
        message: $('#message').val(),
        //parentId :$('#parentsDD').val(),
        studentId: parseInt($('#studentsDD').val()),
        studentName: $('#studentsDD option:selected').text(),
        parentId: 0,
        imageURL: "",
        type: "message"
    }

    fetchStudent(message.studentId).then(astudent => {
        parentId = astudent.parentId;
        message.parentId = parseInt(parentId);
    }).then(() => {
        console.log(message);

        let url = "http://localhost:9080/messages/";
        let requestMethod = "post";

        fetch(url, {
            method: requestMethod,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(message)
        }).then(() => {
            //After add/update then refresh the list
            //alert("Message Sent!");

            //window.location.href= "http://localhost:9080/messageParent.html"
        });

        alert("Message Sent!");
        window.location.href = "messageParent.html"


    })


}


function getParents() {
    let url = `http://localhost:9080/parents`;
    return fetch(url).then(response => response.json());
}

function getParentStudents(qatariId) {
    let url = `http://localhost:9080/parents/students/${qatariId}`;
    return fetch(url).then(response => response.json());
}

function getTeacherStudents(staffNo) {
    let url = `http://localhost:9080/teachers/students/${staffNo}`;
    return fetch(url).then(response => response.json());
}

function getStaffByUsername(username) {
    let url = `http://localhost:9080/staff/username/${username}`;
    return fetch(url).then(response => response.json());
}

function fetchStudent(studentId) {
    let url = `http://localhost:9080/students/${studentId}`;
    return fetch(url).then(response => response.json());

}


