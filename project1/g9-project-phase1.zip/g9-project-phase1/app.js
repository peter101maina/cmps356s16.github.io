'use strict';

let express = require('express'),
    bodyParser = require('body-parser'),
    fs = require('fs'),
//multer is a package used to ease uploading files
    multer = require('multer'),
    path = require('path'),
//node-uuid is a package to generate a unique identifier
    uuid = require('node-uuid');

let imgUrl;

let options = multer.diskStorage(
    {
        destination: 'uploads/',
        filename: function (req, file, cb) {
            let fileName = uuid.v1() + path.extname(file.originalname);
            cb(null, fileName);
        }
    });

let app = express();
app.use(express.static(__dirname));

let port = 9080;

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

let tasksController = require('./TasksController.js');
let studentController = require('./StudentController.js');
let surahRepository = require('./SurahRepository.js');
let staffRepository = require('./StaffRepository.js');
let messageRepository = require('./MessageRepository.js');

app.listen(port, function () {
    console.log("Server is listening @ http://localhost:" + port);
});

app.post('/', (req, res) => {
    let userInfo = req.body;
    console.log("app.post.req.body", userInfo);

    if (userInfo.username.startsWith("teacher")) {
        userInfo.redirectTo = '/teacher.html';
        res.json(userInfo);
    }
    else if (userInfo.username.startsWith("coordinator")) {
        userInfo.redirectTo = '/coordinator.html';
        res.json(userInfo);
    }
    else {
        userInfo.redirectTo = '/parent.html';
        res.json(userInfo);
    }

});

app.get('/surahs', (req, res) => {
    surahRepository.getSurahs().then(surahs => {
        res.json(surahs);
    });
});

app.get('/surahs/:id', (req, res) => {
    let id = req.params.id;
    console.log('req.params.id', id);
    surahRepository.fetchSurah(parseInt(id)).then(surah => {
        console.log(JSON.stringify(surah, null, 2));
        res.json(surah);
    }).catch(err => {
        res.send("Failed :" + err);
    });
});

app.get('/parents', (req, res) => studentController.getAllParents(req, res));
app.get('/parents/:qatariId', (req, res) => studentController.fetchParent(req, res));
app.get('/parents/username/:username', (req, res) => studentController.fetchParentByUsername(req, res));
app.get('/students', (req, res) => studentController.getAllStudents(req, res));
app.get('/students/:studentId', (req, res) => studentController.fetchStudent(req, res));
app.get('/parents/students/:qatariId', (req, res) => studentController.fetchParentStudents(req, res));
app.post('/parents', (req, res) => studentController.addParent(req, res));
app.put('/parents/:qatariId', (req, res) => studentController.updateParent(req, res));

app.get('/tasks', (req, res) => tasksController.getAllTasks(req, res));
app.get('/tasks/completed/:teacherStaffNo', (req, res) => tasksController.getCompletedTasks(req, res));
app.get('/tasks/pending/:teacherStaffNo', (req, res) => tasksController.getPendingTasks(req, res));
app.get('/tasks/:taskId', (req, res) => tasksController.fetchTask(req, res));
app.get('/tasks/student/:studentId', (req, res) => tasksController.getStudentTasks(req, res));
app.delete('/tasks/:taskId', (req, res) => tasksController.deleteTask(req, res));
app.post('/tasks', (req, res) => tasksController.addTask(req, res));
app.put('/tasks/:taskId', (req, res) => tasksController.updateTask(req, res));


app.get('/staff', (req, res) => {
    staffRepository.getStaff().then(requests => {
        res.json(requests);
    });
});

app.get('/staff/:staffNo', (req, res) => {
    let staffNo = req.params.staffNo;
    console.log('req.params.staffNo', staffNo);
    staffRepository.fetchStaff(parseInt(staffNo)).then(staff => {
        console.log(JSON.stringify(staff, null, 2));
        res.json(staff);
    }).catch(err => {
        res.send("Failed :" + err);
    });
});

app.get('/staff/username/:username', (req, res) => {
    let username = req.params.username;
    console.log('req.params.username', username);
    staffRepository.fetchStaffByUsername(username).then(staff => {
        console.log(JSON.stringify(staff, null, 2));
        res.json(staff);
    }).catch(err => {
        res.send("Failed :" + err);
    });
});

app.get('/coordinators', (req, res) => {
    staffRepository.getCoordinators().then(requests => {
        res.json(requests);
    });
});

app.get('/teachers', (req, res) => {
    staffRepository.getTeachers().then(requests => {
        res.json(requests);
    });
});

app.get('/announcements', (req, res) => {
    messageRepository.getAnnouncements().then(messages => {
        res.json(messages);
    });
});

app.get('/teachers/students/:staffNo', (req, res) => studentController.getTeacherStudents(req, res));
app.get('/parents/messages/:parentId', (req, res) => studentController.fetchParentMessages(req, res));
app.get('/students/messages/:studentId', (req, res) => studentController.fetchStudentMessages(req, res));


app.get('/messages', (req, res) => {
    messageRepository.getMessages().then(messages => {
        res.json(messages);
    });
});

app.get('/messages/:msgId', (req, res) => {
    let msgId = req.params.msgId;
    console.log('req.params.msgId', msgId);
    messageRepository.fetchMessage(parseInt(msgId)).then(msg => {
        console.log(JSON.stringify(msg, null, 2));
        res.json(msg);
    }).catch(err => {
        res.send("Failed :" + err);
    });
});


app.post('/messages', (req, res) => {
    let msg = req.body;
    console.log(msg);
    messageRepository.addMessage(msg, imgUrl).then((newMsg) => {
        console.log(newMsg);
        let location = `/messages/${newMsg.msgId}`;
        res.location(location);
        //res.status(201).send(location);
    }).catch(err => {
        res.status(500).send(err);
        console.log(err);
    });
});

app.post('/uploads', multer({storage: options}).single('msgImage'), (req, res) => {

    console.log("form fields if any", req.body);
    console.log("Uploaded file details", req.file);

    let uploadedFileName = req.file.filename;

    console.log('uploadedFileName', uploadedFileName);

    imgUrl = `http://localhost:${port}/uploads/${uploadedFileName}`;
    console.log('Url of uploaded image', imgUrl);


    //res.redirectTo(imgUrl);

    //messageRepository.addImageURl(imgUrl).then(() => {
    //    //res.status(200).send("imageURL added successfully");
    //});

});

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname, '/upload.html'));
});
