/**
 * Created by sarahalhussaini on 4/30/16.
 */
'use strict'

class TasksController {

    constructor() {
        this.taskRepository = require('./TaskRepository');
    }

    getAllTasks(req, res) {
        this.taskRepository.getTasks().then(tasks => {
            res.json(tasks);
        });
    }

    getCompletedTasks(req, res) {
        let teacherStaffNo = req.params.teacherStaffNo;
        this.taskRepository.getCompletedTasks(teacherStaffNo).then(tasks => {
            res.json(tasks);
        });
    }

    getPendingTasks(req, res) {
        let teacherStaffNo = req.params.teacherStaffNo;
        this.taskRepository.getPendingTasks(teacherStaffNo).then(tasks => {
            res.json(tasks);
        });
    }

    fetchTask(req, res) {
        let taskId = req.params.taskId;
        console.log('req.params.taskId', taskId);
        this.taskRepository.fetchTask(parseInt(taskId)).then(task => {
            console.log(JSON.stringify(task, null, 2));
            res.json(task);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }

    getStudentTasks(req, res) {
        let studentId = req.params.studentId;
        this.taskRepository.fetchTaskByStudentId(parseInt(studentId)).then(task => {
            console.log(JSON.stringify(task, null, 2));
            res.json(task);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }

    deleteTask(req, res) {
        let taskId = req.params.taskId;
        this.taskRepository.deleteTask(taskId).then(() => {
            res.status(200).send("task deleted");
        }).catch(err => {
            res.status(500).send(err);
        });
    }

    addTask(req, res) {
        let task = req.body;
        console.log(task);
        this.taskRepository.addTask(task).then((newTask) => {
            console.log(newTask);
            let location = `/tasks/${newTask.requestId}`;
            res.location(location);
            res.status(201).send(location);
        }).catch(err => {
            res.status(500).send(err);
            console.log(err);
        });
    }

    updateTask(req, res) {
        let task = req.body;
        this.taskRepository.updateTask(task).then(() => {
            res.status(200).send("task updated successfully");
        });
    }

}

module.exports = new TasksController();