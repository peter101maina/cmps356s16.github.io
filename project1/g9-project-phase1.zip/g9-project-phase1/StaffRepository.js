/**
 * Created by sarahalhussaini on 4/26/16.
 */

'use strict';

class StaffRepository{


    constructor() {
        this.utils = require('./Utils');
    }

    getStaff() {
        return new Promise((resolve, reject) => {
            this.utils.readJsonFile('./data/teacher.json').then(staff => {
                staff = staff.map(t => {
                    return {
                        staffNo: t.staffNo,
                        username: t.username,
                        firstName: t.firstName,
                        lastName: t.lastName,
                        email: t.email,
                        password: t.password,
                        isCoordinator: t.isCoordinator,
                        halaqa: t.halaqa
                    }
                });
                resolve(staff);
            }).catch(err => {
                reject(err);
            });
        });
    }

    fetchStaffByUsername(username) {
        return new Promise((resolve, reject) => {
            this.getStaff().then(staff => {
                staff = staff.filter(t => t.username === username);
                if (staff.length > 0) {
                    resolve(staff[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }


    fetchStaff(staffNo) {
        return new Promise((resolve, reject) => {
            this.getStaff().then(staff => {
                staff = staff.filter(t => t.staffNo === staffNo);
                if (staff.length > 0) {
                    resolve(staff[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getCoordinators() {
        return new Promise((resolve, reject) => {
            this.getStaff().then(coordinators => {
                coordinators = coordinators.filter(t => t.halaqa == undefined);
                resolve(coordinators);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getTeachers() {
        return new Promise((resolve, reject) => {
            this.getStaff().then(teachers => {
                teachers = teachers.filter(t => t.isCoordinator == undefined)
                resolve(teachers);
            }).catch(err => {
                reject(err);
            });
        });
    }
}

module.exports = new StaffRepository();