/**
 * Created by sarahalhussaini on 4/26/16.
 */

'use strict';

class MessageRepository {

    constructor() {
        this.utils = require('./Utils');
        this.studentRepo = require('./StudentRepository');
    }

    getMessages() {
        return new Promise((resolve, reject) => {
            this.utils.readJsonFile('./data/message.json').then(messages => {
                messages = messages.map(msg => {
                    return {
                        msgId: msg.msgId,
                        subject: msg.subject,
                        message: msg.message,
                        parentId: msg.parentId,
                        studentId: msg.studentId,
                        studentName: msg.studentName,
                        imageURL: msg.imageURL,
                        type: msg.type
                    }
                });
                resolve(messages);
            }).catch(err => {
                reject(err);
            });
        });
    }

    fetchMessage(msgId) {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                messages = messages.filter(s => s.msgId === msgId);
                if (messages.length > 0) {
                    resolve(messages[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }


    addMessage(message, imgUrl) {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                let msgId = Math.max.apply(Math, messages.map(m => m.msgId)) + 1;
                message.msgId = msgId;
                message.imageURL = imgUrl;
                messages.push(message);
                return this.utils.writeJsonFile('./data/message.json', messages);
            }).then(() => {
                resolve(message);
            }).catch(err => reject(err));
        });
    }

    fetchParentMessages(parentId) {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                messages = messages.filter(s => s.parentId == parentId);
                if (messages.length > 0) {
                    resolve(messages);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    fetchStudentMessages(studentId) {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                messages = messages.filter(s => s.studentId == studentId);
                if (messages.length > 0) {
                    resolve(messages);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }

    getAnnouncements() {
        return new Promise((resolve, reject) => {
            this.getMessages().then(messages => {
                messages = messages.filter(s => s.type == "announcement");
                if (messages.length > 0) {
                    resolve(messages);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }


}

module.exports = new MessageRepository();