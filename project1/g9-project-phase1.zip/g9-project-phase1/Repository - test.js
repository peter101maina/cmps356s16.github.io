'use strict'

//let studentRepository = require('./StudentRepository.js');

//repo.getParents().then(students => {
//    console.log(students);
//});

//repo.getSurahs().then(students => {
//    console.log(students);
//});

//let id = 2;
//repo.fetchSurah(id).then(student => {
//    //Displays a pretty-printed multiline JSON representation indented with 2 spaces
//   console.log(JSON.stringify(student, null, 2));
//});

//repo.fetchParent(34).then (staff => console.log(staff));

//repo.getTasks().then(students => {
//    console.log(students);
//});

//repo.fetchTask(3).then (staff => console.log(staff));

//repo.getStaff().then(students => {
//    console.log(students);
//});

//repo.fetchStaff(501).then (staff => console.log(staff));

let repo = require('./StaffRepository.js');

repo.getTeachers().then(students => {
    console.log(students);
});

//let req = {
//    crn : 2001,
//    studentId : 2015002,
//    reason: "Schedule conflict"
//}
//
//repo.addRequest(req).then (staff => console.log(staff));

//repo.getStudentDetailedRequests(2015002).then( requests => {
//    console.log(requests);
//});

//repo.getTasks().then( tasks => {
//    console.log(tasks);
//});

//repo.getPendingTasks().then( tasks => {
//    console.log(tasks);
//});

//repo.deleteRequest(93).then( requests => {
//    console.log(requests);
//});

//let task=  {
//    "studentId": 8,
//    "surahId": 6,
//    "surahName": "Al-Anaam",
//    "fromAya": 17,
//    "toAya": 21,
//    "type": "Memorization",
//    "dueDate": "3/04/2016"
//};
//
//repo.addTask(task);


//repo.getStudents().then( tasks => {
//    console.log(tasks);
//});
//
//repo.deleteTask(13);
//
//repo.getTasks().then( tasks => {
//    console.log(tasks);
//});

//studentRepository.getParents().then( tasks => {
//    console.log(tasks);
//});

//let parent= {
//    "qatariId": 20,
//    "firstName": "NEW_PARENT",
//    "lastName": "Dahak",
//    "mobile": "7777-888",
//    "email": "juha@test.com",
//    "username": "juha",
//    "password": "password",
//    "students":[
//        {
//            "studentId": 1,
//            "firstName": "Ibn Juha",
//            "lastName": "Dahak",
//            "dob": "1/1/2009",
//            "gender": "M",
//            "schoolGrade": 4
//        },
//        {
//            "studentId": 2,
//            "firstName": "Bint Juha",
//            "lastName": "Dahak",
//            "dob": "1/5/2011",
//            "gender": "F",
//            "schoolGrade": 2
//        }
//    ]
//};
//
//studentRepository.addParent(parent);

//let parent= {
//    "qatariId": 20,
//    "firstName": "Juha",
//    "lastName": "Dahak",
//    "mobile": "7777-888",
//    "email": "juha@test.com",
//    "username": "juha",
//    "password": "password",
//    "students":[
//        {
//            "studentId": 9,
//            "firstName": "Ibn Juha",
//            "lastName": "Dahak",
//            "dob": "1/1/2009",
//            "gender": "M",
//            "schoolGrade": 4
//        },
//        {
//            "studentId": 10,
//            "firstName": "Bint Juha",
//            "lastName": "Dahak",
//            "dob": "1/5/2011",
//            "gender": "F",
//            "schoolGrade": 2
//        },
//        {
//            "firstName": "new",
//            "lastName": "Dahak",
//            "dob": "1/5/2011",
//            "gender": "F",
//            "schoolGrade": 2
//        }
//    ]
//};
//console.log(parent);
//studentRepository.updateParent(parent);

//let taskRepository = require('./TaskRepository.js');
//
//taskRepository.fetchTaskByStudentId(6).then( tasks => {
//    console.log(tasks);
//});

//
//let messageRepository = require('./MessageRepository.js');
//messageRepository.fetchStudentMessages(1).then( tasks => {
//    console.log(tasks);
//
//});

