/**
 * Created by sarahalhussaini on 4/30/16.
 */

'use strict'

class StudentController {

    constructor() {
        this.studentRepository = require('./StudentRepository');
        this.messageRepository = require('./MessageRepository');
    }

    getAllParents(req, res) {
        this.studentRepository.getParents().then(parents => {
            res.json(parents);
        });
    }

    fetchParent(req, res) {
        let qatariId = req.params.qatariId;
        console.log('req.params.qatariId', qatariId);
        this.studentRepository.fetchParent(parseInt(qatariId)).then(parent => {
            console.log(JSON.stringify(parent, null, 2));
            res.json(parent);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }

    fetchParentByUsername(req, res) {
        let username = req.params.username;
        console.log('req.params.username', username);
        this.studentRepository.fetchParentByUsername(username).then(parent => {
            console.log(JSON.stringify(parent, null, 2));
            res.json(parent);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }

    getAllStudents(req, res) {
        this.studentRepository.getStudents().then(students => {
            res.json(students);
        });
    }

    fetchStudent(req, res) {
        let studentId = req.params.studentId;
        console.log('req.params.studentId', studentId);
        this.studentRepository.fetchStudent(parseInt(studentId)).then(student => {
            console.log(JSON.stringify(student, null, 2));
            res.json(student);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }

    fetchParentStudents(req, res) {
        let qatariId = req.params.qatariId;
        console.log('req.params.qatariId', qatariId);
        this.studentRepository.fetchParentStudents(parseInt(qatariId)).then(students => {
            res.json(students);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }

    addParent(req, res) {
        let parent = req.body;
        console.log(parent);
        this.studentRepository.addParent(parent).then((newParent) => {
            console.log(newParent);
            let location = `/parents/${newParent.qatariId}`;
            res.location(location);
            res.status(201).send(location);
        }).catch(err => {
            res.status(500).send(err);
            console.log(err);
        });
    }

    updateParent(req, res) {
        let parent = req.body;
        this.studentRepository.updateParent(parent).then(() => {
            res.status(200).send("parent updated successfully");
        });
    }

    fetchParentMessages(req, res) {
        let parentId = req.params.parentId;
        this.messageRepository.fetchParentMessages(parseInt(parentId)).then(messages => {
            res.json(messages);
        });
    }

    fetchStudentMessages(req, res) {
        let studentId = req.params.studentId;
        this.messageRepository.fetchStudentMessages(parseInt(studentId)).then(messages => {
            res.json(messages);
        });
    }

    getTeacherStudents(req, res) {
        let staffNo = req.params.staffNo;
        console.log('req.params.staffNo', staffNo);
        this.studentRepository.getTeacherStudents(parseInt(staffNo)).then(students => {
            console.log(JSON.stringify(students, null, 2));
            res.json(students);
        }).catch(err => {
            res.send("Failed :" + err);
        });
    }

}

module.exports = new StudentController();