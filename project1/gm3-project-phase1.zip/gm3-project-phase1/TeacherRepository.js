/**
 * Created by Fahad on 4/22/2016.
 */
'use strict'
class TeacherRepository {
    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Not Found:" + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    /**
     writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }
     */


    getTeachers() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(teachers => {
                resolve(teachers);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getTeacherByUser(username) {
        return new Promise((resolve, reject) => {
            this.getTeachers().then(teachers => {
                teachers = teachers.filter(t => t.username === username);
                if (teachers.length > 0) {
                    resolve(teachers[0]);
                }
                else {
                    reject("Not Found:");
                }
            });
        });
    }


         authenticate(user, password){
             return new Promise((resolve, reject) => {
                 this.getTeachers().then(teachers => {
                     teachers = teachers.filter(t => t.username === user && t.password == password);
                     if (teachers.length > 0) {
                         resolve(teachers[0]);
                     }
                     else {
                         reject("Not Found:");
                     }
                 });
             });
}

}
module.exports= new TeacherRepository();