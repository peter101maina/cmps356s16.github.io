/**
 * Created by Fahad on 4/23/2016.
 */
'use strict'
class StudentRepository {
    constructor() {
        this.fs = require('fs');
    }
    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }
    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }
    getParents() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(t => {
                resolve(t);
            }).catch(err => {
                reject(err);
            });
        });
    }
    getParentByUser(username) {
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {
                parents = parents.filter(p => p.username === username);
                if (parents.length > 0) {
                    resolve(parents[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getStudents(){
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {
                let students=[];
                for(var i=0;i<parents.length;i++){
                    for(var j=0;j<parents[i].students.length;j++)
                    {
                        students.push(parents[i].students[j]);}
                }
                if (students.length > 0) {
                    resolve(students);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getStudentOfParent(username){
        return new Promise((resolve, reject) => {
            this.getParentByUN(username).then(parent => {
                let students = parent.students;
                if (students.length > 0) {
                    resolve(students);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }


    authenticate(user, password){
        return new Promise((resolve, reject) => {
            this.getParents().then(parents => {
                parents = parents.filter(t => t.username === user && t.password == password);
                if (parents.length > 0) {
                    resolve(parents[0]);
                }
                else {
                    reject("Not Found:");
                }
            });
        });
    }

}
module.exports= new StudentRepository();