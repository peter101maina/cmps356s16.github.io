/**
 * Created by Fahad on 4/24/2016.
 */
"use strict";
let express = require('express'),
    bodyParser = require('body-parser')

let app = express();
app.use(express.static(__dirname));

let port = 9090;

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());


let studentController = require('./StudentController');
let studentRepository = require('./StudentRepository');
let taskController = require('./TaskController');
let teacherController = require('./TeacherController');
let teacherRepository = require('./TeacherRepository');
let surahController = require('./SurahController');
let messageController = require('./MessageController');
let annoucementController = require('./AnnoucementController');

app.get('/',(req, res) => res.redirect('Home.html') );
app.post('/', (req, res) => {
    let userInfo = req.body;
    console.log(userInfo);
    let count=0;

    studentRepository.getParents().then(parents => {
        for (let i = 0; i < parents.length; i++) {
            if (parents[i].username == userInfo.username && parents[i].password == userInfo.password) {
                userInfo = parents[i];
                count++;
                userInfo.redirectTo = '/Parent.html';
                console.log(userInfo);
                res.json(userInfo);
                break;
            }
        }
    });
    teacherRepository.getTeachers().then(teachers => {
            for (let i = 0; i < teachers.length; i++) {
                console.log(userInfo);

                if (teachers[i].username == userInfo.username && teachers[i].password ==userInfo.password ) {
                    userInfo=teachers[i];
                    count++;
                    if(teachers[i].isCoordinator)

                        userInfo.redirectTo = '/Coordinator.html';
                    else
                        userInfo.redirectTo = '/Instructor.html';

                    console.log(userInfo);
                    res.json(userInfo);
                    break;

                }
                else if(count==0 && i==(teachers.length-1)){
                    res.json(userInfo);
                }
            }
        }
    );
});

app.get('/api/parents', (req, res) => studentController.getParents(req, res));

app.get('/api/tasks', (req, res) => taskController.getTasks(req, res));
app.post('/api/tasks', (req, res) => taskController.addTask(req, res));
app.put('/api/tasks/:taskId', (req, res) => taskController.updateTask(req, res));
app.delete('/api/tasks/:taskId', (req, res) => taskController.deleteTask(req, res));

app.get('/api/tasks/:taskId', (req, res) => taskController.getTask(req, res));

app.get('/api/task/:type', (req, res) => taskController.getTaskByType(req, res));
app.get('/api/t/:studentId', (req, res) => taskController.getTaskByStudentId(req, res));

app.get('/api/t/:studentId/:type', (req, res) => taskController.getTaskByStudentIdType(req, res));
app.get('/api/surahs/:id', (req, res) => surahController.getSurah(req, res));
app.get('/api/surahs', (req, res) => surahController.getSurahs(req, res));
app.get('/api/annoucements', (req, res) => annoucementController.getAnnoucements(req, res));

app.get('/api/annoucements/:aId', (req, res) => annoucementController.getAnnoucement(req, res));
app.get('/api/messages', (req, res) => messageController.getMessages(req, res));
app.get('/api/messages/:messageId', (req, res) => messageController.getMessage(req, res));
app.get('/api/teachers/:username', (req, res) => teacherController.getTeacherByUser(req, res));
app.get('/api/teachers', (req, res) => teacherController.getTechers(req, res));
app.get('/api/students', (req, res) => studentController.getStudents(req, res));
app.get('/api/parentschild/:username', (req, res) => studentController.getStudentOfParent(req, res));

app.get('/api/parents', (req, res) => studentController.getParents(req, res));
app.get('/api/parents/:username', (req, res) => studentController.getParentByUN(req, res));

app.get('/api/surahs', (req, res) => surahController.getSurahs(req, res));


app.listen(port, function(){
    console.log('Students App is running my app on http://localhost:' + port);
});