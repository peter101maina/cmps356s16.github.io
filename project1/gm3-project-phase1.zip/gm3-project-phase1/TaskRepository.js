/**
 * Created by Fahad on 4/22/2016.
 */
'use strict'

class TaskRepository {
    constructor() {
        this.fs = require('fs');
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }



    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }

    getTasks() {
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(t => {
                resolve(t);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getTaskByStudentId(studentId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks = tasks.filter(t => t.studentId === studentId);
                if (tasks.length > 0) {
                    resolve(tasks);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getTaskByType(type) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                if (type=="Completed")
                {tasks = tasks.filter(t => t.completedDate);}
                else
                {tasks = tasks.filter(t => !(t.completedDate));}

                if (tasks.length > 0) {
                    resolve(tasks);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getTaskById(taskId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                tasks= tasks.filter(t => t.taskId === taskId);
                if (tasks.length > 0) {
                    resolve(tasks[0]);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }
    getTaskOfStudentByType(studentId,type) {
        return new Promise((resolve, reject) => {
            this.getTaskByStudentId(studentId).then(tasks => {

                if (type=="Completed")
                {tasks = tasks.filter(t => t.completedDate);}
                else
                {tasks = tasks.filter(t => !(t.completedDate));}
                if (tasks.length > 0) {
                    resolve(tasks);
                }
                else {
                    reject("No records found");
                }
            });
        });
    }


    addTask(task) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                //Get the last Id used +1
                let maxId = Math.max.apply(Math, tasks.map(t => t.taskId)) + 1;
                console.log("maxId", maxId);

                task.taskId = maxId;

                console.log("addTask", task);
                tasks.push(task);
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(()=> resolve(task))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    updateTask(task) {
        console.log( "task to be update is" +JSON.stringify (task));
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                console.log( tasks.length + "task found got from the json file")
                let len = tasks.length;
                for(let i=0; i<len; i++){
                    if (tasks[i].taskId === task.taskId) {
                        console.log("task found and will be updated")
                        tasks[i] = task;
                        break;
                    }
                }
                return this.writeJsonFile('./data/task.json', tasks);
            }).then(()=> resolve())
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    deleteTask(taskId) {
        return new Promise((resolve, reject) => {
            this.getTasks().then(tasks => {
                let len = tasks.length;
                let foundAt = -1;
                for (let i = 0; i < len; i++) {
                    if (tasks[i].taskId == taskId) {
                        foundAt = i;
                        break;
                    }
                }
                if (foundAt >= 0) {
                    tasks.splice(foundAt, 1);
                }
                console.log("task deleted", taskId);

                return this.writeJsonFile('./data/task.json', tasks);
            }).then(() => {
                resolve();
            }).catch(err => {
                reject(err);
            });
        });
    }

}
module.exports= new TaskRepository();