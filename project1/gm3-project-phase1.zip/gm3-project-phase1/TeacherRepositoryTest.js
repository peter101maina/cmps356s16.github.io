/**
 * Created by Fahad on 4/22/2016.
 */
'use strict'
let teacherRep = require('./TeacherRepository.js');

teacherRep.getTeachers().then(teachers=> {
    console.log(teachers);
}).catch(err => console.log(err));



