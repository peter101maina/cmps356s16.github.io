/**
 * Created by Mohammedyasser on 27-Apr-16.
 */
"use strict";
class taskRepository {
    constructor() {
        this.fs = require('fs');
    }

    getSurahs() { //gets all Surahs in username/password format
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/surah.json').then(Surahs => {
                resolve(Surahs);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getSurahByID(id){
        return new Promise ((resolve, reject) =>{
            this.getSurahs().then(surahs =>{
                let surah = surahs.filter(u=> u.id == id);

                if (surah.length>0){
                    resolve(surah[0]);
                }
                else {
                    reject('surah not found');
                }
            })
        });
    }

    getTaskByStudentID(id){
        return new Promise ((resolve, reject) =>{
            this.getTasks().then(task =>{
                let tasks = task.filter(u=> u.studentId == id);
                if (tasks.length>0){
                    resolve(tasks);
                }
                else {
                    reject('tasks not found');
                }
            })
        });
    }

    getTaskById(id){
        return new Promise ((resolve, reject) =>{
           this.getTasks().then(tasks =>{
              let task = tasks.filter(t=> t.taskId == id);
               if(task.length>0)
               resolve(task);
               else
               reject('task not found');
           });
        });
        }

    getTasks() { //gets all Tasks
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/task.json').then(Tasks => {
                resolve(Tasks);
            }).catch(err => {
                reject(err);
            });
        });
    }

    editTask(task){ //Incomplete
        return new Promise((resolve,reject) =>{
           //edit code here
        });
    }


    addTask(task){ //Incomplete
        return new Promise ((resolve,reject) => {
            this.getTasks().then(taskHist => {
                let taskID = 1;
                this.getSurahByID(task.surahId).then(surah => {
                    task.surahName=surah.englishName;
                }).catch(err => reject(err));
                if(taskHist.length>0){
                    taskID = taskHist[taskHist.length-1].taskId+1;
                    task.taskId = taskID;
                }

                task.taskId = taskID;

                taskHist.push(task);
                return this.writeJsonFile('./data/task.json', taskHist)
            }).then (() =>resolve(task)).catch(err => {
                reject(err);
            });

        });
    }




    getTasksByStudents(studentsList){
        return new Promise ((resolve,reject)=>{
            let taskList = new Array();
            this.getTasks().then(allTasks =>{
                for (var s=0; s<studentsList.length; s++){
                    taskList.push(allTasks.filter(t=>t.studentId==studentsList[s].studentId));
                }
                taskList=[].concat.apply([],taskList);
                resolve(taskList);
            }).catch(err => reject(err));
        });
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }
    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }
}

module.exports = new taskRepository();