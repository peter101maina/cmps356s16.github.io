/**
 * Created by Ahmed on 4/25/2016.
 */
    "use strict";
class userRepository {
    constructor() {
        this.fs = require('fs');
    }


     getStudents() { //gets all students in username/password format
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/student.json').then(students => {
                resolve(students);
            }).catch(err => {
                reject(err);
            });
        });
    }
    
     getTeachers() { //gets all teachers in username/password format
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/teacher.json').then(teachers => {
                resolve(teachers);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getAllUsers(){ //gets all users in username/password format
        return new Promise((resolve,reject) =>{
           this.getStudents().then(students =>{
               this.getTeachers().then(teachers =>{

                    let users = teachers.concat(students);
                   resolve(users);
               });
           }).catch(err => {
               reject(err);
           });
        });
    }

    getStudentsByTeacherId(teacherId){
        return new Promise((resolve,reject) =>{
            let studentsList = new Array()
            this.getStudents().then(parents => {
                for (var p=0; p<parents.length; p++){
                    for(var s=0; s<parents[p].students.length; s++){
                        if(parents[p].students[s].teacherId == teacherId){studentsList.push(parents[p].students[s]);}
                    }
                }
                resolve(studentsList);
            }).catch(err => reject(err));
        });
    }

    getUserByUsername(username){
        return new Promise ((resolve, reject) =>{
            this.getAllUsers().then(users =>{
               let user = users.filter(u=> u.username === username);

                if (user.length>0){
                    resolve(user[0]);
                }
                else {
                    reject('username not found');
                }
            })
        });
    }


    addParent(parent) {
        return new Promise((resolve, reject) => {
            this.getStudents().then(parents => {
                console.log("Attempting to add parent: ", parent);
                parents.push(parent);
                return this.writeJsonFile('./data/student.json', parents);
            }).then(()=> resolve(parent))
                .catch(err => {
                    console.log(err);
                    reject(err);
                });
        });
    }

    getAllMessages(){
        return new Promise((resolve, reject) => {
            this.readJsonFile('./data/messages.json').then(messages => {
                resolve(messages);
            }).catch(err => {
                reject(err);
            });
        });
    }

    getMessagesByUser(username){
        return new Promise((resolve,reject) => {
            this.getUserByUsername(username).then(parent => {
                this.getAllMessages().then(allMessages => {
                    let messages = allMessages.filter(m => m.to == parent.username || m.to == 'all');
                    resolve(messages);
                });
            }).catch(err => reject(err));
        });
    }


    getMessagesByID(id){ //get messages by student id
        return new Promise ((resolve,reject) =>{
               this.getStudents().then(parents =>{
                    for (var p=0; p<parents.length; p++){
                        for(var i = 0; i<parents[p].students.length; i++){
                            if(parents[p].students[i].studentId == id){
                                this.getMessagesByUser(parents[p].username).then(messages => resolve(messages));
                                break;
                            }
                        }
                    }
               }).catch(err => reject(err));
           });
    }

    getMassegeByMassegeID(id){
        return new Promise ((resolve,reject) => {
            this.getAllMessages().then(messages =>{
               let message = messages.filter(m => m.id == id)
                if(message.length>0){
                    resolve(message[0]);
                }
                else {
                    reject('no messages found');
                }
            });
        });
    }

    sendMessage(message){
        return new Promise ((resolve,reject) => {
            this.getAllMessages().then(messageHist => {
                let msgID = 1;
                if(messageHist.length>0){
                    msgID = messageHist[messageHist.length-1].id+1;
                    message.id = msgID;
                }

                message.id = msgID;

                messageHist.push(message);
                return this.writeJsonFile('./data/messages.json', messageHist)
            }).then (() =>resolve(message)).catch(err => {
            reject(err);
        });

        });
    }

    readJsonFile(filePath) {
        return new Promise((resolve, reject) => {
            this.fs.readFile(filePath, (error, data) => {
                if (error) {
                    reject("Reading file failed: " + error);
                }
                else {
                    let json = JSON.parse(data);
                    resolve(json);
                }
            });
        });
    }

    writeJsonFile(filePath, data) {
        return new Promise((resolve, reject) => {
            this.fs.writeFile(filePath, JSON.stringify(data), error => {
                if (error) {
                    reject("Write to file failed: " + error);
                }
                else {
                    resolve();
                }
            });
        });
    }


}

module.exports = new userRepository();
