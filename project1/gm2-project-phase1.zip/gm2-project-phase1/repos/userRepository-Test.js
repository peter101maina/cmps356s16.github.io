'use strict';
let userRepository = require('./userRepository');

userRepository.getStudents().then(students => {
    console.log('get student users test: ')
    console.log(students);
    console.log("-----------------------------------------------------------------------------------------------------------");

});


userRepository.getTeachers().then(teachers =>{
    console.log('get teacher users test:')
    console.log(teachers);
    console.log("-----------------------------------------------------------------------------------------------------------");

});

userRepository.getAllUsers().then(users =>{
    console.log('get all users test: ')
   console.log(users);
    console.log("-----------------------------------------------------------------------------------------------------------");

});

userRepository.getUserByUsername('juha').then(user=> {
    console.log('get a particular user test: ')
    console.log(user);
    console.log("-----------------------------------------------------------------------------------------------------------");

});

userRepository.getUserByUsername('Adham').then(user=> {
    console.log(user);
}).catch(err => {
    console.log('get a unknown user test: ')
    console.log(err);
    console.log("-----------------------------------------------------------------------------------------------------------");
});





