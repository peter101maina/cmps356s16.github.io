/**
 * Created by Ahmed on 4/28/2016.
 */
$(document).ready(function(){
   // $("#studentDD").on('change', onStudentChange);
    $('#btnSendMsg').on('click', sendMessege );
    $('#btnAdd').on('click', taskDialog );
    let user = JSON.parse(localStorage.user);
    console.log(user.username + " is now logged in");
    $('#loggedInAs').html('logged in as ' + user.username);
    //getParents().then(parents => fillStudentsDD(parents)).catch(err => console.log(err));
    console.log(user);
    getCurrentUser(user).then(u=>
    getTasks(u).then(tasks => {
        displayTasks(tasks);
    })).catch(err => console.log(err));
    getParents().then(parents => fillStudentsDD(parents)).catch(err => console.log(err));
    getParents().then(parents => fillParentsDD(parents)).catch(err => console.log(err));
    getSurahs().then(surahs => fillSurahsDD(surahs)).catch(err => console.log(err));

    $("#FromAya").prop({max:7});
    $("#ToAya").prop({max:7});
    $("#surah").on('change', onSurahChange);
    $("#FromAya").on('change', fromAyaChange);

    var date = new Date();
    date.setDate(date.getDate() + 1);//today date plus 1
    $('#Due').prop({value :formattedDate(date)});
    $('#Completed').prop({value :formattedDate(Date())});

});


function getSurahs() {
    let url = "http://localhost:9090/api/surahs";
    return fetch(url).then(response => response.json());
}

function getSelectedSurah(id){
    let url = "http://localhost:9090/api/surahs/"+id;
    return fetch(url).then(response => response.json());
}

function fillSurahsDD(surahs) {
    for (let surah of surahs) {
        $("<option>", {
            value: surah.id,
            text: surah.id+". "+ surah.englishName+" ("+surah.ayaCount+" Aya)"
        }).appendTo($("#surah"))
    }
}

function onSurahChange() {
    let selectedSurah = $(this).val();
    getSelectedSurah(selectedSurah).then(surah => {
        $("#FromAya").prop({value:1});
        $("#ToAya").prop({value:1});
        $("#FromAya").prop({max:surah.ayaCount});
        $("#ToAya").prop({max:surah.ayaCount});
    }).catch(err => console.log(err));
}

function fromAyaChange() {
    $("#ToAya").prop({min:$("#FromAya").val()});
}

function fillParentsDD(parents) {
    for(let parent of parents) {
        let parentName = parent.firstName+ " " + parent.lastName;
        $("<option>", {
            value: parent.username,
            text: parentName
        }).appendTo($("#parentDD"))

    }
}
function fillStudentsDD(parents) {
    for(let parent of parents) {
        for(var i =0; i<parent.students.length; i++) {
            let student = parent.students[i];
            let studentName = student.firstName + " " + student.lastName;
            $("<option>", {
                value: student.studentId,
                text: studentName
            }).appendTo($("#studentDD"))
        }
    }
}
function sendMessege(event){

    event.preventDefault();

    let messege = $('#messegeBody').val();
    let reciever= $('#parentDD').val();
    let url = 'http://localhost:9090/api/messages';

    let currentUser = JSON.parse(localStorage.user);

    let message = {
        content: messege,
        from: currentUser.username,
        to: reciever,
        date: formattedDate(new Date())
    };

    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(message)
    }).then(res => {
        console.log(res);
    })

}
function formattedDate(date) {
    var d = new Date(date || Date.now()),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [day, month, year].join('/');
}

function displayTasks(tasks) {
    let htmlTemplate = $('#task-template').html(),
        tasksTemplate = Handlebars.compile(htmlTemplate)
    console.log('tasksTemplate(tasks)', tasksTemplate(tasks));
    $('#tasks-Table-Body').html(tasksTemplate({tasks}));
}

function getCurrentUser(user){
    let url = "http://localhost:9090/api/users/" + user.username;
    return fetch(url).then(response => response.json());
}

function getTasks(user){
        let url = "http://localhost:9090/api/tasks/teacher/" + user.staffNo;
        return fetch(url).then(response => response.json());
}

function getTask(id){
    let url = "http://localhost:9090/api/tasks/id/" + id;
    return fetch(url).then(response => response.json());
}

function getParents() {
    let url = "http://localhost:9090/api/students";
    return fetch(url).then(response => response.json());
}

function updateTask(task){ //Incomplete
    let url = "http://localhost:9090/api/tasks/";
    fetch(url, {
        method: "put",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(task)
    }).then(res => {
        console.log(res);
    })
}

function addTask(){ //Incomplete
    let task = {
        studentId: $('#studentDD').val(),
        surahId: $('#surah').val(),
        fromAya: $('#FromAya').val(),
        toAya: $('#ToAya').val(),
        type: $('input[name=type]:checked').val(),
        dueDate: $('#Due').val(),
        completedDate:$('#Completed').val()
    }
    let url = "http://localhost:9090/api/tasks/";
    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(task)
    }).then(res => {
        console.log(res);
    })
}

function load_edit(task){
    $('#editDue').val(task[0].dueDate);
    $('#editSurahName').val(task[0].surahName);
    $('#editFromAya').val(task[0].fromAya);
    $('#editToAya').val(task[0].toAya);
    $('#editComment').val(task[0].comment);

}

function openDialog(element) {
    console.log('Row was just clicked');
    let id = element.id;
    getTask(id).then(task => {
        load_edit(task);
        var dialogInstance1 = new BootstrapDialog({
            size: BootstrapDialog.SIZE_WIDE,
            title: 'Edit Request',
            message: $('#editForm').show()
            ,
            buttons: [{
                label: 'Submit',
                cssClass: 'btn-primary',
                action: function() {
                    console.log('submit button pressed');
                    //create the task object here then call the update method and pass the task to it
                }
            }]
        });
        dialogInstance1.open();
    });
}
function taskDialog(element) {
    console.log('add was just clicked');
        var dialogInstance1 = new BootstrapDialog({
            size: BootstrapDialog.SIZE_WIDE,
            title: 'Edit Request',
            message: $('#addForm').show()
            ,
            buttons: [{
                label: 'Submit',
                cssClass: 'btn-primary',
                action: function() {
                    console.log('submit button pressed');
                    //create the task object here then call the update method and pass the task to it
                    addTask();
                }
            }]
        });
        dialogInstance1.open();
}

/*
Whats left here:
- Updating a task (see comments in the open dialog method, the repository and app.js)
- Delete task use case (Not even started):
    -add a onclick listener to the delete button
    -add a delete api in app.js
    -add a deleteTask() method to the repository
    -fetch the url in the onClick listener
- Marking the selected tasks as complete

Note: the edit task starts when the task is clicked from the tasks table in the Manage Tasks tab. You can add tasks the same way except that the dialog should pop up when the user presses a button
 or you can just add the body of the html page that yasser made into a new tab and import the js methods from addTask.js into this file.
 I also found a bug where the editTask dialog would appear without the forum the second time you click any element from the table
 */