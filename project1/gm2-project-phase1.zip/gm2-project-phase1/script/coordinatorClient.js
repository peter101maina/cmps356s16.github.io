
/**
 * Created by Ahmed on 4/26/2016.
 */
"use strict";

$(document).ready(function(){
    $('#btnSubmitRegister').on('click' , submitParent);
    $('#btnSubmitRegisterChild').on('click' , submitStudent);
    $('#btnSubmitAnnouncement').on('click', submitAnnouncement );
    $("#studentDD").on('change', onStudentChange);
    let user = JSON.parse(localStorage.user);
    console.log(user.username + " is now logged in");
    $('#loggedInAs').html('logged in as ' + user.username);
    getParents().then(parents => fillStudentsDD(parents)).catch(err => console.log(err));
    getParents().then(parents => fillParentsDD(parents)).catch(err => console.log(err));
    getTeachers().then(teachers => fillTeachersDD(teachers)).catch(err => console.log(err));

});
function getSelectedMessage(id){
    let url = "http://localhost:9090/api/messages/id/"+id;
    return fetch(url).then(response => response.json());
}
function openDialog(element) {
    let id = element.id;
    getSelectedMessage(id).then(Msg=>{
        let content=Msg.content;
        let from=Msg.from;
        var date=Msg.date;
        var dialogInstance1 = new BootstrapDialog({
            title: "From: "+from + " on " + date,
            message:content,
            buttons: [{
                label: 'Close',
                action: function(dialogItself){
                    dialogItself.close();
                }
            }]
        });
        dialogInstance1.open();
    });

}
function submitParent(event){

    event.preventDefault();


        let fName = $('#Fname').val();
    let lName = $('#Lname').val();
    let qId = $('#QID').val();
    let email = $('#Email').val();
    let country = $('#countries').val();
    let username = $('#Username').val();
    let password = $('#Password').val();
    let phone = $('#Phone').val();

    let parent = {
        qatariId: qId,
        firstName: fName,
        lastName: lName,
        mobile: phone,
        email: email,
        username: username,
        password: password,
        country: country,
        students: {}
    };

    console.log("Parent created: " + JSON.stringify(parent));
    let url = "http://localhost:9090/api/parent";

    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(parent)
    }).then(res => {
        console.log(res);
    })

}
function submitStudent(event){

    event.preventDefault();

    let parent= $('#parentDD').val();
    let fName = $('#Fname').val();
    let lName = $('#Lname').val();
    let dob = $('#DoB').val();
    let gender = $('#gender').val();
    let teacherID = $('#halaqas').val();
    let schoolgrade = $('#SchoolGrade').val();

    let student = {
        firstName: fName,
        lastName: lName,
        dob: dob,
        gender: gender,
        schoolGrade:schoolgrade,
        teacherId:teacherID,
        parentUsername:parent
    };

    console.log("Student created: " + JSON.stringify(student));
    let url = "http://localhost:9090/api/student";

    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(student)
    }).then(res => {
        console.log(res);
    })

}

function formattedDate(date) {
    var d = new Date(date || Date.now()),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [day, month, year].join('/');
}

function submitAnnouncement(event){

    event.preventDefault();

    let announcement = $('#announcementBody').val();
    let url = 'http://localhost:9090/api/messages';

    let currentUser = JSON.parse(localStorage.user);

    let message = {
        content: announcement,
        from: currentUser.username,
        to: 'all',
        date: formattedDate(new Date())
    };

    fetch(url, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(message)
    }).then(res => {
        console.log(res);
    })

}

function getParents() {
    let url = "http://localhost:9090/api/students";
    return fetch(url).then(response => response.json());
}

function getTasks(id){
    let url = "http://localhost:9090/api/tasks/" + id;
    return fetch(url).then(response => response.json());
}

function getMessages(id){
    let url = "http://localhost:9090/api/messages/" + id;
    return fetch(url).then(response => response.json());
}


function onStudentChange(){
    let selectedStudentId = $(this).val();

    if(selectedStudentId != "") {
    getTasks(selectedStudentId).then(tasks => {
        displayTasks(tasks);
    }).catch(err => console.log(err));


        getMessages(selectedStudentId).then(messages => {
            displayMessages(messages)
        }).catch(err => console.log(err));
    }

}

function fillStudentsDD(parents) {
    for(let parent of parents) {
        for(var i =0; i<parent.students.length; i++) {
            let student = parent.students[i];
            let studentName = student.firstName + " " + student.lastName;
            $("<option>", {
                value: student.studentId,
                text: studentName
            }).appendTo($("#studentDD"))
        }
    }
}

function fillParentsDD(parents) {
    for(let parent of parents) {
            let parentName = parent.firstName+ " " + parent.lastName;
            $("<option>", {
                value: parent.username,
                text: parentName
            }).appendTo($("#parentDD"))

    }
}

function getTeachers() {
    let url = 'http://localhost:9090/api/teachers';
    return fetch(url).then(response => {
        console.log(response);
        return response.json();
    }).then(teachers => {
        return teachers.filter(u=>u.lastName!="Coordinator");
    }).catch( err => {
        console.log(err);
    })
}

function fillTeachersDD(Teachers) {
    for (let teacher of Teachers) {
        $("<option>", {
            value: teacher.staffNo,
            text: teacher.halaqa
        }).appendTo($("#halaqas"))
    }
}

function displayTasks(tasks) {
    let htmlTemplate = $('#task-template').html(),
        tasksTemplate = Handlebars.compile(htmlTemplate)
    console.log('tasksTemplate(tasks)', tasksTemplate(tasks));
    $('#tasks-Table-Body').html(tasksTemplate({tasks}));
}

function displayMessages(messages){
    console.log(messages);
    let htmlTemplate = $('#messages-template').html(),
        messagesTemplate = Handlebars.compile(htmlTemplate)
    console.log('messagesTemplate(messages)', messagesTemplate(messages));
    $('#messages-Table-Body').html(messagesTemplate({messages}));
}

/*
 Whats left here:
 - adding a child does not work properly (the child is not added to a parent but added as a parent)
 - adding attachments and type of announcement to the announcements useCase (for adding a type you can just add the attribute to the message, the rest should be handled by the server and the repository)
 */