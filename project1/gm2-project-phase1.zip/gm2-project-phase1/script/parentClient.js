/**
 * Created by Ahmed on 4/28/2016.
 */
$(document).ready(function(){
    let user = JSON.parse(localStorage.user);
    console.log(user.username + " is now logged in");
    $('#loggedInAs').html('logged in as ' + user.username);
    $("#studentDD").on('change', onStudentChange);
    getMessages(user.username).then(messages => displayMessages(messages));
    getParent(user.username).then(parent => fillStudentsDD(parent));
});

function fillStudentsDD(parent) {
        for(var i =0; i<parent.students.length; i++) {
            let student = parent.students[i];
            let studentName = student.firstName + " " + student.lastName;
            $("<option>", {
                value: student.studentId,
                text: studentName
            }).appendTo($("#studentDD"))
        }
}
function getSelectedMessage(id){
    let url = "http://localhost:9090/api/messages/id/"+id;
    return fetch(url).then(response => response.json());
}

function openDialog(element) {
    console.log('Row was just clicked');
    let id = element.id;
    getSelectedMessage(id).then(Msg=>{
        let content=Msg.content;
        let from=Msg.from;
        var date=Msg.date;
        var dialogInstance1 = new BootstrapDialog({
            title: "From: "+from + " on "+date,
            message: content,
            buttons: [{
                label: 'Close',
                action: function(dialogItself){
                    dialogItself.close();
                }
            }]
        });
        dialogInstance1.open();
    });

}
function onStudentChange(){
    let selectedStudentId = $(this).val();
    if(selectedStudentId == ""){}
    else {
        getTasks(selectedStudentId).then(tasks => {
            displayTasks(tasks);
        }).catch(err => console.log(err));
    }
}

function displayMessages (messages){
    console.log(messages);
    let htmlTemplate = $('#messages-template').html(),
        messagesTemplate = Handlebars.compile(htmlTemplate)
    console.log('messagesTemplate(messages)', messagesTemplate(messages));
    $('#messages-Table-Body').html(messagesTemplate({messages}));
}

function displayTasks(tasks) {
    let htmlTemplate = $('#task-template').html(),
        tasksTemplate = Handlebars.compile(htmlTemplate)
    console.log('tasksTemplate(tasks)', tasksTemplate(tasks));
    $('#tasks-Table-Body').html(tasksTemplate({tasks}));
}

function getMessages(username){
        let url = "http://localhost:9090/api/messages/parent/" + username;
        return fetch(url).then(response => response.json());
}

function getParent(username){
    let url = "http://localhost:9090/api/users/" + username;
    return fetch(url).then(response => response.json());
}

function getTasks(id){
    let url = "http://localhost:9090/api/tasks/" + id;
    return fetch(url).then(response => response.json());
}







