/**
 * Created by Ahmed on 4/25/2016.
 */
"use strict";

let express = require('express');
let userRepository = require("./repos/userRepository");
let taskRepository = require("./repos/taskRepository");
let bodyParser = require('body-parser');
let app = express();
let port = 9090;
//Allow serving static files
app.use(express.static(__dirname));

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

app.get('/',(req,res)=>{
    res.send("Welcome!!!");
});

app.post('/api/users/login', (req, res) => {
    console.log('---------------------------');
    console.log('login attempt:');
    let username = req.body.username;
    let userInformation = req.body;
    console.log(userInformation);
    userRepository.getUserByUsername(username).then(user=> {
        if (user.password == req.body.password) {
            console.log('login successful');
            userInformation.isIn = true;
            if (user.hasOwnProperty('staffNo')) {
                if(user.hasOwnProperty('isCoordinator')){
                    console.log('coordinator login');
                    userInformation.goTo = '/coordinatorHome.html';
                }
                else{
                    console.log('staff login');
                    userInformation.goTo = '/teacherHome.html';
                }
                console.log('---------------------------');
            }
            else{
                console.log('Parent Login');
                userInformation.goTo = '/parentHome.html';
                console.log('---------------------------');
            }
        }
        else{
            console.log('Invalid password input');
            userInformation = {
                isIn : false,
                allert : 'Invalid password'
            };
        }
        res.json(userInformation);
    }).catch(err => {
        console.log('user not found');
        userInformation.isIn = false;
        userInformation.allert = 'Invalid username';
        res.json(userInformation);
    });
});

app.post('/api/parent', (req,res)=>{
    console.log('attempting to post parent');
    let parent = req.body;
    userRepository.addParent(parent).then((parent) =>{
        res.status(200).send('parent created');
    }).catch(err => {
        console.log(err);
        res.status(500).send('Fail: could not post');
    });
});

app.post('/api/student', (req,res)=>{
    console.log('attempting to post student');
    let student = req.body;
    userRepository.addStudent(student).then((student) =>{
        res.status(200).send('student created');
    }).catch(err => {
        console.log(err);
        res.status(500).send('Fail: could not post');
    });
});

app.post('/api/messages', (req,res)=>{
    console.log('---------------------------');
    let message = req.body;
    console.log('attempting to send message to ' + message.to );
    userRepository.sendMessage(message).then((message) =>{
        console.log('attempt successful');
        console.log('---------------------------');
        res.status(200).send('message sent');
    }).catch(err => {
        console.log(err);
        console.log('---------------------------');
        res.status(500).send('Fail: could not post');
    });
});

app.get('/api/messages/:id' , (req,res) =>{ //gets messages by student id
    console.log('---------------------------');
    console.log('attempting to retrieve messages by student id: ' + req.params.id);
    let id = req.params.id;
    userRepository.getMessagesByID(id).then(messages =>{
        res.json(messages);
        console.log('attempt successful');
        console.log('---------------------------');
    }).catch(err => res.status(404).send('Failed: ' + err));
});

app.get('/api/messages/id/:id', (req, res) => {      //get surah by id
    console.log('---------------------------');
    let id = req.params.id;
    console.log('Attempting to retrieve massege with id: ' + id);
    userRepository.getMassegeByMassegeID(id).then(msg => {
        console.log('massege successfully retrieved');
        console.log('---------------------------');
        return res.json(msg);
    }).catch(err=>{
        console.log('massege was not found');
        console.log('---------------------------');
        res.send("Fail: "+err);
    });
});

app.get('/api/messages/parent/:username' , (req,res) =>{ //gets messages by student id
    console.log('---------------------------');
    console.log('attempting to retrieve messages by parent Username: ' + req.params.username);
    let username = req.params.username;
    userRepository.getMessagesByUser(username).then(messages =>{
        res.json(messages);
        console.log('attempt successful');
        console.log('---------------------------');
    }).catch(err => res.status(404).send('Failed: ' + err));
});


app.get('/api/users', (req,res)=>{
    console.log('---------------------------');
    console.log('Attempt to request all users');
    userRepository.getAllUsers().then(users => {
        for (var i = 0; i < users.length ; i++){
            delete users[i].password;
        }
        res.json(users);
        console.log('---------------------------');
    }).catch(err => res.status(404).send(err));
});

app.get('/api/surahs', (req,res)=>{
    console.log('---------------------------');
    console.log('Attempt to request all surahs');
    taskRepository.getSurahs().then(surahs => {
        res.json(surahs);
        console.log('---------------------------');
    }).catch(err => console.log(err));
});


app.get('/api/surahs/:id', (req, res) => {      //get surah by id
    console.log('---------------------------');
    let id = req.params.id;
    console.log('Attempting to retrieve surah: ' + id);
    taskRepository.getSurahByID(id).then(surah => {
        console.log('Surah successfully retrieved');
        console.log('---------------------------');
        return res.json(surah);
    }).catch(err=>{
        console.log('Surah was not found');
        console.log('---------------------------');
        res.send("Fail: "+err);
    });
});

app.get('/api/tasks/:id', (req, res) => {      //get surah by id
    console.log('---------------------------');
    let id = req.params.id;
    console.log('Attempting to retrieve tasks for student: ' + id);
    taskRepository.getTaskByStudentID(id).then(tasks => {
        console.log('tasks successfully retrieved');
        console.log('---------------------------');
        return res.json(tasks);
    }).catch(err=>{
        console.log('tasks were not found');
        console.log('---------------------------');
        res.send("Fail: "+err);
    });
});

app.get('/api/tasks/id/:id', (req, res) => {
    console.log('---------------------------');
    console.log('Attempting to retrieve task by id: ' + req.params.id);
    taskRepository.getTaskById(req.params.id).then(task =>{
        res.json(task);
        console.log('Attempt successful');
        console.log('---------------------------');
    }).catch(err => res.status(404).send(err));
});

app.get('/api/tasks', (req,res)=>{
    console.log('---------------------------');
    console.log('Attempt to request all tasks');
    taskRepository.getTasks().then(tasks => {
        res.json(tasks);
        console.log('---------------------------');
    }).catch(err => console.log(err));
});


/*app.put('/api/tasks', (req,res)=>{ //Incomplete
    console.log('---------------------------');
    console.log('Attempt to edit task');
    let task = req.body;
    taskRepository.editTask(task).then(res =>{

        res.status(200).send('task posted');
        console.log("attempt successful");
        console.log('---------------------------');
    });

}).catch(err => res.status(500).send(err));*/


app.post('/api/tasks', (req,res)=>{
    console.log('---------------------------');
    let task = req.body;
    console.log('attempting to add task ');
    taskRepository.addTask(task).then((task) =>{
        console.log('attempt successful');
        console.log('---------------------------');
        res.status(200).send('task added');
    }).catch(err => {
        console.log(err);
        console.log('---------------------------');
        res.status(500).send('Fail: could not post');
    });
});



app.get('/api/tasks/:id', (req, res) => {      //get task by student id
    console.log('---------------------------');
    let id = req.params.id;
    console.log('Attempting to retrieve tasks: ' + id);
    taskRepository.getTaskByStudentID(id).then(tasks => {
        console.log('tasks successfully retrieved');
        console.log('---------------------------');
        return res.json(tasks);
    }).catch(err=>{
        console.log('Student has no tasks');
        console.log('---------------------------');
        res.send("Fail: "+err);
    });
});

app.get('/api/tasks/teacher/:id', (req, res) => {      //get task by student id
    console.log('---------------------------');
    let id = req.params.id;
    console.log('Attempting to retrieve tasks: ' + id);
    userRepository.getStudentsByTeacherId(parseInt(id)).then(studentsList => {
        taskRepository.getTasksByStudents(studentsList).then(tasks =>{
            res.json(tasks);
            console.log('Tasks successfully retrieved');
            console.log('---------------------------');
        }).catch(err => res.status(404).send('The task was not found'));
    }).catch(err => res.status(500).send('The tasks was not found'));
});

app.get('/api/students', (req,res)=>{
    console.log('---------------------------');
    console.log('Attempt to get all students');
    userRepository.getStudents().then(students => {
        for (var i = 0; i < students.length; i++){
            delete students[i].password;
        }
        res.json(students);
        console.log('---------------------------');
    }).catch(err => console.log(err));

});

app.get('/api/teachers', (req,res)=>{
    console.log('---------------------------');
    console.log('Attempt to get all teachers');
    userRepository.getTeachers().then(teachers => {
        for (var i = 0; i < teachers.length; i++){
            delete teachers[i].password;
        }
        res.json(teachers);
        console.log('---------------------------');
    }).catch(err => console.log(err));

});

app.get('/api/users/:username', (req, res) => {      //get user by username
    console.log('---------------------------');
    let username = req.params.username;
    console.log('Attempting to retrieve username: ' + username);
    userRepository.getUserByUsername(username).then(user => {
        console.log('User successfully retrieved');
        console.log('---------------------------');
        return res.json(user);
    }).catch(err=>{
        console.log('User was not found');
        console.log('---------------------------');
        res.status(404).send("Fail: "+err);
    });
});

app.listen(port, function(){
    console.log('HalaqaMetrash App is running my app on http://localhost:' + port);
    //open('http://localhost:' + port);
});
